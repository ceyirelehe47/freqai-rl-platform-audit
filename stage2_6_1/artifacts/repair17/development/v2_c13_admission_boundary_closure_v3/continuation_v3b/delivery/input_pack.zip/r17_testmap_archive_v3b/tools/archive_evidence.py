#!/usr/bin/env python3
"""Export verification evidence without following or publishing special files.

No source deletion, mutation, generator, claim, import of project code, or Git
write operation. The only allowed special object is the explicitly named
symlink negative. Its readlink bytes are retained in an inert regular JSON
record; it is never dereferenced or recreated in the publication tree.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

FORMAT = 'R17EvidenceExport-v3b'
MANIFEST = '_ARCHIVE_MANIFEST.json'
LINKS = '_LINK_RECORDS'
ALLOWED_LINK = 'negative_cases/nested_directory_symlink/package/symlink_directory'
EVIDENCE_ROOT = ('stage2_6_1/artifacts/repair17/development/'
                 'v2_c13_admission_boundary_closure_v3/continuation_v3b')

class ExportError(RuntimeError):
    pass

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def json_bytes(obj) -> bytes:
    return (json.dumps(obj, sort_keys=True, ensure_ascii=True, indent=2) + '\n').encode()

def safe_path(path: Path, *, exists=False) -> Path:
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise ExportError('absolute path without .. required')
    probe = Path(path.anchor)
    for part in path.parts[1:]:
        probe /= part
        try:
            st = probe.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(st.st_mode):
            raise ExportError('symlink path component: ' + str(probe))
        if probe != path and not stat.S_ISDIR(st.st_mode):
            raise ExportError('non-directory path component: ' + str(probe))
    if exists and not path.exists():
        raise ExportError('path missing: ' + str(path))
    return path

def _signature(st):
    return st.st_dev, st.st_ino, st.st_mode, st.st_size, st.st_mtime_ns, st.st_ctime_ns

def regular_meta(path: Path, dest: Path | None = None) -> dict:
    """Read only a regular descriptor, not a path-following stream (FIFO safe)."""
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ExportError('not a regular file: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    stream = None
    try:
        opened = os.fstat(fd)
        if _signature(opened) != _signature(before) or not stat.S_ISREG(opened.st_mode):
            raise ExportError('source changed before opening: ' + str(path))
        if dest is not None:
            dest.parent.mkdir(parents=True, exist_ok=True)
            stream = dest.open('xb')
        h = hashlib.sha256(); size = 0
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk); size += len(chunk)
            if stream is not None:
                stream.write(chunk)
        if _signature(os.fstat(fd)) != _signature(opened) \
                or _signature(path.lstat()) != _signature(opened):
            raise ExportError('source changed during copy: ' + str(path))
        if stream is not None:
            stream.flush(); os.fsync(stream.fileno())
        return {'kind': 'regular', 'size': size, 'sha256': h.hexdigest(),
                'source_mode': stat.S_IMODE(opened.st_mode)}
    finally:
        if stream is not None:
            stream.close()
        os.close(fd)

def inventory(root: Path, *, permit_probe_link=False) -> dict:
    root = safe_path(root, exists=True)
    if not root.is_dir():
        raise ExportError('source must be a directory')
    out = {}
    def walk(directory):
        before = directory.lstat()
        if not stat.S_ISDIR(before.st_mode):
            raise ExportError('non-directory during traversal')
        with os.scandir(directory) as entries:
            names = sorted(e.name for e in entries)
        for name in names:
            p = directory / name
            rel = p.relative_to(root).as_posix()
            if any(c in rel for c in ('\n', '\r', '\t', '\\')):
                raise ExportError('unsafe evidence path: ' + repr(rel))
            st = p.lstat()
            if stat.S_ISDIR(st.st_mode):
                out[rel] = {'kind': 'directory'}
                walk(p)
            elif stat.S_ISREG(st.st_mode):
                out[rel] = regular_meta(p)
            elif stat.S_ISLNK(st.st_mode) and permit_probe_link and rel == ALLOWED_LINK:
                raw = os.readlink(os.fsencode(p))
                if _signature(st) != _signature(p.lstat()):
                    raise ExportError('symlink changed during readlink')
                out[rel] = {'kind': 'symlink', 'git_mode': '120000',
                            'target_base64': base64.b64encode(raw).decode('ascii'),
                            'target_size': len(raw), 'target_sha256': digest(raw),
                            'dereferenced': False}
            else:
                raise ExportError('special object is not an authorized probe: ' + rel)
        after = directory.lstat()
        if _signature(before) != _signature(after):
            raise ExportError('directory changed during inventory: ' + str(directory))
    walk(root)
    return dict(sorted(out.items()))

def file_index(root: Path) -> dict:
    return {p: {'size': r['size'], 'sha256': r['sha256']}
            for p, r in inventory(root).items() if r['kind'] == 'regular'}

def export_tree(source: Path, destination: Path) -> dict:
    source = safe_path(source, exists=True)
    destination = safe_path(destination)
    if destination == source or destination.is_relative_to(source) \
            or source.is_relative_to(destination):
        raise ExportError('source/destination overlap')
    if os.path.lexists(destination):
        raise ExportError('destination exists; use a fresh attempt')
    before = inventory(source, permit_probe_link=True)
    if MANIFEST in before or any(p == LINKS or p.startswith(LINKS + '/') for p in before):
        raise ExportError('reserved export metadata path already exists in source')
    # Nothing is written until the complete input inventory has been checked.
    destination.mkdir(parents=True)
    described = {}
    for rel, record in before.items():
        if record['kind'] == 'directory':
            (destination / rel).mkdir(parents=True, exist_ok=True)
        elif record['kind'] == 'regular':
            copied = regular_meta(source / rel, destination / rel)
            if copied != record:
                raise ExportError('copy differs from inventory: ' + rel)
        else:
            descriptor = LINKS + '/' + digest(rel.encode()) + '.json'
            target = destination / descriptor
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(json_bytes({'format': FORMAT, 'original_path': rel,
                                         **record, 'restored_as_link': False}))
            described[rel] = descriptor
    after = inventory(source, permit_probe_link=True)
    if before != after:
        raise ExportError('source tree changed; partial output is NOT publishable')
    result = {'format': FORMAT, 'source_root': str(source),
              'source_unchanged': True, 'source_inventory': before,
              'symlink_descriptors': described, 'published_files': file_index(destination),
              'no_live_symlinks': True}
    with (destination / MANIFEST).open('xb') as stream:
        stream.write(json_bytes(result))
    verify_export(destination, source=source)
    return {'ok': True, 'format': FORMAT, 'destination': str(destination),
            'regular_files': len(result['published_files']),
            'inert_symlink_records': len(described), 'source_unchanged': True}

def verify_export(root: Path, *, source: Path | None = None) -> dict:
    root = safe_path(root, exists=True)
    actual = file_index(root)  # rejects every live symlink/special file
    metadata = json.loads((root / MANIFEST).read_bytes())
    if metadata.get('format') != FORMAT:
        raise ExportError('unknown export format')
    actual.pop(MANIFEST, None)
    if actual != metadata.get('published_files'):
        raise ExportError('export files differ from sealed manifest')
    original = metadata.get('source_inventory')
    links = metadata.get('symlink_descriptors')
    if not isinstance(original, dict) or not isinstance(links, dict):
        raise ExportError('export inventory missing')
    regulars = {p: {'size': m['size'], 'sha256': m['sha256']}
                for p, m in original.items() if m['kind'] == 'regular'}
    if any(actual.get(p) != m for p, m in regulars.items()):
        raise ExportError('original regular bytes not preserved')
    if set(links) != {p for p, r in original.items() if r['kind'] == 'symlink'}:
        raise ExportError('inert descriptor coverage mismatch')
    if set(actual) != set(regulars) | set(links.values()):
        raise ExportError('unexpected export members')
    for rel, path in links.items():
        if rel != ALLOWED_LINK or path != LINKS + '/' + digest(rel.encode()) + '.json':
            raise ExportError('unauthorized descriptor path')
        record = json.loads((root / path).read_bytes())
        raw = base64.b64decode(record['target_base64'], validate=True)
        if record != {'format': FORMAT, 'original_path': rel,
                      **original[rel], 'restored_as_link': False} \
                or len(raw) != record['target_size'] or digest(raw) != record['target_sha256']:
            raise ExportError('descriptor target bytes mismatch')
        if os.path.lexists(root / rel):
            raise ExportError('link must not exist in exported tree')
    if source is not None and inventory(source, permit_probe_link=True) != original:
        raise ExportError('source differs from its pre-export inventory')
    return {'ok': True, 'regular_files': len(actual), 'inert_symlink_records': len(links)}

def git(repo, *args):
    p = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, timeout=120)
    if p.returncode:
        raise ExportError(p.stderr.decode(errors='replace'))
    return p.stdout

def verify_staged(repo: Path, evidence_rel: str = EVIDENCE_ROOT) -> dict:
    """Read-only precommit gate: only new regular blobs in the new v3b root."""
    repo = safe_path(repo, exists=True)
    if evidence_rel != EVIDENCE_ROOT:
        raise ExportError('wrong v3b evidence root')
    fields = git(repo, 'diff', '--cached', '--name-status', '--no-renames', '-z').split(b'\0')
    fields = [x.decode('utf-8') for x in fields if x]
    if not fields or len(fields) % 2:
        raise ExportError('empty or malformed staged changes')
    stage = {}
    for item in git(repo, 'ls-files', '--stage', '-z').split(b'\0'):
        if item:
            header, raw = item.split(b'\t', 1)
            mode, oid, conflict = header.decode().split()
            stage[raw.decode()] = (mode, oid, conflict)
    checked = []
    for status, path in zip(fields[::2], fields[1::2]):
        if status != 'A' or not path.startswith(evidence_rel + '/'):
            raise ExportError('only new v3b evidence additions allowed: ' + status + ' ' + path)
        mode, oid, conflict = stage.get(path, ('', '', ''))
        if mode not in ('100644', '100755') or conflict != '0':
            raise ExportError('staged member is not a regular resolved Git blob: ' + path)
        disk = repo / path
        safe_path(disk, exists=True)
        meta = regular_meta(disk)
        body = git(repo, 'cat-file', 'blob', oid)
        if meta['sha256'] != digest(body) or meta['size'] != len(body):
            raise ExportError('staged bytes differ from worktree; check attributes: ' + path)
        checked.append({'path': path, 'mode': mode, 'git_blob': oid})
    # git add may silently omit ignored logs. Match the entire fresh publication
    # subtree to the index as well as checking the changed members.
    disk_index = file_index(repo / evidence_rel)
    expected_paths = {evidence_rel + '/' + rel for rel in disk_index}
    indexed_paths = {path for path in stage if path.startswith(evidence_rel + '/')}
    if expected_paths != indexed_paths:
        raise ExportError('publication/index member set differs (possibly ignored logs)')
    for path in sorted(expected_paths):
        mode, oid, conflict = stage[path]
        if mode not in ('100644', '100755') or conflict != '0':
            raise ExportError('nonregular publication member in index: ' + path)
        raw = git(repo, 'cat-file', 'blob', oid)
        info = disk_index[path[len(evidence_rel) + 1:]]
        if info != {'size': len(raw), 'sha256': digest(raw)}:
            raise ExportError('publication file not fully staged: ' + path)
    return {'ok': True, 'checked': checked, 'staged_regular_only': True,
            'publication_member_count': len(expected_paths), 'no_ignored_files_missing': True}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    ex = sub.add_parser('export'); ex.add_argument('--source', type=Path, required=True); ex.add_argument('--out', type=Path, required=True)
    ve = sub.add_parser('verify'); ve.add_argument('--root', type=Path, required=True); ve.add_argument('--source', type=Path)
    st = sub.add_parser('staged'); st.add_argument('--repo', type=Path, required=True)
    args = p.parse_args()
    if args.command == 'export':
        result = export_tree(args.source, args.out)
    elif args.command == 'verify':
        result = verify_export(args.root, source=args.source)
    else:
        result = verify_staged(args.repo)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, ExportError) as exc:
        print(f'EXPORT_STOP: {type(exc).__name__}: {exc}', file=sys.stderr)
        raise SystemExit(2)
