# WSL Runbook（执行给定代码，不另设计）

环境：WSL `CryptoRL-Ubuntu-24.04`；用户 `cryptorl`；conda `freqtrade-rl`；Python `3.11.16`；vendor pin `52bc96f4480b1a0da6a9b455bd00b17fbb6786a5`。

以下命令在**解压后的本包根目录**开始。脚本有固定生产路径但不启动生产实验。运行失败立即保留输出并停止；不要把 `|| true` 用在验收命令上。

## S0. 包、远端、历史原件

```bash
set -euo pipefail
PACK="$(pwd)"
test -f "$PACK/README_AGENT.md"
sha256sum -c "$PACK/SHA256SUMS"
REPO=/mnt/f/trading/freqai-rl-audit
DEPLOY=/home/cryptorl/projects/crypto_rl
RUNNER=$DEPLOY/stage2_6_1_runner
BASELINE=71a815c676e484ff5b97dbd230a40923ff468ae5
BRANCH=route-c-stage2-6-1-repair17
AR_REL=stage2_6_1/artifacts/repair17/development/v2_c13_admission_boundary_closure_v3/continuation_v3b
AR=$REPO/$AR_REL
BASE=$DEPLOY/work/r17_v3b_$(date -u +%Y%m%dT%H%M%SZ)
WORK=$BASE/work
PUB=$BASE/publish
source "$DEPLOY/activate-freqtrade.sh"
cd "$REPO"
test "$(python -c 'import platform; print(platform.python_version())')" = 3.11.16
test ! -e "$BASE"
test ! -e "$AR" && test ! -L "$AR"
mkdir -p "$WORK/handover" "$PUB"
git fetch origin
test "$(git rev-parse HEAD)" = "$BASELINE"
test "$(git rev-parse origin/$BRANCH)" = "$BASELINE"
test "$(git branch --show-current)" = "$BRANCH"
test -z "$(git diff --cached --name-only)"
test -z "$(git status --porcelain=v1 -- stage2_6_1/runner stage2_6_1/src stage2_6_1/tests .gitattributes)"
git status --porcelain=v1 > "$WORK/handover/worktree.txt"
git log -8 --oneline > "$WORK/handover/git_log.txt"
git ls-remote origin "refs/heads/$BRANCH" > "$WORK/handover/remote.txt"
python -VV > "$WORK/handover/python.txt" 2>&1
git -C "$DEPLOY/vendor/freqtrade" rev-parse HEAD > "$WORK/handover/vendor.txt"
test "$(cat "$WORK/handover/vendor.txt")" = 52bc96f4480b1a0da6a9b455bd00b17fbb6786a5
python "$PACK/tools/protected_snapshot.py" --repo "$REPO" > "$WORK/handover/protected_before.json"
sha256sum stage2_6_1/runner/r17_v2_c13_source_lock.py > "$WORK/handover/historical_lock.txt"
```

存在既有 run_supervision 未跟踪/追加并不授权清理它们。除已知活动遥测外发现未知修改，停止核对。不要 checkout/reset 到旧候选。

## S1. 应用四文件

```bash
python "$PACK/tools/apply_patch.py" --repo "$REPO" \
 > "$WORK/apply_check.json" 2> "$WORK/apply_check.stderr.log"
python "$PACK/tools/apply_patch.py" --repo "$REPO" --apply \
 --recovery "$WORK/recovery" > "$WORK/apply.json" 2> "$WORK/apply.stderr.log"
git diff --check
git diff --stat > "$WORK/handover/applied_diff_stat.txt"
```

应用器恰改四文件，完整输出 SHA 在 apply.json。保留 recovery，不执行旧应用器，不调用 relock。代码候选尚未生成。

## S2. 恢复合法测试来源并做定向

```bash
# 先用给定新实现作 source-only 诊断，不受未同步旧部署影响。
python "$PACK/tools/test_mapping.py" --runner "$PACK/implementation" \
 --repo "$REPO" --deploy "$DEPLOY" --candidate "$BASELINE" --worktree --source-only \
 > "$WORK/handover/test_source_before_sync.json"
bash "$REPO/stage2_6_1/runner/r17_sync.sh" \
 > "$WORK/sync.stdout.log" 2> "$WORK/sync.stderr.log"
python "$PACK/tools/test_mapping.py" --runner "$RUNNER" \
 --repo "$REPO" --deploy "$DEPLOY" --candidate "$BASELINE" --worktree \
 > "$WORK/handover/test_mapping_worktree.json"
cd "$PACK"
bash "$PACK/tools/run_pack_checks.sh" "$WORK/pack_checks"
bash "$PACK/tools/run_targeted.sh" "$WORK/targeted"
```

核对129测试文件、31根目录来源均恢复；mapping_worktree 只是新候选提交前的诊断，不用于生产准入。八文件定向应含21个新的映射case，预计178；以实际 JUnit 和 checker 为准。任一失败停止，不能移走合法源测试。

## S3. 新代码候选 C

```bash
cd "$REPO"
git add -- \
 stage2_6_1/runner/r17_v2_c13_admission_guard.py \
 stage2_6_1/runner/r17_v2_c13_governance_source_lock.py \
 stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_admission_guard.py \
 stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_regression_evidence.py
git diff --cached --name-status > "$WORK/handover/candidate_changes.txt"
# 人工核对恰为以上四文件；不要 git add -A。
git commit -m "R17 v3b: bind recursive candidate test sources to flat deployment"
CANDIDATE=$(git rev-parse HEAD)
printf '%s\n' "$CANDIDATE" > "$WORK/CANDIDATE_COMMIT.txt"
bash stage2_6_1/runner/r17_sync.sh > "$WORK/sync_after_C.log"
test -z "$(git status --porcelain=v1 -- stage2_6_1/runner stage2_6_1/src stage2_6_1/tests .gitattributes)"
```

此后不再修改代码、测试、配置。C 的实际 source hash/test Git对象决定后续包；不要给旧1832/2070包改candidate字段。

## S4. 完整 R17-first 回归（一次）

```bash
bash "$PACK/tools/run_bound_regression.sh" "$CANDIDATE" "$WORK/full_regression" \
 > "$WORK/full_regression.console.log" 2> "$WORK/full_regression.console.stderr.log"
```

脚本会在 collect/pytest 前检查完整递归源map，并从map生成运行列表；不存在“跑完发现路径错，再删测试”的步骤。脚本中的原collector、实际full verifier必须都通过。所有rc/JUnit/required/native和两次source/map保留。失败按实际阶段归档，不新开正式实验。

## S5. 健康控制与10类副本负例

```bash
python "$PACK/tools/probe_evidence.py" --runner "$RUNNER" \
 --package "$WORK/full_regression/healthy_package" --out "$WORK/negative_cases" \
 > "$WORK/negative_cases.stdout.json" 2> "$WORK/negative_cases.stderr.log"
python "$PACK/tools/protected_snapshot.py" --repo "$REPO" \
 --compare "$WORK/handover/protected_before.json" > "$WORK/protected_after.json"
```

按 TASKBOOK 的要求完成 `WORK/REPORT.md`，此时工程结论写 `PENDING_POST_COMMIT_VERIFY`，列明实际测试计数，不提前 PASS。更正31文件误判，但不改旧报告。

可以把本包 ZIP 原字节另存到 WORK/input_pack.zip 以保存实现来源；不要复制运行过的pytest临时目录或未知特殊文件到WORK。

## S6. 导出并暂存（不使用 cp -a/cp -L）

```bash
# 从这里起 WORK 封存，不再向其中写任何运行日志。
python "$PACK/tools/archive_evidence.py" export --source "$WORK" --out "$AR/delivery" \
 > "$PUB/export.json" 2> "$PUB/export.stderr.log"
python "$PACK/tools/archive_evidence.py" verify --root "$AR/delivery" --source "$WORK" \
 > "$PUB/export_verify.json"
cd "$REPO"
# -f 只用于精确的新证据子树，避免 .gitignore 漏收必要日志。
git add -f -- "$AR_REL/delivery"
python "$PACK/tools/archive_evidence.py" staged --repo "$REPO" > "$PUB/staged_gate.json"
git diff --cached --name-status > "$PUB/staged_changes.txt"
git commit -m "R17 v3b: archive complete regression with inert negative-case link records"
EVIDENCE=$(git rev-parse HEAD)
printf '%s\n' "$EVIDENCE" > "$PUB/EVIDENCE_COMMIT.txt"
```

staged 门禁同时检查全部新证据子树与 index 的集合，不仅检查已暂存的部分；缺收被忽略日志也会拒绝。mode120000和gitlink仍拒绝。

## S7. E 后真实 full 冷验、E2、最终推送

```bash
mkdir "$PUB/post_E"
printf '%s\n' "$CANDIDATE" > "$PUB/post_E/CANDIDATE.txt"
printf '%s\n' "$EVIDENCE" > "$PUB/post_E/EVIDENCE.txt"
printf '%s\n' "python $RUNNER/r17_v2_c13_regression_evidence.py verify --package $AR/delivery/full_regression/healthy_package" \
 > "$PUB/post_E/command.txt"
set +e
python "$RUNNER/r17_v2_c13_regression_evidence.py" verify \
 --package "$AR/delivery/full_regression/healthy_package" \
 > "$PUB/post_E/result.json" 2> "$PUB/post_E/stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$PUB/post_E/rc.txt"
test "$RC" -eq 0
python - "$PUB/post_E/result.json" <<'PY'
import json,sys
v=json.load(open(sys.argv[1]))
assert v['ok'] and v['validation_scope']=='full' and not v['admission_eligible'], v
PY
# 在PUB/post_E/FINAL_REPORT.md写真实三层结论并附export/staged结果摘要。
# 不修改delivery里的待验收报告，最终结论由post_E/新文档承载。
python "$PACK/tools/archive_evidence.py" export --source "$PUB/post_E" --out "$AR/post_E" \
 > "$PUB/post_E_export.json"
git add -f -- "$AR_REL/post_E"
python "$PACK/tools/archive_evidence.py" staged --repo "$REPO" > "$PUB/staged_E2.json"
git commit -m "R17 v3b: append post-commit full cold-read evidence"
FINAL=$(git rev-parse HEAD)
set +e
python "$RUNNER/r17_v2_c13_regression_evidence.py" verify \
 --package "$AR/delivery/full_regression/healthy_package" \
 > "$PUB/final_external_verify.json" 2> "$PUB/final_external_verify.stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$PUB/final_external_verify.rc"
test "$RC" -eq 0
python "$PACK/tools/protected_snapshot.py" --repo "$REPO" \
 --compare "$WORK/handover/protected_before.json" > "$PUB/final_protected_check.json"
git diff "$CANDIDATE"..HEAD --exit-code -- stage2_6_1/runner stage2_6_1/src stage2_6_1/tests
git push origin "$BRANCH"
git ls-remote origin "refs/heads/$BRANCH" > "$PUB/final_remote.txt"
test "$(cut -f1 "$PUB/final_remote.txt")" = "$FINAL"
```

最终 E2 full 冷验输出留在仓库外，由 Agent 直接交付或作为会话附件；不要为“归档最后一次归档的验证”无限提交。远端E2已包括E冷验原件。最终报告列出 C/E/E2 和外部最终校验摘要。

失败时不执行后续PASS路径。保留失败原件，另写普通失败说明并按任务边界提交推送；不 amend/force、删除历史 symlink、覆盖已封存目录或重写run_meta。
