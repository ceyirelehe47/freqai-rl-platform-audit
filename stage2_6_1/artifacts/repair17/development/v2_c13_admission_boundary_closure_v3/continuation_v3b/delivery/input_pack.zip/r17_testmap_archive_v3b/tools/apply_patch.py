#!/usr/bin/env python3
"""Pinned v3b patch. Changes four files; no sync/test/commit/push/claim side effects."""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

BASELINE = '71a815c676e484ff5b97dbd230a40923ff468ae5'
BRANCH = 'route-c-stage2-6-1-repair17'
ROOT = Path(__file__).resolve().parents[1]
RUNNER = 'stage2_6_1/runner/'
TESTS = 'stage2_6_1/tests/route_c_stage2_6_1/'
PINS = {
    RUNNER + 'r17_v2_c13_admission_guard.py': 'cae6f602e92773cf45da17609783c0ec73284b78',
    RUNNER + 'r17_v2_c13_governance_source_lock.py': 'db723cac4e1b3d6626def62458d94b8b1fcb5812',
    TESTS + 'test_curriculum261_r17_v2_c13_admission_guard.py': '2985be4ab82ed12b3f3b253fe5880ab2f5f79c40',
    TESTS + 'test_curriculum261_r17_v2_c13_regression_evidence.py': '5b30d919eef347d17d65be442b43abd847eaacb2',
}
HISTORY_SHA = 'c9152b62192a93571c16ba62e0ef2e70522f108726f3eb83fd25d48007a77c55'

def git(repo, *args):
    p = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, timeout=120)
    if p.returncode:
        raise RuntimeError(f'git {args} failed: {p.stderr.decode(errors="replace")}')
    return p.stdout

def blob_id(body):
    return hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()

def rewrite_full_fixture(source: str) -> str:
    """Keep production full binding strict; align fake ecology to its real 3-case fixture."""
    tree = ast.parse(source)
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'full_eco']
    if len(nodes) != 1:
        raise RuntimeError('expected exactly one full_eco fixture')
    node = nodes[0]
    lines = source.splitlines(keepends=True)
    block = ''.join(lines[node.lineno-1:node.end_lineno])
    start = block.index('    test_rel = []\n')
    stop = block.index('    def git(*args):\n', start)
    replacement = '''    # v3b: this is an explicit three-case synthetic ecology, not a fake
    # "full project" receipt. Candidate sources, deployment and actual fixture
    # JUnit/collection must agree; production verification has no exemption.
    test_body = ("def test_synth_0(): pass\\n"
                 "def test_synth_1(): pass\\n"
                 "def test_synth_2(): pass\\n").encode('utf-8')
    test_name = 'test_synth.py'
    (release / 'stage2_6_1/tests/route_c_stage2_6_1' / test_name).write_bytes(test_body)
    (deploy / 'tests/route_c_stage2_6_1' / test_name).write_bytes(test_body)
    test_rel = [('tests/route_c_stage2_6_1/' + test_name,
                 hashlib.sha256(test_body).hexdigest())]

'''
    block = block[:start] + replacement + block[stop:]
    lines[node.lineno-1:node.end_lineno] = [block]
    output = ''.join(lines)
    # All test assertions remain byte-for-byte AST-source identical.
    original_tests = {n.name: ast.get_source_segment(source, n) for n in tree.body
                      if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
    after_tests = {n.name: ast.get_source_segment(output, n) for n in ast.parse(output).body
                   if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
    if original_tests != after_tests:
        raise RuntimeError('existing regression tests unexpectedly modified')
    return output

def refresh_guard_hash(source, new_guard: bytes):
    tree = ast.parse(source)
    nodes = [n for n in tree.body if isinstance(n, ast.Assign)
             and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
             and n.targets[0].id == 'SOURCE_SHA256']
    if len(nodes) != 1:
        raise RuntimeError('governance hash map missing/ambiguous')
    node = nodes[0]
    mapping = ast.literal_eval(node.value)
    if mapping.get('r17_v2_c13_admission_guard') != 'daf603e6a4ca207373f3034ed518a32535810cc327dce356f075244bba0d3a04':
        raise RuntimeError('unexpected old guard hash')
    mapping['r17_v2_c13_admission_guard'] = hashlib.sha256(new_guard).hexdigest()
    lines = source.splitlines(keepends=True)
    lines[node.lineno-1:node.end_lineno] = ['SOURCE_SHA256 = ' + json.dumps(mapping, sort_keys=True, indent=4) + '\n']
    return ''.join(lines)

def transform(sources):
    guard = (ROOT / 'implementation/r17_v2_c13_admission_guard.py').read_bytes()
    output = {RUNNER + 'r17_v2_c13_admission_guard.py': guard,
              RUNNER + 'r17_v2_c13_governance_source_lock.py': refresh_guard_hash(
                  sources[RUNNER + 'r17_v2_c13_governance_source_lock.py'].decode(), guard).encode(),
              TESTS + 'test_curriculum261_r17_v2_c13_regression_evidence.py': rewrite_full_fixture(
                  sources[TESTS + 'test_curriculum261_r17_v2_c13_regression_evidence.py'].decode()).encode()}
    test_rel = TESTS + 'test_curriculum261_r17_v2_c13_admission_guard.py'
    output[test_rel] = sources[test_rel].rstrip() + b'\n\n' + (ROOT / 'payload/guard_test_additions.py').read_bytes()
    for name, data in output.items():
        compile(data, name, 'exec')
    # A new test helper must not redefine an old function or test.
    for name in (test_rel, TESTS + 'test_curriculum261_r17_v2_c13_regression_evidence.py'):
        funcs = [n.name for n in ast.parse(output[name]).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
        if len(funcs) != len(set(funcs)):
            raise RuntimeError('duplicate top-level test/fixture definition: ' + name)
    return output

def safe_existing(path, repo):
    for p in (path, *path.parents):
        if p.is_symlink():
            raise RuntimeError('symlink source path: ' + str(p))
        if p == repo:
            break
    if not path.is_file():
        raise RuntimeError('source file missing/nonregular: ' + str(path))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--apply', action='store_true')
    p.add_argument('--recovery', type=Path)
    a = p.parse_args()
    repo = a.repo.absolute()
    if repo.is_symlink() or repo != repo.resolve(strict=True):
        raise RuntimeError('repo must be real canonical directory')
    if git(repo, 'rev-parse', 'HEAD').decode().strip() != BASELINE:
        raise RuntimeError('HEAD differs from baseline; stop without reset/rebase')
    if git(repo, 'branch', '--show-current').decode().strip() != BRANCH:
        raise RuntimeError('wrong branch')
    if git(repo, 'diff', '--cached', '--name-only').strip():
        raise RuntimeError('index is not clean')
    if git(repo, 'status', '--porcelain=v1', '--', 'stage2_6_1/runner', 'stage2_6_1/src', 'stage2_6_1/tests', '.gitattributes').strip():
        raise RuntimeError('source/test/config worktree dirty')
    source = {}
    for rel, oid in PINS.items():
        safe_existing(repo / rel, repo)
        body = git(repo, 'show', 'HEAD:' + rel)
        if blob_id(body) != oid:
            raise RuntimeError('preimage Git blob mismatch: ' + rel)
        # Ignore CR bytes only as the documented sync representation; no arbitrary edits.
        if (repo / rel).read_bytes().replace(b'\r', b'') != body.replace(b'\r', b''):
            raise RuntimeError('worktree does not match its Git preimage: ' + rel)
        source[rel] = body
    historical = repo / (RUNNER + 'r17_v2_c13_source_lock.py')
    if hashlib.sha256(historical.read_bytes()).hexdigest() != HISTORY_SHA:
        raise RuntimeError('historical lock bytes changed')
    output = transform(source)
    hashes = {rel: hashlib.sha256(body).hexdigest() for rel, body in output.items()}
    if a.apply:
        if a.recovery is None:
            raise RuntimeError('--apply requires --recovery')
        recovery = a.recovery.absolute()
        if recovery != recovery.resolve(strict=False) or recovery.is_relative_to(repo) or os.path.lexists(recovery):
            raise RuntimeError('fresh nonsymlink recovery outside repo required')
        recovery.mkdir(parents=True)
        for rel in output:
            path = recovery / 'preimage' / rel; path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((repo / rel).read_bytes())
        (recovery / 'output_manifest.json').write_text(json.dumps(hashes, indent=2) + '\n')
        for rel, body in output.items():
            dest = repo / rel
            mode = dest.stat().st_mode & 0o777
            fd, temp = tempfile.mkstemp(prefix='.' + dest.name + '.', dir=dest.parent)
            try:
                with os.fdopen(fd, 'wb') as stream:
                    stream.write(body); stream.flush(); os.fsync(stream.fileno())
                os.chmod(temp, mode); os.replace(temp, dest)
            finally:
                if os.path.lexists(temp):
                    os.unlink(temp)
        for rel, expected in hashes.items():
            if hashlib.sha256((repo / rel).read_bytes()).hexdigest() != expected:
                raise RuntimeError('post-write hash mismatch: ' + rel)
        if hashlib.sha256(historical.read_bytes()).hexdigest() != HISTORY_SHA:
            raise RuntimeError('historical lock changed')
    print(json.dumps({'baseline': BASELINE, 'applied': a.apply, 'outputs': hashes,
                      'changed_files': 4, 'production_generation_authorized': False}, indent=2))

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'PATCH_STOP: {type(exc).__name__}: {exc}', file=sys.stderr)
        raise SystemExit(2)
