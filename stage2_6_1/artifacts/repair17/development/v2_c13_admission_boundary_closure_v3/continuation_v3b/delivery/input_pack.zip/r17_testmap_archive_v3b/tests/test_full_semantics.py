"""Run the shipped guard's full semantic function on actual temporary Git/file objects.
The synthetic package builder is the unchanged v3 function, not a PASS stub.
This is not the user's WSL project or the legacy collector CLI.
"""
import ast
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import pytest
import r17_v2_c13_admission_guard as g
import archive_evidence as exporter

ROOT=Path(__file__).resolve().parents[1]

def put(p,body):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(body.encode() if isinstance(body,str) else body)

def write(p,d):put(p,json.dumps(d,indent=2,sort_keys=True)+'\n')
def read(p):return json.loads(p.read_bytes())

def builder():
    file=ROOT/'references/evidence_functions_before.py'
    tree=ast.parse(file.read_bytes());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_synthetic_package')
    ns={'Path':Path,'Any':object,'json':json,'EvidenceError':g.AdmissionError,
        '_sha256_bytes':g.sha256,'_canonical':g.canonical,'PACKAGE_FORMAT':'R17V2C13FullRegressionEvidence-v1',
        'package_digest':lambda p:g.sha256(g.canonical(g.tree_index(p)).encode())}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(file),'exec'),ns)
    return ns['build_synthetic_package']


def reanchor(pkg):
    rr=read(pkg/'supervision/run_record.json')
    entries=[]
    for role,path in g.ROLE_PATHS.items():
        if role=='run_record':continue
        body=(pkg/path).read_bytes();sha=g.sha256(body)
        record=next(e for e in rr['required'] if e['role']==role)
        record.update(sha256=sha,bytes=len(body))
        entries.append({'role':role,'path':path,'sha256':sha,'size':len(body)})
    write(pkg/'supervision/run_record.json',rr)
    body=(pkg/'supervision/run_record.json').read_bytes()
    entries.append({'role':'run_record','path':'supervision/run_record.json','sha256':g.sha256(body),'size':len(body)})
    write(pkg/'required_files.json',{'entries':entries})
    ix=g.tree_index(pkg);ix.pop('manifest.json',None)
    write(pkg/'manifest.json',{'format':'R17V2C13FullRegressionEvidence-v1','files':ix})


@pytest.fixture
def eco(tmp_path):
    repo=tmp_path/'repo';deploy=tmp_path/'deploy';pkg=tmp_path/'work/full_regression/healthy_package'
    repo.mkdir()
    def git(*args):return g.git_checked(repo,*args).decode().strip()
    git('init','-q');git('config','user.email','test@example.invalid');git('config','user.name','synthetic')
    git('config','core.autocrlf','false')
    body=b'VALUE = 1\n';sha=g.sha256(body)
    put(repo/'stage2_6_1/runner/m.py',body);put(deploy/'stage2_6_1_runner/m.py',body)
    put(repo/'stage2_6_1/runner/r17_v2_c13_governance_source_lock.py',
        "MEMBER_MODULES = ('m',)\nSOURCE_SHA256 = "+repr({'m':sha})+'\n')
    tests={'stage2_6_1/tests/route_c_stage2_6_1/test_synth.py':b'def test_synth_0(): pass\ndef test_synth_1(): pass\ndef test_synth_2(): pass\n',
           'stage2_6_1/tests/test_root.py':b'def test_root(): pass\r\n'}
    for rel,data in tests.items():
        put(repo/rel,data);put(deploy/'tests/route_c_stage2_6_1'/Path(rel).name,data.replace(b'\r',b''))
    git('add','.');git('commit','-qm','real temporary candidate')
    c=git('rev-parse','HEAD')
    sources={'m':{'path':str(deploy/'stage2_6_1_runner/m.py'),'sha256':sha}}
    builder()(pkg,current_sources=sources,candidate_commit=c)
    # Explicitly add the candidate root-origin test to real XML and collection.
    xml=ET.fromstring((pkg/'junit.xml').read_bytes());suite=next(xml.iter('testsuite'));suite.set('tests','4')
    ET.SubElement(suite,'testcase',{'classname':'tests.route_c_stage2_6_1.test_root','name':'test_root','time':'0.001'})
    (pkg/'junit.xml').write_bytes(ET.tostring(xml,encoding='utf-8',xml_declaration=True))
    put(pkg/'collected_tests.txt',(pkg/'collected_tests.txt').read_text().replace('3 tests collected','tests/route_c_stage2_6_1/test_root.py::test_root\n4 tests collected'))
    put(pkg/'business.stdout.log','4 passed in 0.01s\n')
    mapped=g.candidate_test_map(repo,c)
    put(pkg/'test_files.sha256',''.join(r['deploy_sha256']+'  '+p+'\n' for p,r in mapped.items() if r['is_test']))
    ids={side:{'m':{'file':str(p),'sha256':sha}} for side,p in (
        ('release',repo/'stage2_6_1/runner/m.py'),('deploy',deploy/'stage2_6_1_runner/m.py'))}
    write(pkg/'import_identity.json',ids)
    meta=read(pkg/'run_meta.json');meta.update(release_repo=str(repo),deploy_root=str(deploy));write(pkg/'run_meta.json',meta)
    reanchor(pkg)
    return dict(repo=repo,deploy=deploy,pkg=pkg,candidate=c,git=git,sources=sources,work=tmp_path/'work')


def check(e,pkg=None):
    return g.package_semantics(pkg or e['pkg'],synthetic=True,full=True,
                               release_repo=e['repo'],deploy_root=e['deploy'],current_sources=e['sources'])


def test_real_full_semantic_layer_accepts_flattened_candidate(eco):
    before=g.tree_index(eco['pkg']);assert check(eco)==[];assert g.tree_index(eco['pkg'])==before


def test_resigning_all_outer_metadata_cannot_hide_removed_candidate_file(eco):
    e=eco;pkg=e['pkg'];rel='tests/route_c_stage2_6_1/test_root.py'
    (e['deploy']/rel).unlink()
    put(pkg/'test_files.sha256','\n'.join(s for s in (pkg/'test_files.sha256').read_text().splitlines() if rel not in s)+'\n')
    put(pkg/'collected_tests.txt','\n'.join(s for s in (pkg/'collected_tests.txt').read_text().splitlines() if rel not in s).replace('4 tests collected','3 tests collected')+'\n')
    xml=ET.fromstring((pkg/'junit.xml').read_bytes());suite=next(xml.iter('testsuite'));suite.set('tests','3')
    suite.remove(next(n for n in suite if n.get('name')=='test_root'))
    (pkg/'junit.xml').write_bytes(ET.tostring(xml));put(pkg/'business.stdout.log','3 passed in 0.01s\n')
    reanchor(pkg)
    keys={k for k,_ in check(e)}
    assert {'test_candidate_set_mismatch','test_execution_set_mismatch','test_file_set_changed'}<=keys


def test_full_semantics_survives_real_probe_export_git_e_and_e2(eco):
    e=eco
    assert check(e)==[]
    link=e['work']/exporter.ALLOWED_LINK;link.parent.mkdir(parents=True)
    link.symlink_to(e['pkg']/'supervision',target_is_directory=True)
    put(e['work']/'negative_cases/nested_directory_symlink/result.json','{"error":"non_regular_file"}\n')
    root=e['repo']/exporter.EVIDENCE_ROOT/'delivery'
    exporter.export_tree(e['work'],root)
    e['git']('add',exporter.EVIDENCE_ROOT);exporter.verify_staged(e['repo']);e['git']('commit','-qm','E exported')
    archived=root/'full_regression/healthy_package'
    assert g.tree_index(archived)==g.tree_index(e['pkg'])
    assert check(e,archived)==[]
    put(e['repo']/exporter.EVIDENCE_ROOT/'post_E/receipt.txt','full semantic PASS in synthetic ecosystem\n')
    e['git']('add',exporter.EVIDENCE_ROOT);exporter.verify_staged(e['repo']);e['git']('commit','-qm','E2 receipt')
    assert check(e,archived)==[]
    assert read(archived/'run_meta.json')['candidate_commit']==e['candidate']
    assert read(archived/'run_meta.json')['git_head_at_collect']==e['candidate']
