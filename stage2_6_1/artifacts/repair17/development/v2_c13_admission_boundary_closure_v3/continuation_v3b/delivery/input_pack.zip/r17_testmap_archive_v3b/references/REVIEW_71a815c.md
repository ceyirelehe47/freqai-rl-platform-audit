# R17 v3a 独立验收：V10 已修复，但整体 FAIL；测试来源映射与归档链各有一项阻塞

审查对象：`ceyirelehe47/freqai-rl-platform-audit`，分支 `route-c-stage2-6-1-repair17`。
本轮任务：`R17V2C13V10FixtureRepairAndVerificationResume-v3a`。

## 1. 提交身份

- 基线：`1ea193c0f1eb710e37aa23aa89f261617eb93c43`
- 代码候选 C：`16c45daeac0c934886157b2dbbff5509db8b7868`
- 证据提交 E：`82deed8677458dda7afc8e19c27b8148ab100699`
- 失败证据提交 E2 / 审查 HEAD：`71a815c676e484ff5b97dbd230a40923ff468ae5`

C 的补丁只修改 `stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_pipeline.py`：委托健康协议夹具，增加一项健康检查和四项拒绝 case。原 V10 的业务断言没有改成允许不健康输入。

C 和最新 HEAD 的三个 Git tree 相同：

| 子树 | Git tree |
|---|---|
| runner | a9041ae34ad143faab1b8ab87d6e006194952251 |
| src | 1b3e44f55021ed20e7aab2fc02e8c6bdfc736836 |
| tests | a1140a0e389de2141988d8c3e5e7b5fb51118292 |

这证明 C→E2 没有改源码/测试树，不证明整个证据交付合同通过。

## 2. 可保留的实际成果

八文件定向原始 stdout：`157 passed in 519.84s`。

第一轮全量 pytest 原始 stdout：`2063 passed, 7 skipped`，即 2070 cases；其证据 reader 因错误的源码路径映射返回 31 项错误。

第二轮 pytest 原始 stdout：`1825 passed, 7 skipped`，即 1832 cases；这是移出 31 个合法来源测试后的子集，不能接受为“完整 R17-first 回归”。

八项真实健康包副本负例的 summary 记录全部拒绝于期望层。该结果可以保留，但它没有覆盖“按现有同步规则找到根目录测试来源”和“负例产物能安全进入 Git 归档”两项场景。

旧 v3 的 V10 缺陷修复可按限定范围接受；v3a 的整体工程合同仍为 FAIL。新统计 NOT_RUN；正式资格 NOT_ISSUED。

## 3. 阻塞 A：31 个合法测试被误认为陈旧文件，1832 项不是完整套件

### 3.1 与报告相反的 Git 事实

Agent 报告称 31 个隔离文件从未被本仓库跟踪。实际在 C 的 `stage2_6_1/tests/` 根目录中，全部 31 个文件已经存在；它们不在嵌套的 `stage2_6_1/tests/route_c_stage2_6_1/` 下。

C 的 tests 根 Git tree：`a1140a0e389de2141988d8c3e5e7b5fb51118292`。
隔离副本 files Git tree：`c794908951ff36a43af5a60bcd8a5d077c88d94b`。
两者对照，27 个文件的 Git blob 完全相同。四个 r7 文件 blob 不同；本次没有下载其完整字节独立验证归一化，因此不把它们写成“已逐字节验证同源”。所有 31 个同名源文件在 C 被跟踪这一点不受影响。

例：`test_curriculum261_r4_namespaces.py` 的源文件和隔离副本均为 blob：
`24684ddb562fb95e429ebeb60a3f79d1451ddaf0`。

### 3.2 同步合同被 verifier 错误解释

现存 `stage2_6_1/runner/r17_sync.sh` 的实际行为：

```bash
find "$R/stage2_6_1/tests" -name '*.py' | while read -r f; do
  tr -d '\r' < "$f" > "$D/tests/route_c_stage2_6_1/$(basename "$f")"
done
```

它递归遍历整个 tests 源树，按 basename 平铺，并删除 CR 字节。因此根目录的这 31 个文件本来就应出现在部署测试目录中。

v3 guard 的 `package_semantics` 却把每个部署路径直接拼为：

```text
candidate:stage2_6_1/tests/route_c_stage2_6_1/<basename>
```

正确的根目录来源因此被误查为不存在。第一轮 `verify_C.json` 的 31 项原始错误正是 `git show` 错路径返回 128，而不是内容 SHA 已确认不同。

此外，该循环只检查 manifest 中已有的测试，没有从 C 的完整测试源树反推必须存在的部署集合。于是删去这些部署文件及 manifest 项后，reader 没有发现少测了合法候选文件。

### 3.3 独立本地复现

`probe_current_guard.py` 载入与当前远端 Git blob 完全相同的 guard，不改其函数。临时 Git 生态中有一个嵌套测试和一个根目录测试：

- 两个合法测试都按同步规则平铺、登记：实际 `package_semantics(... full=True)` 误报根目录测试来源不存在。
- 不改候选源树，只移除部署根目录测试及 manifest 项：同一函数返回空错误列表。

这是实际 guard 的 full 语义层复现，不是完整 WSL CLI，也不冒称新的项目回归。

### 3.4 修复范围

只修测试来源消费规则，不删除合法测试来迁就 checker：

1. 以候选 Git tree 递归枚举测试源文件。
2. 按现存同步行为形成源路径→部署 basename→同步后字节的映射。
3. 同 basename 多来源必须 fail-closed，不任意选第一个，也不能靠模糊 fallback 规避。
4. 从候选反推期望集合，并对齐 manifest、部署文件和执行 collection；缺项、额外项、重复项均拒绝。
5. 正确建模 `tr -d '\r'`；保留 Git 原字节 hash 与同步后 hash 的区别。
6. 先执行该映射预检，再启动完整 pytest。不得再在跑完几十分钟后才发现来源位置不一致。

31 个文件的隔离副本保留。部署恢复从已核对的仓库来源与既有同步步骤完成，不盲目覆盖未知本地改动。`never_tracked_proof.txt` 的空输出不能证明整个仓库从未跟踪这些 basename。

## 4. 阻塞 B：真实负例 symlink 与归档指令自相矛盾

负例脚本创建了 `nested_directory_symlink/package/symlink_directory`；Runbook 使用 `cp -a` 保存全部 WORK 内容，连同该 symlink 进入 E。

当前 Git tree 中该路径确实是：

```text
mode = 120000
type = blob
blob = f9698610336a33bd12c48e72ec96f2ec0bb38b4f
```

`verify_candidate_history` 对 C..HEAD 的每个中间提交检查：新证据只能是 100644/100755 普通 blob。它拒绝 120000，符合现有合同。

提交后的真实错误：

```text
candidate_drift: evidence is not a regular Git blob
```

健康包在 C 时与 E 后的 digest 都是：
`1306dac459109e504f3575a0943b2434ec932b852c1d0bd240109a327786108e`。
因此已发现的这一失败是 Git 交付链的文件类型不合规，不是该健康包的原始日志在提交时发生变化。

这是助手提供的负例输出与归档步骤的组合缺陷。不能靠放宽生产 reader 接受 symlink 解决，也不能把拒绝判成统计失败。

### 修复方向

- 负例在独立临时 WORK 中保留真实 symlink，用来执行拒绝测试。
- 入库时保留原结果、命令、recipe，以及普通文件形式的 symlink 描述（原相对路径、目标、类型、相关摘要）；不把真实链接本身变成可跟随的交付成员。
- 不用 `cp -L` 跟随链接；不把负例副本包装成健康 evidence。
- 健康包的实际字节不改。
- commit/push 前检查暂存区 Git mode，禁止 120000/160000 与其他非普通对象。
- 必须本地走通“负例生成→安全归档→Git commit→实际 history checker”，不能只测各工具分开绿。

本地使用实际 `verify_candidate_history` 复现：普通证据提交可通过；增加 symlink 后拒绝；之后只增加新目录仍然拒绝。

## 5. 不要误用“换新目录即可恢复”

当前 reader 扫描 C..HEAD 的所有中间提交。E 中已有不合规 symlink，追加新目录并不会移除旧 E；删除或类型替换又会触发既有历史守卫。

保留 C、E、E2 及失败原件。下一轮有真实必要的测试映射代码修复，可以建立新的实际源码候选，并在该候选上取得完整回归和合规交付。不能只做空提交或修改旧 run_meta 的 candidate 字段来伪造新的运行身份。

由于 verifier 源码会改变，一次正确绑定新候选的完整回归是必要验证，而不是为 evidence-only 提交重复跑全量。之后 E 的收尾只做只读 full 冷验。

## 6. 三层结论与边界

| 对象 | 结论 |
|---|---|
| V10 夹具修复 | 限定范围通过，保留 |
| 八文件定向 | 157 passed；保留 |
| 2070 项首次 pytest | 原始日志绿色；来源 reader 误拒，尚无完整交付验收 |
| 1832 项第二次 pytest | 子集绿色，不承认为完整回归 |
| v3a 归档与最新 HEAD full 冷验 | FAIL |
| v3a 工程整体 | FAIL |
| 本轮新统计 | NOT_RUN |
| 正式资格 | NOT_ISSUED |

不重跑旧 v2 主实验；不新建生产 plan/receipt/claim；不启动 C2 正式校准或训练；不扩展 monitor、V2、R4/R5、C2 selector 的既有修复面。

## 7. 审查与复现范围

独立读取了当前 ref、代码提交差分、C/HEAD 子树、根目录测试和隔离副本 Git 元数据、同步脚本、关键原始 stdout、pre/post-E verifier JSON、负例 summary 和失败归档。没有重新执行用户 WSL 全量 pytest，也没有声称独立重算了所有归档文件的 SHA。

本地探针：Linux / Python 3.13.5；准确 guard blob `cae6f602e92773cf45da17609783c0ec73284b78`，SHA-256 `daf603e6a4ca207373f3034ed518a32535810cc327dce356f075244bba0d3a04`。探针只写临时 Git 生态，不触碰生产目录，不调用 generation/fit/eval/claim。

本包是独立审查与复现材料，不是下一轮生产修复补丁，也不授权 Agent 自行放宽规则。
