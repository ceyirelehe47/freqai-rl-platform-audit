# 四文件应用面及外部工具

基线：`71a815c676e484ff5b97dbd230a40923ff468ae5`。

| 路径（均在 stage2_6_1 下） | 原 Git blob | 修改 |
|---|---|---|
| runner/r17_v2_c13_admission_guard.py | cae6f602e92773cf45da17609783c0ec73284b78 | 候选递归 test map、完整集合及字节绑定 |
| runner/r17_v2_c13_governance_source_lock.py | db723cac4e1b3d6626def62458d94b8b1fcb5812 | 仅更新 guard 摘要，10成员不变 |
| tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_admission_guard.py | 2985be4ab82ed12b3f3b253fe5880ab2f5f79c40 | 追加21case |
| tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_regression_evidence.py | 5b30d919eef347d17d65be442b43abd847eaacb2 | full_eco 合成夹具源/JUnit一致，测试断言不变 |

不修改：profile、pipeline、batch、regression_evidence生产模块、r17_sync、sampler/monitor、C2 selector、任何科学模块、V10测试文件。历史 r17_v2_c13_source_lock.py 不动。

外部工具只存包工作区，最终可作为普通文件入新的证据目录：

- test_mapping.py：pre-sync source-only、pre-C worktree diagnostics、post-C candidate mapping。
- archive_evidence.py：安全导出、导出对拍、暂存区门禁。只允许既定负例链接转惯性记录，不放宽生产 reader。
- run_targeted.sh / check_targeted_junit.py：八文件定向，强制新的21case。
- run_bound_regression.sh：候选完整源map→R17-first收集→监护全量→原collector→实际full验证。
- probe_evidence.py：健康包副本10负例。
- protected_snapshot.py：旧artifact lstat/readlink/字节只读快照，排除本轮新continuation_v3b。

旧保护区：development 下的工程 v1/v2 delivery、postrun_governance、C2 launch prep、工程 claim、governance_authority_evidence_closure_v2、admission_boundary_closure_v3 旧部分。run_supervision 活动追加单独记录，不能清理或并入代码提交。

新证据布局：

- continuation_v3b/delivery/：一次封存的导出；内含新WORK原件和导出元数据。
- continuation_v3b/post_E/：提交E后的冷读原件，只新增。

不要在旧 continuation_v3a 下补写新结果；不要改旧 REPORT/SHA256SUMS、旧 symlink 或旧 Git mode。
