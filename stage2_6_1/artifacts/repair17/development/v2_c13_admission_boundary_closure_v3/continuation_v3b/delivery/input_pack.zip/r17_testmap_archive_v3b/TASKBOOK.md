# R17 Test Source Map / Safe Evidence Export v3b

任务 ID：`R17V2C13TestSourceMapAndEvidenceExportClosure-v3b`

## 1. 接手身份与状态

固定仓库/分支：`ceyirelehe47/freqai-rl-platform-audit` / `route-c-stage2-6-1-repair17`。固定 HEAD：`71a815c676e484ff5b97dbd230a40923ff468ae5`。

历史链：`1ea193c…`（v3 定向失败）→ `16c45da…`（V10 修复 C）→ `82deed8…`（v3a E）→ `71a815c…`（提交后冷验 FAIL）。全部保留。本轮不是旧运行恢复，也不重新解释旧失败为 PASS。

可保留：V10 单文件修复；157 项八文件定向绿色；已有 authority/claim 加固；原 R4/R5、C2、sampler 实现。

必须纠正：

1. 上轮 31 个测试是候选根目录中的合法受跟踪源文件，原 reader 错查嵌套路径。第一次 2070 个 case 测试绿色，但证据来源验证误拒；第二次 1832 个 case 是移除 238 个 case 后的子集，不能当作完整回归。
2. 特殊文件负例创建真实 symlink 后，被通用 `cp -a` 带入 E，违反原 evidence-only 普通 blob 约束。旧 C→HEAD 链在旧规则下仍失败；换目录不能追认它。

## 2. 授权边界

本轮允许：给定四文件补丁；部署同步及完整源映射检查；既有八文件定向；候选 C 上一次完整 R17-first pytest；临时副本负例；安全归档；新 C/E/E2 普通提交、普通 push。

不允许：新主实验生成、业务 V2 fit、scaled/canonical/policy 运行、生产 preclaim/plan/receipt/claim 写入、C2 namespace 或正式校准、qualification/exposure、新 BC/PPO 训练。

原有 pytest 在临时测试上下文中使用的合成数据、数值组件和既有短 smoke 按原测试运行，不是本轮新业务实验。不要把“无新主实验/生产写入”伪报为已逐函数测得所有 pytest 内 generator/fit 调用绝对为零。

不得修改、缩小或跳过失败测试以换绿色。不得再次隔离这 31 个合法文件。未知同名冲突、非候选 Python 文件或字节失配应停止并保留路径映射证据，不自行放宽。

## 3. 实现与修改面

四个现有文件：

- `runner/r17_v2_c13_admission_guard.py`：候选 Git 递归映射、精确 CR 删除、文件名冲突拒绝、完整部署/清单/执行文件集合检查。原 authority、claim 约束、history 规则未放宽。
- `runner/r17_v2_c13_governance_source_lock.py`：仅更新实际改动 guard 的摘要；其余九成员及成员集不变。不是历史 `r17_v2_c13_source_lock.py`。
- `tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_admission_guard.py`：追加 21 个映射行为 case，原测试保留。
- `tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_regression_evidence.py`：只调整 full_eco 合成夹具，让临时 Git、部署、JUnit、collection 都包含它实际承载的三个 test_synth case；原测试断言不变，不给 synthetic full verification 开例外。

`tools/archive_evidence.py` 等运行在包外工作区。它们不是另一个生产准入 reader，不替代项目 `verify_package()`。生产 verifier 仍由实际部署模块执行。

## 4. S0–S2：接手、应用、恢复正确部署、定向

S0：fetch 后精确核对 HEAD、branch、源/测试/config clean、index empty。已知 run_supervision 活动追加只记录，不清理、不混入提交。远端前进或未知修改则停止，不 reset/rebase/stash。

保存原 artifact 区的类型/字节快照。旧 symlink 使用 lstat/readlink 记录，不跟随。历史 lock SHA 必须是 `c9152b62192a93571c16ba62e0ef2e70522f108726f3eb83fd25d48007a77c55`。

S1：`apply_patch.py` 先 check，后 `--apply --recovery`。恢复目录在发布库外。输出恰好四个文件；失败不自动回滚。不运行 relock 工具覆盖给定结果。

S2：在同步前使用包内实现做 source-only/worktree 诊断，检测完整 Git 源集合与冲突；然后运行既有 `r17_sync.sh`，从当前源树恢复 31 个合法根目录测试；再由实际部署 guard 核对工作树诊断映射。

当前基线有 31 个根目录和 98 个嵌套目录测试，合计 129 个测试文件；本补丁只追加到已有文件，不增加文件数。最终权威为 Git 递归源集合，不是为凑数字删文件。预期的规范化规则为 `data.replace(b'\r', b'')`，不是只替换 CRLF。

运行本包 57 项快速检查并归档其独立范围，然后运行八文件定向。预计 178 case（157+21），必须零 failure/error/skip/xfail；checker 强制 21 个新增映射 case 和保留的 V10 核心 case 被执行。总体数只作诊断，不能据此修改收集结果。

## 5. S3–S4：新代码候选与完整回归

定向通过后普通 commit 四文件为新 C（实质代码改动），同步部署，保存实际 __file__/SHA/source_guard 和候选 test map。不要携带运行证据进代码提交。

新候选的完整回归只跑一次：脚本在 collect/pytest 之前就从 C 的 Git tree 建立全部 Python 源文件到部署文件的映射，检查源与部署集合及内容；从该映射选定全部 `test_*.py`，R17 优先，其余按路径排序。`PYTEST_ADDOPTS` 必须为空，不加 `-k/-m/--deselect`。

完整回归包含恢复后的 31 文件。预计总数约 2091（旧完整 2070+新增21），不把该数字当替代完整源集合的凭据。7 个历史 skip 继续按源码固定白名单核对；本轮 critical 不得 skip。

保留 entry 命令/rc/stdout/stderr、business、JUnit、collection、test_files、source/import、两次映射、required/native 原件。回归后 `source_before==source_after`、`test_mapping_before==test_mapping_after`。collector 与实际 `verify_package(full)` 都必须通过。

若完整回归或证据层失败：停止，不再通过隔离受跟踪文件修环境、不改旧日志、不重签伪造摘要；提交真实失败，交回助手处理。

## 6. S5：实际健康包负例

`probe_evidence.py` 只读健康包，在独立副本中执行 10 个负例：旧八类，加“移除合法根目录来源的 manifest 成员”和“重复测试 manifest 成员”。各例必须被拒绝且包含其预期错误键。原健康包前后字节不变。

“部署和 manifest/JUnit 同时移除文件仍拒绝”通过项目新增21 case及包内真实 full 语义临时 Git 生态测试验证；真实 WSL negative probe 不去删除生产部署文件来制造此情形。

`nested_directory_symlink` 继续实际创建链接并调用真实 reader 拒绝，不能改成只写一个模拟错误。

## 7. S6：安全导出与提交前模式检查

必须使用 `archive_evidence.py export` 从新 WORK 导出到 `continuation_v3b/delivery/`。禁止通用 `cp -a` 或 `cp -L` 归档整个 WORK；前者发布链接，后者解引用并篡改证据语义。

导出器：

- 先完整 lstat 检查输入，普通文件逐字节复制；不删除/改写 WORK；链接目标绝不被读取。
- 仅允许既定 symlink 负例的特殊路径。把原类型、原相对路径、原始 readlink 字节的 base64/size/SHA 写入普通 `_LINK_RECORDS/*.json`。原链接路径在交付中不存在；原负例结果及其他普通字节不变。
- 未授权 symlink/FIFO/device/socket、路径逃逸、符号链接父路径全部拒绝。失败输出不得作为完整导出使用。
- `_ARCHIVE_MANIFEST.json` 明确列出源 inventory 和导出普通文件对应关系，不伪称导出是字节同构的链接目录。

导出后运行独立 verify 并与仍保留的 WORK 对拍；检查旧保护区。报告在导出前写成“等待提交后冷验”，不能提前 PASS。

暂存时只 add 新 v3b 子根。`archive_evidence.py staged` 必须确认所有暂存变化为该根内新文件、Git mode 为100644/100755、无 gitlink/120000/冲突、暂存字节与工作树一致。任何 M/D/T、域外变化均拒绝。本轮无需修改 `.gitattributes`，沿用既有父根 -text 规则。

## 8. S7：E/E2 冷验与推送

先**本地普通提交** E，不立即 push。在真实发布库 HEAD=E，对 `delivery/full_regression/healthy_package` 调用实际项目 full verifier，并检查 rc=0/ok=true/scope=full。无 authority 的审查 CLI 中 `admission_eligible=false` 是正确的，它不等于业务准入授权。

把这次 E 冷验的命令、stdout/stderr/rc和结果写入仓库外的单独目录；作为 `continuation_v3b/post_E/` 新增原件形成 E2。不要往已经封存的 delivery/ 添加或更改内容，也不覆盖其 manifest。然后在 E2 上再次做只读 full 验证，输出留在仓库外，不继续无限补 E3。

C..E..E2 必须被未放宽的实际历史规则接受。最后普通 push；远端 ref 必须等于最终本地 HEAD。不能 amend/force/rebase。若 E 后失败，保留失败原件，按 FAIL 交付，不删链接重写历史，不回填旧包的 candidate。

## 9. 最终判定

只有完整执行以上步骤、矩阵全过、旧保护区不变、新证据普通文件发布闭合，才可给本轮工程 PASS。

首页必须分别报告：

- 本轮测试映射/归档工程 PASS/FAIL；新 C/E/E2。
- 定向实际计数；完整测试文件数、全部case数、pass/skip/fail；根目录来源31个是否全部存在并执行。
- full 冷验 C/E/E2 各自真实结果；旧 C→HEAD 仍不追认。
- 本轮新业务统计 NOT_RUN；正式资格 NOT_ISSUED；C2/新训练 NOT_STARTED。
- 新主实验/生产 claim/plan/receipt/admission/namespace 写入未获授权且未发生；测试内操作与业务预算分开。
- 历史保护快照，旧31文件误判的更正，所有失败 attempt 永久保留。
