# R17 v3b：代码补丁与实机验收包

**任务**：`R17V2C13TestSourceMapAndEvidenceExportClosure-v3b`  
**仓库**：`ceyirelehe47/freqai-rl-platform-audit`  
**分支**：`route-c-stage2-6-1-repair17`  
**固定应用基线**：`71a815c676e484ff5b97dbd230a40923ff468ae5`

先读：本文件 → TASKBOOK.md → SOURCE_MAP.md → RUNBOOK.md → ACCEPTANCE_MATRIX.md。

这是助手已实现的**代码补丁 + 验收脚本**，不是让 Agent 再设计实现的任务书。只应用本包，不再应用旧 v3/v3a；应用器没有自动同步、提交或推送动作。

本轮一次完成：修正递归候选测试源到平铺部署的映射，阻止“从部署及清单同时去掉受跟踪测试”的假完整回归，恢复 31 个合法根目录来源测试，安全归档特殊文件负例，完成新候选 C → E → E2 的真实提交后冷验。

## 已固定的处理方向

- 31 个测试在候选的 `stage2_6_1/tests/` 根目录，不能继续标为“未跟踪陈旧文件”。使用候选 Git 对象及现有 `r17_sync.sh` 的递归、basename、删除全部 CR 字节规则；同名/大小写冲突拒绝。
- 不修改 V10 夹具修复、生产 authority/claim、R4/R5 科学数学、C2 selector、monitor/sampler。
- 特殊文件负例在临时目录真实执行；只有普通文件的描述和原始结果进入交付。禁止再次用 `cp -a "$WORK"/. "$AR"/` 发布证据。
- 不为过旧 C 改历史例外。旧 C→E 中的 120000 仍被原规则拒绝。本轮有真实 guard 改动，生成新候选并跑一次新完整回归；不得把旧 run_meta 的 candidate 改成新 C。

## 本包交付内容

`implementation/`：完整的新 guard 源码。  
`payload/`：测试新增和映射实现原文。  
`tools/apply_patch.py`：按四个精确 Git blob 校验/应用，唯一写面四个已有文件。  
`tools/test_mapping.py`：collect/pytest 前检测完整源、部署及规范化字节。  
`tools/archive_evidence.py`：不跟随链接的安全导出、导出核验、Git 暂存区模式门禁。  
`tools/run_targeted.sh`、`run_bound_regression.sh`、`probe_evidence.py`：给定实机运行脚本。  
`tests/`：57 项本包测试；不是用户项目全量回归。  
`local_validation/`：助手 Linux / Python 3.13.5 实测原件。没有声称完成用户 WSL 回归。

新证据只写：

`stage2_6_1/artifacts/repair17/development/v2_c13_admission_boundary_closure_v3/continuation_v3b/`

旧 v3/v3a 报告、失败运行、claim、source lock 原件不改；本轮新报告单独更正上轮“31 个未跟踪文件”的错误结论。
