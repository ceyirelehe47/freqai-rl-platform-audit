#!/usr/bin/env bash
# Small standalone checks; NOT the project regression or an admission certificate.
set -euo pipefail
PACK=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
OUT=${1:?fresh external output required}
[[ $OUT == /* && ! -e $OUT && ! -L $OUT ]] || exit 2
mkdir -p "$OUT"
cd "$PACK"
set +e
PYTHONDONTWRITEBYTECODE=1 python -m pytest -q -p no:cacheprovider "$PACK/tests" \
 --junitxml="$OUT/junit.xml" > "$OUT/stdout.log" 2> "$OUT/stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$OUT/rc.txt"
python -VV > "$OUT/python.txt" 2>&1
git --version > "$OUT/git.txt"
exit "$RC"
