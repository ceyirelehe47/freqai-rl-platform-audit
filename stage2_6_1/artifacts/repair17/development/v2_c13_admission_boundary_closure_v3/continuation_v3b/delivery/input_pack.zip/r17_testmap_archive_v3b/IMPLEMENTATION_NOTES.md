# 实现与验证范围

## 已实现

实际运行guard基于 `71a815c…` 的精确 blob `cae6f602e92773cf45da17609783c0ec73284b78`。完整新模块在implementation下，应用器不用模糊替换版本。

新增 `candidate_test_map()` 以Git对象递归确定Python源，显式记录raw blob、raw SHA、规范化SHA及真实源路径。`verify_candidate_tests()`双向检查候选、部署、manifest、collection/JUnit文件和case多重集合；旧“部署路径加stage2_6_1前缀”逻辑已经移除。现有authority、history、JUnit安全逻辑没有删除或改宽。

外部安全导出器先检查整个WORK的文件类型，只允许既定symlink负例特殊路径。用readlink保留目标字节，不打开目标；入库是普通描述文件，不再入库链接对象。普通文件用O_NOFOLLOW非阻塞描述符读取，检查读取前后identity；FIFO等在读取前拒绝。导出原件和对照manifest有独立readback。

暂存检查不仅看已add的文件，还检查整个新证据树与Git index集合，避免被.gitignore漏掉的stdout/native原件在本机存在却没提交。E先本地提交，实际full冷验通过再发布，避免推送之后才发现工作流冲突。

## 本地实测与未实测

已在Linux / Python3.13.5运行本包57项测试（原始stdout/stderr/JUnit/rc在local_validation）。涵盖：21个将追加到项目的映射case、26个安全导出/真实暂存提交测试、4个应用器/历史不变性测试、3个实际guard full语义测试、3个preflight测试。

其中full语义测试直接执行将交付的 `package_semantics(full=True)`，使用真实临时Git仓库、源/部署文件、实际XML/collection和原v3合成包构造函数；完整演练负例链接→普通导出→Git E→E2→full语义读取，不用返回固定PASS的替代guard。合成包格式明确synthetic，不能用于生产准入。

**没有在助手环境取得完整仓库checkout，也没有运行用户WSL全项目、原collector CLI、生产source_guard十成员导入或2070/2091量级pytest。** 应用器对完整目标文件的实际改写、八文件定向、129文件完整回归、真实监护/native封口及发布后fullCLI均由Agent按给定脚本验证。不能用57个包级测试替代这些检查。

应用器的full_eco变更通过精确blob前置检查+函数边界定位；只改夹具输入构造，并自动比较原test_*函数源码不变。没有转交设计工作，但发生未覆盖的实机错误仍须保留FAIL，不允许Agent自行弱化要求。

## 历史处理

旧v3/v3a失败及1832项子集报告不回填。不修改旧C→E的history规则。新C包含真实guard修复，因此应重新跑一次完整回归；不能将旧包改个candidate字段复用。根目录31测试从当前受跟踪源同步，旧隔离目录只读保留。

归档工具为工作区工具，不是新增生产reader：最终准入边界仍为项目本身的full verifier。无生产authority的审核CLI返回admission_eligible=false是预期，工程验证通过不签正式资格。
