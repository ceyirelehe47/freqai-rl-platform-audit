from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import pytest
import archive_evidence as a
import r17_v2_c13_admission_guard as g


def put(p, data=b'evidence\n'):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)

def init_repo(p):
    p.mkdir()
    def git(*args):
        return a.git(p, *args)
    git('init', '-q'); git('config', 'user.email', 'test@example.invalid')
    git('config', 'user.name', 'R17 export test'); git('config', 'core.autocrlf', 'false')
    put(p / 'stage2_6_1/runner/model.py', b'VALUE = 1\n')
    git('add', '.'); git('commit', '-qm', 'C')
    return git, git('rev-parse', 'HEAD').decode().strip()


def healthy_source(root):
    put(root / 'full_regression/healthy_package/result.json', b'{"ok":true}\n')
    put(root / 'negative_cases/nested_directory_symlink/result.json', b'{"ok":false,"error":"non_regular_file"}\n')
    path = root / a.ALLOWED_LINK; path.parent.mkdir(parents=True, exist_ok=True)
    target = root / 'negative_cases/nested_directory_symlink/package/supervision'
    put(target / 'run_record.json', b'{"fixture":true}\n')
    path.symlink_to(target, target_is_directory=True)
    return root


def test_export_symlink_as_inert_record_without_following(tmp_path):
    source = healthy_source(tmp_path / 'work'); out = tmp_path / 'out'
    before = a.inventory(source, permit_probe_link=True)
    result = a.export_tree(source, out)
    assert result['inert_symlink_records'] == 1
    assert a.inventory(source, permit_probe_link=True) == before
    assert not os.path.lexists(out / a.ALLOWED_LINK)
    assert all(r['kind'] in ('regular', 'directory') for r in a.inventory(out).values())
    assert (source / a.ALLOWED_LINK).is_symlink()
    assert a.verify_export(out, source=source)['ok']


def test_entire_export_stage_commit_history_cold_read_sequence(tmp_path):
    repo = tmp_path / 'repo'; git, c = init_repo(repo)
    source = healthy_source(tmp_path / 'work')
    dest = repo / a.EVIDENCE_ROOT / 'delivery'
    a.export_tree(source, dest)
    git('add', a.EVIDENCE_ROOT)
    staged = a.verify_staged(repo)
    assert staged['ok'] and all(x['mode'] in ('100644','100755') for x in staged['checked'])
    git('commit', '-qm', 'E regular-only evidence')
    result = g.verify_candidate_history(repo, c, c)
    assert result['source_test_trees_unchanged']
    assert a.verify_export(dest, source=source)['ok']
    put(repo / a.EVIDENCE_ROOT / 'post_E' / 'receipt.json', b'{"ok":true}\n')
    git('add', a.EVIDENCE_ROOT); a.verify_staged(repo)
    git('commit', '-qm', 'E2 cold read receipt')
    assert len(g.verify_candidate_history(repo, c, c)['evidence_descendants']) == 2


@pytest.mark.parametrize('kind', ['dangling', 'outside', 'self'])
def test_allowed_probe_target_is_never_followed(tmp_path, kind):
    source = tmp_path / 'work'; link = source / a.ALLOWED_LINK
    link.parent.mkdir(parents=True)
    if kind == 'outside':
        target = tmp_path / 'private'; put(target, b'NEVER COPY THIS')
    elif kind == 'self':
        target = link.parent
    else:
        target = tmp_path / 'missing'
    link.symlink_to(target)
    out = tmp_path / 'out'; a.export_tree(source, out)
    assert a.verify_export(out)['ok']
    assert b'NEVER COPY THIS' not in b''.join(p.read_bytes() for p in out.rglob('*') if p.is_file())


@pytest.mark.parametrize('path', ['healthy_package/link','unexpected/link','negative_cases/other/link'])
def test_unapproved_symlink_fails_before_any_export_write(tmp_path, path):
    source=tmp_path/'source'; link=source/path; link.parent.mkdir(parents=True)
    link.symlink_to(tmp_path/'nope')
    out=tmp_path/'out'
    with pytest.raises(a.ExportError, match='special object'):
        a.export_tree(source,out)
    assert not out.exists()


def test_fifo_fails_without_blocking_or_dereferencing(tmp_path):
    source=tmp_path/'source';source.mkdir();os.mkfifo(source/'pipe')
    with pytest.raises(a.ExportError, match='special object'):
        a.export_tree(source,tmp_path/'out')
    assert not (tmp_path/'out').exists()


@pytest.mark.parametrize('case', ['existing','overlap','parent_symlink','reserved'])
def test_export_path_safety(tmp_path,case):
    source=tmp_path/'source';put(source/'evidence')
    out=tmp_path/'out'
    if case=='existing':out.mkdir()
    elif case=='overlap':out=source/'out'
    elif case=='parent_symlink':
        real=tmp_path/'real';real.mkdir();(tmp_path/'alias').symlink_to(real);out=tmp_path/'alias/out'
    else:put(source/a.MANIFEST)
    with pytest.raises(a.ExportError):a.export_tree(source,out)


@pytest.mark.parametrize('mutation', ['append','extra','link','descriptor','source_change'])
def test_export_readback_rejects_mutation(tmp_path,mutation):
    source=healthy_source(tmp_path/'work');out=tmp_path/'out';a.export_tree(source,out)
    if mutation=='append':
        p=out/'full_regression/healthy_package/result.json';p.write_bytes(p.read_bytes()+b' ')
    elif mutation=='extra':put(out/'extra')
    elif mutation=='link':
        (out/'alias').symlink_to(source)
    elif mutation=='descriptor':
        p=next((out/a.LINKS).glob('*.json'));p.write_bytes(b'{}')
    else:put(source/'later')
    with pytest.raises(a.ExportError):a.verify_export(out,source=source)


@pytest.mark.parametrize('mutation', ['symlink','outside_root','modified_old','gitlink','filtered_bytes'])
def test_staged_gate_rejects_before_commit(tmp_path,mutation):
    repo=tmp_path/'repo';git,c=init_repo(repo)
    root=repo/a.EVIDENCE_ROOT
    if mutation=='symlink':
        root.mkdir(parents=True);(root/'link').symlink_to('/does-not-exist');git('add',a.EVIDENCE_ROOT)
    elif mutation=='outside_root':put(repo/'outside.txt');git('add','outside.txt')
    elif mutation=='modified_old':put(repo/'stage2_6_1/runner/model.py',b'VALUE=2\n');git('add','.')
    elif mutation=='gitlink':
        git('update-index','--add','--cacheinfo','160000',c,a.EVIDENCE_ROOT+'/submodule')
    else:
        put(root/'record',b'one');git('add',a.EVIDENCE_ROOT);put(root/'record',b'two')
    with pytest.raises(a.ExportError):a.verify_staged(repo)


def test_old_bad_e_remains_failed_even_if_new_directory_added(tmp_path):
    repo=tmp_path/'repo';git,c=init_repo(repo)
    p=repo/g.NEW_EVIDENCE_ROOT/'old/link';p.parent.mkdir(parents=True);p.symlink_to('/not-found')
    git('add','.');git('commit','-qm','bad old E')
    put(repo/a.EVIDENCE_ROOT/'new.txt');git('add','.');git('commit','-qm','new dir only')
    with pytest.raises(g.AdmissionError,match='not a regular Git blob'):
        g.verify_candidate_history(repo,c,c)


def test_current_candidate_can_preserve_prior_failed_evidence_unchanged(tmp_path):
    repo=tmp_path/'repo';git,old=init_repo(repo)
    p=repo/g.NEW_EVIDENCE_ROOT/'old/link';p.parent.mkdir(parents=True);p.symlink_to('/not-found')
    git('add','.');git('commit','-qm','old failed E')
    # A genuine new code candidate, not relabeling a prior run's candidate.
    put(repo/'stage2_6_1/runner/model.py',b'VALUE=2\n');git('add','.');git('commit','-qm','new corrected code C')
    c=git('rev-parse','HEAD').decode().strip()
    put(repo/a.EVIDENCE_ROOT/'new-report.json');git('add','.');git('commit','-qm','new E')
    assert g.verify_candidate_history(repo,c,c)['source_test_trees_unchanged']
    with pytest.raises(g.AdmissionError):g.verify_candidate_history(repo,old,old)


def test_staged_gate_detects_ignored_evidence_not_added(tmp_path):
    repo=tmp_path/'repo';git,c=init_repo(repo)
    put(repo/'.gitignore',b'*.log\n');git('add','.gitignore');git('commit','-qm','fixture ignore policy')
    root=repo/a.EVIDENCE_ROOT
    put(root/'report.json',b'{}');put(root/'required.log',b'original evidence')
    git('add',a.EVIDENCE_ROOT)
    with pytest.raises(a.ExportError,match='member set differs'):
        a.verify_staged(repo)
    git('add','-f',a.EVIDENCE_ROOT)
    assert a.verify_staged(repo)['no_ignored_files_missing']
