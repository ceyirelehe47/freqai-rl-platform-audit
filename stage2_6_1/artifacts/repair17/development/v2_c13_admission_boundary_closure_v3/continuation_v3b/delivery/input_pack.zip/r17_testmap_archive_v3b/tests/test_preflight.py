import pytest
# Avoid importing the similarly named tests.test_mapping module through this name.
import importlib.util
from pathlib import Path
import r17_v2_c13_admission_guard as guard
from tests.test_mapping import v3b_test_ecology

spec=importlib.util.spec_from_file_location('mapping_cli',Path(__file__).resolve().parents[1]/'tools/test_mapping.py')
cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)


def test_preflight_rejects_missing_deployment_before_any_test(v3b_test_ecology):
    e=v3b_test_ecology
    (e['deploy']/'tests/route_c_stage2_6_1/test_root.py').unlink()
    with pytest.raises(guard.AdmissionError,match='preflight rejected'):
        cli.check_mapping(guard,e['repo'],e['deploy'],e['candidate'])
    assert cli.check_mapping(guard,e['repo'],e['deploy'],e['candidate'],source_only=True)['deployment_checked'] is False


def test_preflight_distinguishes_worktree_diagnostic_from_candidate(v3b_test_ecology):
    e=v3b_test_ecology
    src=e['repo']/'stage2_6_1/tests/test_root.py';src.write_bytes(src.read_bytes()+b'# patched\n')
    (e['deploy']/'tests/route_c_stage2_6_1/test_root.py').write_bytes(src.read_bytes().replace(b'\r',b''))
    with pytest.raises(guard.AdmissionError,match='release normalized'):
        cli.check_mapping(guard,e['repo'],e['deploy'],e['candidate'])
    result=cli.check_mapping(guard,e['repo'],e['deploy'],e['candidate'],worktree=True)
    assert result['scope']=='worktree_diagnostic_only' and not result['admission_eligible']


def test_preflight_rejects_untracked_release_python_file(v3b_test_ecology):
    e=v3b_test_ecology
    (e['repo']/'stage2_6_1/tests/test_untracked.py').write_bytes(b'def test_other(): pass\n')
    with pytest.raises(guard.AdmissionError,match='release Python member set'):
        cli.check_mapping(guard,e['repo'],e['deploy'],e['candidate'],worktree=True,source_only=True)
