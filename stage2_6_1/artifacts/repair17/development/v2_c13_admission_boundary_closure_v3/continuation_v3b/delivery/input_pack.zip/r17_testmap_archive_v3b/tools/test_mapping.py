#!/usr/bin/env python3
"""Preflight source mapping before expensive pytest. Does not modify either tree."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys


def check_mapping(guard, repo: Path, deploy: Path, candidate: str, *, worktree=False, source_only=False):
    mapping = guard.candidate_test_map(repo, candidate)
    expected_sources = {row['source_path'] for row in mapping.values()}
    found = set()
    for directory, dirs, files in os.walk(repo / 'stage2_6_1/tests', followlinks=False):
        for name in dirs:
            if (Path(directory) / name).is_symlink():
                raise guard.AdmissionError('symlink directory in release tests')
        for name in files:
            if name.endswith('.py'):
                path = Path(directory) / name
                guard.no_symlink_path(path, must_exist=True)
                found.add(path.relative_to(repo).as_posix())
    if found != expected_sources:
        raise guard.AdmissionError('release Python member set differs from candidate Git: ' +
                                   guard.canonical({'missing': sorted(expected_sources-found),
                                                    'extra': sorted(found-expected_sources)}))
    mapped = {}
    for rel, row in mapping.items():
        row = dict(row)
        body = guard.stable_bytes(repo / row['source_path'])
        # Worktree mode is only for pre-C patched tests; never an admission certificate.
        if worktree:
            row['worktree_source_sha256'] = hashlib.sha256(body).hexdigest()
            row['deploy_sha256'] = hashlib.sha256(body.replace(b'\r', b'')).hexdigest()
            row['deploy_size'] = len(body.replace(b'\r', b''))
        elif hashlib.sha256(body.replace(b'\r', b'')).hexdigest() != row['deploy_sha256']:
            raise guard.AdmissionError('release normalized bytes differ: ' + row['source_path'])
        mapped[rel] = row
    errors = [] if source_only else guard.deployment_test_errors(deploy, mapped)
    if errors:
        raise guard.AdmissionError('deployment test preflight rejected: ' + guard.canonical(errors))
    return {'ok': True, 'candidate': candidate,
            'scope': 'worktree_diagnostic_only' if worktree else 'candidate_git_mapping',
            'admission_eligible': False, 'deployment_checked': not source_only, 'map': mapped,
            'python_file_count': len(mapped),
            'test_file_count': sum(row['is_test'] for row in mapped.values()),
            'root_origin_test_count': sum(row['is_test'] and row['source_path'].count('/') == 2 for row in mapped.values())}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runner', type=Path, required=True)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--deploy', type=Path, required=True)
    p.add_argument('--candidate', required=True)
    p.add_argument('--worktree', action='store_true')
    p.add_argument('--source-only', action='store_true', help='diagnostic before sync; not full verification')
    a = p.parse_args()
    sys.path.insert(0, str(a.runner))
    import r17_v2_c13_admission_guard as g
    result = check_mapping(g, a.repo, a.deploy, a.candidate, worktree=a.worktree, source_only=a.source_only)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'TESTMAP_STOP: {type(exc).__name__}: {exc}', file=sys.stderr)
        raise SystemExit(2)
