# 验收矩阵（每项绑定真实原件，不以汇总自证）

| ID | 必须满足的行为 |
|---|---|
| P01 | 基线71a815c、正确分支、源/测试/config clean；旧活动遥测单独记录 |
| P02 | 四个精确Git blob应用，输出恰四文件；历史lock c9152b…未改变 |
| P03 | V10、authority/claim、history、R4/R5、C2、monitor/sampler未被放宽或修改 |
| M01 | 根目录与嵌套目录受跟踪Python文件递归映射，来源路径不是根据部署路径猜测 |
| M02 | CR删除规则与现有sync逐字节相同；仅替换CRLF不合格 |
| M03 | 同名及大小写折叠冲突在同步/测试前拒绝，相同内容也不能静默覆盖 |
| M04 | 候选合法31根目录测试恢复，完整129文件进入部署及运行；不继续隔离 |
| M05 | 候选→部署→manifest精确集合一致；缺文件、多文件、重复行、字节错配拒绝 |
| M06 | support Python文件也绑定；篡改或缺失conftest不能被忽略 |
| M07 | collection/JUnit精确node multiset一致，每个候选测试文件必须有执行成员 |
| M08 | 从部署、manifest、collection、JUnit同时删除候选文件仍拒绝（真实guard临时Git测试） |
| M09 | source-only/worktree检查明确非准入；正式full只绑定新C Git对象 |
| M10 | full_eco为明确合成3case且同样遵守成员规则；旧测试断言不变 |
| T01 | 本包快速测试全绿，保存Python/Git/命令/rc/JUnit；不冒称项目全量 |
| T02 | 八文件定向零fail/error/skip/xfail，新增21case和V10均实际执行 |
| T03 | 完整R17-first从C的map生成全部test列表，运行前就拒绝缺测部署 |
| T04 | 一次同候选完整pytest，原collector/full verifier通过；源map前后相同 |
| T05 | 7个历史skip来源白名单；本轮critical不skip；完整case数如实记录 |
| N01 | 实际健康包10类副本负例各命中预期错误键；原包字节不变 |
| A01 | 临时symlink负例真实执行，未改为字符串模拟；导出时不跟随链接 |
| A02 | readlink原始字节、类型、路径、size/SHA保存在普通描述文件；原WORK不改 |
| A03 | 只有固定负例链接允许描述化；其他特殊文件/父链接/路径逃逸在写出前拒绝 |
| A04 | export/verify对拍源与导出；所有普通输入字节保持，链接转换明确标注 |
| A05 | 暂存区仅新v3b路径A；100644/100755；拒绝120000/160000/M/D/T/域外改动 |
| A06 | 新证据整个工作树与index集合相同；.gitignore漏收原始日志被拒绝 |
| A07 | 完整“负例→导出→暂存→E→E2→实际history/full语义”在临时Git生态测试通过 |
| G01 | 新C是真实代码候选；旧16c45da运行的candidate/HEAD字段不改写 |
| G02 | E先本地提交后full冷验，成功才进最终发布；E2后再次真实full冷验 |
| G03 | C..E..E2源码/测试未漂移；旧symlink历史仍按原规则拒绝，不加特批 |
| G04 | delivery一次封存；post_E单独新增；旧报告/日志/claim/锁全保留 |
| G05 | 普通commit/push，无amend/force/reset；最终远端等于本地E2 |
| V01 | 本轮工程/新统计NOT_RUN/正式资格NOT_ISSUED分别报告；不授权C2或新训练 |

任何失败按FAIL，不给conditional PASS。已有正确工作不因此作废：V10修复、原统计和监护实现保留。
