import ast
import hashlib
from pathlib import Path
import pytest
import apply_patch as a


def test_exact_base_guard_pin_and_unchanged_security_functions():
    before=(a.ROOT/'references/guard_before.py').read_bytes()
    after=(a.ROOT/'implementation/r17_v2_c13_admission_guard.py').read_bytes()
    assert a.blob_id(before)==a.PINS[a.RUNNER+'r17_v2_c13_admission_guard.py']
    left={n.name:ast.get_source_segment(before.decode(),n) for n in ast.parse(before).body if isinstance(n,ast.FunctionDef)}
    right={n.name:ast.get_source_segment(after.decode(),n) for n in ast.parse(after).body if isinstance(n,ast.FunctionDef)}
    for key in ('authority_values','no_symlink_path','stable_bytes','verify_candidate_history','junit_details','tree_index'):
        assert left[key]==right[key],key


def test_rewrite_fixture_keeps_original_assertions_and_builds_matched_sources():
    source='''import pytest
@pytest.fixture
def full_eco(tmp_path):
    test_rel = []
    for file in []:
        pass

    def git(*args):
        pass
    return test_rel

def test_old(full_eco):
    assert full_eco
'''
    result=a.rewrite_full_fixture(source)
    assert 'test_synth.py' in result
    assert 'def test_old(full_eco):\n    assert full_eco' in result
    compile(result,'fixture','exec')


def test_update_only_guard_digest_in_current_governance_lock():
    s="MEMBER_MODULES = ('r17_v2_c13_admission_guard', 'other')\nSOURCE_SHA256 = " + repr({'r17_v2_c13_admission_guard':'daf603e6a4ca207373f3034ed518a32535810cc327dce356f075244bba0d3a04','other':'ab'*32})+'\n'
    out=a.refresh_guard_hash(s,b'new guard')
    ns={};exec(out,ns)
    assert ns['SOURCE_SHA256']['other']=='ab'*32
    assert ns['SOURCE_SHA256']['r17_v2_c13_admission_guard']==hashlib.sha256(b'new guard').hexdigest()
    assert ns['MEMBER_MODULES']==('r17_v2_c13_admission_guard','other')


def test_fixture_anchor_missing_rejects():
    with pytest.raises(RuntimeError):a.rewrite_full_fixture('x=1\n')
