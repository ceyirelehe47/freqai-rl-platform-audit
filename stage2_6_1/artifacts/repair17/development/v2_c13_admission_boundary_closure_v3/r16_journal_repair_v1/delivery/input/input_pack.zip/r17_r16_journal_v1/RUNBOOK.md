# WSL 执行与回传

以下路径固定。`PACK` 与 `ZIP` 必须填实际解压目录和实际下载文件，不能猜测两者有嵌套关系。

## S0 — 接手、输入与保护

```bash
source /home/cryptorl/projects/crypto_rl/activate-freqtrade.sh
PACK=/实际解压路径/r17_r16_journal_v1
ZIP=/实际下载路径/R17_R16_Journal_Serialization_and_C2_Resume_v1_Code_and_Verification_Pack.zip
REPO=/mnt/f/trading/freqai-rl-audit
DEPLOY=/home/cryptorl/projects/crypto_rl
WORK="$DEPLOY/work/r17_r16_journal_v1_$(date -u +%Y%m%dT%H%M%SZ)_$$"
mkdir "$WORK"
cd "$PACK"
sha256sum -c SHA256SUMS > "$WORK/package_checksum.txt"
python tools/capture_input_pack.py --zip "$ZIP" --out "$WORK/input" > "$WORK/input_capture.json"
cd "$REPO"
git rev-parse HEAD > "$WORK/head_before.txt"
git branch --show-current > "$WORK/branch_before.txt"
git status --porcelain=v1 > "$WORK/worktree_before.txt"
git ls-remote origin refs/heads/route-c-stage2-6-1-repair17 > "$WORK/remote_before.txt"
test "$(git rev-parse HEAD)" = 3a0235470996b8b8439d6f565e0eb65fea1c97b4
test "$(awk '{print $1}' "$WORK/remote_before.txt")" = 3a0235470996b8b8439d6f565e0eb65fea1c97b4
python "$PACK/tools/protected_snapshot.py" --repo "$REPO" > "$WORK/protected_before.json"
```

WSL Git 网络失败时，允许 Windows 宿主 Git 在**同一发布库**执行 `ls-remote`／最终 push，分别保存命令、stdout、stderr、rc。不把网络失败当成远端未变。不要 reset/pull/rebase 来迁就本包基线。

先阅读工作树；只有已知 `run_supervision` 活动追加可以留下并单列。暂存区或源码面不干净，应用器会拒绝。不要删除未知文件。

## S1 — 检查、应用、同步

```bash
python "$PACK/tools/apply_patch.py" --repo "$REPO" > "$WORK/apply_check.json"
python "$PACK/tools/apply_patch.py" --repo "$REPO" --apply --recovery "$WORK/recovery" > "$WORK/apply.json"
git -C "$REPO" diff --check
bash "$REPO/stage2_6_1/runner/r17_sync.sh" > "$WORK/sync.log" 2> "$WORK/sync.stderr.log"
PYTHONPATH="$DEPLOY/stage2_6_1_runner:$DEPLOY/src" python "$PACK/tools/check_environment.py" > "$WORK/environment.json"
```

任何管道/重定向命令失败都要保留实际 rc 并停止；不要依据 JSON 中的局部字段忽略 shell 非零退出码。可先运行包自带 `RUN_LOCAL_TESTS.sh` 在固定 Python 上做 76 项快速检查；这不能代替项目定向或完整回归。

## S2 — 三个顺序阶段

```bash
bash "$PACK/tools/run_probe.sh" "$WORK/probe"
bash "$PACK/tools/run_targeted.sh" "$WORK/targeted"
bash "$PACK/tools/run_rehearsal.sh" "$WORK/rehearsal"
```

每条仅运行一次，前者非零就不运行后者。建议外层再将控制脚本的 stdout/stderr 和实际 rc 保存到 `$WORK` 顶层。三个脚本内部已经保存入口原件。

`run_probe.sh` 使用监护 fixture 入口；它在临时状态上执行一个旧算法红例和一个新算法绿例。旧红例必须确实重现重复序号及严格错误；新绿例必须确实观察到不兼容 journal 锁并完整完成生命周期。不能接受某一子进程根本未启动作为红例。

定向为十一文件，预期 **291**（既有九文件 231 + R16 23 + journal 37）。新增/原 R16 和 C2 全部不允许 skip/xfail。子进程原件在 `$WORK/targeted/child_evidence/`，不是只留在 pytest 临时目录。

## S3 — 冻结真实候选

只有 S2 全通过才执行：

```bash
cd "$REPO"
git add -- \
 stage2_6_1/src/rl_curriculum/curriculum261_r16_execgov.py \
 stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_execgov.py \
 stage2_6_1/tests/route_c_stage2_6_1/r17_r16_journal_test_support.py \
 stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_journal_serialization.py
git diff --cached --check
git diff --cached --name-status > "$WORK/candidate_diff.txt"
git commit -m "R17: serialize R16 journal transactions and retain competition evidence"
C=$(git rev-parse HEAD)
printf '%s\n' "$C" > "$WORK/CANDIDATE.txt"
bash stage2_6_1/runner/r17_sync.sh > "$WORK/sync_after_C.log"
```

C 必须直接建立在指定基线上，恰好两修改、两新增。之后不改源码／测试；不 amend。完整回归成功后再做证据 E。后续需要改实现时停止交回，不自主换候选。

## S4 — 同候选完整回归

```bash
bash "$PACK/tools/run_bound_regression.sh" "$C" "$WORK/full_regression"
```

脚本先核对 import、完整测试映射与集合，再按 R17-first 顺序 collect/run；当前预期 **2181 项，2174 passed + 7 skipped**。七项必须是固定历史 skip，三组 supplementary critical 共 113 项零 skip。

监护结果、required/native、JUnit 与 test-file 映射依旧使用现有项目代码。额外补充检查使 R16 journal 37 项不能被漏测，也核对 C2 53 项。源码和 import 的 before/after 必须相等。

任何失败不重复执行本脚本。保留已经写出的 `child_evidence`，不要清理进程现场或原 journal 尾部。

## S5 — 封存与证据提交

所有 run 已完成并关闭写者后，撰写 `$WORK/REPORT.md`，分别记录工程、新业务统计、正式资格与历史状态。新业务统计只允许 NOT_RUN，正式资格只允许 NOT_ISSUED。

```bash
python "$PACK/tools/protected_snapshot.py" --repo "$REPO" --compare "$WORK/protected_before.json" > "$WORK/protected_before_export.json"
PUB="$DEPLOY/work/r17_r16_publish_$(date -u +%Y%m%dT%H%M%SZ)_$$"
mkdir "$PUB"
AR=stage2_6_1/artifacts/repair17/development/v2_c13_admission_boundary_closure_v3/r16_journal_repair_v1
python "$PACK/tools/archive_evidence.py" export --source "$WORK" --out "$REPO/$AR/delivery" > "$PUB/export.json"
python "$PACK/tools/archive_evidence.py" verify --root "$REPO/$AR/delivery" --source "$WORK" > "$PUB/export_verify.json"
cd "$REPO"
git add -f -- "$AR/delivery"
python "$PACK/tools/archive_evidence.py" staged --repo "$REPO" > "$PUB/staged_verify.json"
git diff --cached --check
git commit -m "R17: archive journal repair and bound C2 regression evidence"
E=$(git rev-parse HEAD)
printf '%s\n' "$E" > "$PUB/EVIDENCE.txt"
```

**不能把 export/verify 输出写回已经冻结的 `$WORK`。** E 只新增本次 evidence 路径，不修改任何历史 artifact，也不修改 C。暂存门禁要求实际文件与 index 相同、没有忽略的日志、没有活链接或 gitlink。不要给空 checksum 改名充数。

若此前阶段 FAIL：仍可按真实状态归档失败证据，但不要生成健康包、跳过失败测试或把失败 C/E 命名为准入通过。未能形成正常 C 时，回传现有 WORK 和 git 状态，不为满足脚本字段伪造 SHA。

## S6 — E 后只读终验、push、回传

```bash
python "$PACK/tools/final_receipt.py" --candidate "$C" --protected-before "$WORK/protected_before.json" --out "$PUB/return"
```

无论成功或失败，工具在新 `return` 中写真实 SUMMARY。成功路径只调用一次已有 full reader 和一次合成 C2 bundle reader；**不执行 pytest、不写新 claim、不新增 Git 提交**。失败路径不补造未执行的验证。

然后普通 push 并记录真实结果。网络只能在 Windows 侧使用时保存对应宿主输出：

```bash
cd "$REPO"
git rev-parse HEAD > "$PUB/return/head_before_push.txt"
set +e
git push origin route-c-stage2-6-1-repair17 > "$PUB/return/push.stdout.log" 2> "$PUB/return/push.stderr.log"
PUSH_RC=$?
printf '%s\n' "$PUSH_RC" > "$PUB/return/push.rc"
set -e
# PUSH_RC 非零：保留并停止；使用 Windows Git 时另留本次失败原件。
git ls-remote origin refs/heads/route-c-stage2-6-1-repair17 > "$PUB/return/remote_after.txt"
git rev-parse HEAD > "$PUB/return/head_after_push.txt"
```

手工逐字核对末次远端 SHA、本地 HEAD、终验 identity_after HEAD 均为 E（或如实报告不符）。将 `$PUB/export.json`、`export_verify.json`、`staged_verify.json` 复制进尚未封口的 `return/`，然后打包：

```bash
cp "$PUB/export.json" "$PUB/export_verify.json" "$PUB/staged_verify.json" "$PUB/return/"
python "$PACK/tools/verify_publication.py" --receipt "$PUB/return"
python "$PACK/tools/pack_return.py" --source "$PUB/return" --zip "$PUB/RETURN_TO_CHATGPT.zip"
```

回传 `RETURN_TO_CHATGPT.zip`、同名 `.sha256.txt` 与 `return/SUMMARY.md`。不新增 E2/E3；不把这些新观察冒充上轮执行结果。若新终验 FAIL，保留全部原件直接回传，不反复试到成功。
