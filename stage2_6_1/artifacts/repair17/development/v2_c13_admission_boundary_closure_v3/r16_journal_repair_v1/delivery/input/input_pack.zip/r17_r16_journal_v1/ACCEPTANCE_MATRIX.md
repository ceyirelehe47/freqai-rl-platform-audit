# 行为验收矩阵

这些是条件，不是预先授予的 PASS。所有报告必须链接实际测试、raw log、JUnit、rc 和源身份。

| ID | 必须成立的行为 | 主要证据 |
|---|---|---|
| J01 | 成功 owner 和失败 contender 在同一 journal mutex 下分配 seq 和追加 | 确定性交错绿例、真实 flock 被阻塞事实 |
| J02 | reader 在 writer read/partial/file-fsync/dir-fsync 四个边界不读到半条记录 | 四个真实进程参数化测试 |
| J03 | durable=False 仍使用 EX，不能绕过序号事务 | 专项测试及 contender 写拒绝记录 |
| J04 | 缺失 journal 只读返回，不创建路径或锁文件 | 只读目录/文件断言 |
| J05 | 有效旧日志前缀和 inode 不变；严格序号连续 | legacy-prefix 测试 |
| J06 | 损坏、重复 seq、非法 iteration/UTF-8/JSON、截尾记录不被修复或续写 | 11 个损坏变体 |
| J07 | 短写/EINTR 在同一锁内完成；0 write／I/O／fsync 错误不伪造成功 | 短写及故障注入 |
| J08 | writer 被 kill 后实际半记录保留；新读写继续拒绝，锁不会永远占用 | kill 进程 rc、原前缀、reader error |
| J09 | 非普通 journal 对象不被跟随或阻塞 | symlink、目录、FIFO |
| J10 | 多线程独立 open file descriptions 的 seq 仍唯一 | 4线程×8条，无重试 |
| J11 | 第一次 acquire journal 写失败，不泄漏未返回的 session 所有权 | 新 owner fd 锁探测 |
| J12 | 旧模块完整字节复现 [1,1]；新模块相同受控交错正常 | 红绿 probe 的两套 raw bytes/rc |
| T01 | 原竞争测试仍同起点 A/B 并发，只承认一个完整生命周期成功 | 原 test ID、两子进程 rc、恰好一次 exposure |
| T02 | A/B stdout/stderr/rc/阶段/journal 已在断言之前写外部证据 | child_evidence 原件 |
| T03 | 人工 child crash 被判失败且完整 stderr 被保留 | 诊断负例，不能早打印 acquired=true |
| T04 | 原竞争类之前 22 个测试字节不变，C2 四文件 blob 不变 | applier、candidate identity |
| R01 | 十一文件定向 291 项全绿且零 skip/xfail | 监护 stdout/JUnit/entry rc |
| R02 | C2 合成 CLI 与七负例保持正确，16 入口零调用 | 实际 rehearse/verify/negative_cases |
| R03 | 新候选 C 直接承接基线，恰好四路径，无历史锁重签 | Git diff / payload bytes |
| R04 | 一次完整 R17-first 2181 项，七项固定历史 skip | 完整测试映射、collection、JUnit |
| R05 | 所有 required/native 原件存在、writer 封口，完整 reader 验证通过 | 原 collector、full verifier |
| R06 | 源码/import/测试 before/after 一致；真实 R16/17 保护对象不变 | 补充 identity 与保护快照 |
| D01 | 实际输入 ZIP 已逐成员验证并保存非空 checksum | input/identity.json 和实际 ZIP |
| D02 | 安全导出、index、普通文件类型与整个成员集合一致 | export/staged 原件 |
| D03 | E only evidence，当前 E full 冷验通过，旧 C2 consumer 原件能重读 | final_receipt 原件 |
| D04 | 外部终验与远端身份回传，正常 push，无回执递归提交 | RETURN ZIP、remote_after、push rc |

任一关键项失败，当前轮整体 FAIL。旧 consumer v1 那次失败不会因为新轮通过而改写；v3b 的已验收范围也不重开。新统计 NOT_RUN，正式资格 NOT_ISSUED，生产 launch false。
