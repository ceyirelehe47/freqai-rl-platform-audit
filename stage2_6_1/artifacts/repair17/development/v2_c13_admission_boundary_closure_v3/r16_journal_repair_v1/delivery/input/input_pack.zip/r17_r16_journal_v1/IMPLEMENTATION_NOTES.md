# 实现与验证范围

## 1. 原件基线

固定 HEAD `3a0235470996b8b8439d6f565e0eb65fea1c97b4`。

完整原 R16 模块已核对 Git blob `00a000438e88898d59062034abcf5ae3ef5d2b97`；完整原测试文件核对 blob `f59df418b16ae27607a3d5dc51e78eb7f6230fe2`。`references/` 保存这两份精确原件，`references/unchanged_c2/` 保存四个不改动的 C2 文件，用于复验本包边界。不是把函数摘录当完整模块。

## 2. 锁选择

使用 journal 文件自身的 EX/SH advisory flock，和会话互斥文件相互独立。好处是读取旧日志时不必创建新 sidecar 锁，真正只读的目录也可消费；前提是所有参与进程使用本次实现，journal 不做替换/轮转。代码对打开后路径 inode 漂移立即拒绝，不把换 inode 当合法续写。

本实现面向既有受信代码的正常并发与误调用，不宣称抵御 root 或同权限恶意进程；没有把文件锁包装成安全沙箱。修复保留 session 非阻塞竞争语义，拒绝者只可能等当前短 journal I/O，不等待整个 session。锁顺序为 session→journal，不存在 journal 内再取 session 的路径。

参考：Linux man-pages `flock(2)`（https://man7.org/linux/man-pages/man2/flock.2.html）与 Python 3.11 `fcntl` 文档（https://docs.python.org/3.11/library/fcntl.html）。本包行为最终由实际进程测试证明，不靠文档描述代替运行证据。

## 3. 保存失败，而非修复历史

严格 writer 在分配 seq 前重放完整已有记录，不再数坏行继续写。部分写入、file/dir fsync 异常都会向上传播；没有 truncate、replace-journal、重编号、自动 tail recovery 或事务重试。合法写使用 inode 原位 append。

读端 SH 包含完整解析过程，读到的是某次完成追加前或后的快照，而不是未完成行。历史缺失路径仍作为不存在观察，读取不会创建空日志。已经被杀死的 writer 留下半行后，新 reader 不能假装只是暂时空数据。

`journal_append` 拒绝 payload 覆盖保留元数据，并拒绝非有限 JSON；这些也是阻止自造序号破坏日志的必要输入校验。

## 4. 验证已经做到哪里

在本地 Linux / Python 3.13.5，以完整修改后 R16 模块建立最小常规 import 布局（不是函数摘录、没有替换会话实现），运行原 R16 测试文件与新增 journal 测试，再运行包工具测试：

- 原 R16 测试：23 项；仅竞争类实现被改为保留证据，之前22项源码不变。
- 新 journal 测试：37 项。
- 应用/恢复/标准 diff/输入包/安全导出/实际 Git 等工具测试：16 项。
- 合计 **76 passed / 0 failed / 0 errors / 0 skipped**。

额外执行一次精确完整旧源码／新源码红绿进程对照：旧算法 `[1,1]` 与 `R16JournalCorruption`，新算法连续序号和完整生命周期。屏障只在真实读取之后暂停，或在真实短写/fsync 边界暂停；不伪造行数、锁状态、异常或 journal 字节。kill 用例实际终止自己的临时 writer。

初期本地工具运行有超时，测试 helper 在 kill 场景后尝试 signal 已终止进程等待的 multiprocessing Event 会阻塞；该取证 helper 已修正，最终完整运行通过。未完成日志保留在 local_validation，不能算通过；没有补造旧退出码。

## 5. 仍需要 WSL 做的事

当前没有完整远端仓库 checkout 的网络下载条件。本地验证不是用户 Python 3.11.16 环境、不是全项目 2181 项、没有运行用户 Windows sampler 或真实部署 reader CLI。

应用器与标准 PATCH.diff 已在精确源文件的实际临时 Git 仓库上验证；WSL 还必须核对完整真实模块 import、全体测试映射、十一文件定向、受监护全量、C2 synthetic CLI、required/native 字节、E 后 full 冷验与保护对象。

不会把76项本地结果说成全项目通过，也不会把合成报告的数值 PASS 说成 C2 校准成功。
