#!/usr/bin/env python3
"""Copy the actual supplied ZIP only after checking every member against this pack."""
from __future__ import annotations
import argparse,hashlib,json,zipfile
from pathlib import Path
import apply_patch as ap

def capture(source,dest):
    source=ap.safe(source);dest=ap.safe(dest)
    raw=source.read_bytes();expected={}
    sums=(ap.ROOT/'SHA256SUMS').read_bytes()
    for line in sums.decode().splitlines():
        h,rel=line.split('  ',1);expected[rel]=h
    expected['SHA256SUMS']=hashlib.sha256(sums).hexdigest()
    prefix=ap.ROOT.name+'/'
    with zipfile.ZipFile(source) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or set(names)!={prefix+x for x in expected}:raise ValueError('ZIP member set mismatch')
        for rel,h in expected.items():
            if hashlib.sha256(z.read(prefix+rel)).hexdigest()!=h:raise ValueError('ZIP checksum mismatch: '+rel)
    if dest.exists():raise ValueError('input capture exists')
    dest.mkdir(parents=True)
    (dest/'input_pack.zip').write_bytes(raw)
    (dest/'input_pack.sha256').write_text(hashlib.sha256(raw).hexdigest()+'  input_pack.zip\n')
    result={'ok':True,'source':str(source),'zip_sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw),'verified_files':len(expected)}
    (dest/'identity.json').write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--zip',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    print(json.dumps(capture(a.zip,a.out),indent=2))
