#!/usr/bin/env python3
"""One fixed red/green experiment using exact FULL baseline/patched modules.

Only isolated system-temp state. The old source is used to show the known
sequence race; its expected failure is not a regression pass or authorization.
"""
from __future__ import annotations
import argparse, hashlib, json, os, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from r17_r16_journal_test_support import controlled_case
import apply_patch as ap

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--module',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args(argv)
    ap.safe(a.out);ap.safe(a.module)
    if os.path.lexists(a.out):raise RuntimeError('new output required; no overwrite/retry')
    if a.out.is_relative_to('/mnt/f/trading/freqai-rl-audit'):raise RuntimeError('external probe output required')
    expected=(ROOT/'implementation/curriculum261_r16_execgov.py').read_bytes()
    if a.module.read_bytes()!=expected:raise RuntimeError('actual module bytes differ from payload')
    baseline=ROOT/'references/curriculum261_r16_execgov.before.py'
    if ap.blob(baseline.read_bytes())!=ap.PREIMAGES['stage2_6_1/src/rl_curriculum/curriculum261_r16_execgov.py']:
        raise RuntimeError('historical source identity mismatch')
    a.out.mkdir(parents=True)
    state=Path(tempfile.mkdtemp(prefix='r17_r16_redgreen_'))
    oldout=a.out/'baseline_race';oldout.mkdir()
    newout=a.out/'patched_race';newout.mkdir()
    old=controlled_case(baseline,state/'old',oldout,baseline=True)
    new=controlled_case(a.module,state/'new',newout)
    old_expected=(not old['errors'] and old['observed_required_interleaving']
                  and old['children']['B']['rc']==3 and old['children']['A']['rc']==1
                  and old['journal_sequence']==[1,1]
                  and 'R16JournalCorruption' in old['children']['A']['stderr'])
    new_expected=(not new['errors'] and new['observed_required_interleaving']
                  and new['children']['B']['rc']==3 and new['children']['A']['rc']==0
                  and all(not c['stderr'] for c in new['children'].values())
                  and new['journal_sequence']==list(range(1,len(new['journal_sequence'])+1)))
    result={'ok':bool(old_expected and new_expected),'baseline_expected_race_reproduced':old_expected,
            'patched_serialized_lifecycle_completed':new_expected,'baseline_source_git_blob':ap.blob(baseline.read_bytes()),
            'patched_module_file':str(a.module),'patched_sha256':hashlib.sha256(expected).hexdigest(),
            'state_temp_root':str(state),'production_state_touched':False,
            'interpretation':'new controlled experiment, not reconstruction of lost WSL failure'}
    (a.out/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));return 0 if result['ok'] else 1
if __name__=='__main__':raise SystemExit(main())
