#!/usr/bin/env bash
# Isolated complete-module/component tests, NOT a complete project/WSL regression.
set -euo pipefail
PACK=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
OUT=${1:?fresh absolute external output directory required}
[[ $OUT = /* && ! -e $OUT ]] || exit 2
mkdir -p "$OUT"
TMP=$(mktemp -d /tmp/r17_r16_local_XXXXXX)
mkdir -p "$TMP/src/rl_curriculum" "$TMP/tests"
cp "$PACK/implementation/curriculum261_r16_execgov.py" "$TMP/src/rl_curriculum/"
cp "$PACK/tests/"*.py "$TMP/tests/"
printf '%s\n' "$TMP" > "$OUT/layout.txt"
python - <<'PY' > "$OUT/environment.json"
import sys,platform,json
print(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),
 'scope':'full R16 module and component tests in a minimal import layout, not full project'},indent=2))
PY
set +e
R17_R16_TEST_EVIDENCE_DIR="$OUT/child_evidence" PYTHONPATH="$TMP/src" \
 python -m pytest -q "$TMP/tests" "$PACK/package_tests" --junitxml="$OUT/junit.xml" \
 > "$OUT/stdout.log" 2> "$OUT/stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$OUT/rc.txt"
cat "$OUT/stdout.log"
exit "$RC"
