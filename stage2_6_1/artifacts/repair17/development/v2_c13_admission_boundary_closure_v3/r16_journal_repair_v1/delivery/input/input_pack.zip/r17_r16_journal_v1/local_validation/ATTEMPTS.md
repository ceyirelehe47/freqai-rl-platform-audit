# 本地验证记录

`first.stdout.log` 和 `component.stdout.log` 为工具时间限导致的未完成尝试；没有对应完整 JUnit/真实返回码，不算通过。初期 kill 场景的测试取证 helper 会在 parent 再次设置死进程等待的 Event 时阻塞；已修正该 helper 的释放分支。

`component2.*`：60 项完整模块组件测试通过。
`red_green/*`：完整精确旧源码的确定性重复序号红例、完整修改后源码的串行化生命周期绿例。
`complete_run/*`：60 项模块/测试 + 16 项包工具，共76项完整通过。

这些都不是用户WSL全项目回归。最终脚本只创建新路径，保留每一套本地证据。
