# R17R16JournalSerializationAndC2RegressionResume-v1

## 1. 当前状态与本轮目标

接手基线为 `3a0235470996b8b8439d6f565e0eb65fea1c97b4`；仓库、分支见 README。

上轮 C2 consumer 候选 `749660f7501e4db70c962455387bfb5f5755cd8a` 的九文件定向 231 项通过、合成报告 CLI 与七类负例通过，但完整回归为 **2136 passed / 1 failed / 7 skipped，共 2144 项**。失败项是 R16 双进程竞争测试。旧测试丢弃子进程 stderr；该次现场已不可恢复，不能把后来复现当成对该次异常的法证还原。

已确认的算法缺口是成功 owner 与抢锁失败者同时调用 `journal_append()`，旧实现“先数行、再写 seq”没有 journal 级互斥。助手已经用精确完整旧模块做控制交错，得到 `[1,1]` 和严格 reader 的 `R16JournalCorruption`；修复模块下同一交错得到连续序号和完整生命周期。

本轮一次完成：应用 journal 修复、真实进程红绿对照、保存竞争测试取证、验证 C2 仍正常、形成一个新候选并完成正确绑定的完整回归。不是给旧失败换结论。

## 2. 已实现内容，不自行替换方案

journal 本身的文件 inode 用作独立短时 I/O 锁对象，不新增另一套权威日志或生命周期。writer 使用 EX，将严格重放、分配 seq、追加所有字节、flush、必要 file/dir fsync 放进一个临界区；reader 以只读 fd 和 SH 读取一个完整快照。该锁不是 `r16_session.lock`，拒绝者不等待整个正式会话结束。

读取缺失 journal 不创建目录、文件或锁文件；既有有效日志可原位追加，前缀和 inode 保留。不重编号，不截尾，不恢复损坏历史，不自动重试整个事务。短写在同一锁内完成；I/O 或 fsync 失败向上抛出。被 kill 后留存的不完整记录，由后续 reader/writer 如实拒绝。非普通文件、重复键、错误 seq/iteration、非有限 JSON 与未完成的记录不能被签成健康。

成功 session 的第一次 journal 写入失败时，尚未返回的 session fd 会释放，错误与已写前缀仍保留。其他 session/exposure/token/grant/terminal 判定保持原实现。

原双进程测试仍同时放行 A/B、仍要求一个完整成功和一个拒绝、仍核对恰好一次 exposure 及终态。成功 JSON 只在真实 terminal 和 release 完成后输出。新增证据保存 A/B 的原始 stdout、stderr、返回码、阶段事件、journal/marker 字节及摘要。它不靠“谁先启动谁赢”或增加 sleep 假设正确性。

## 3. 修改面

| 位置 | 操作 |
|---|---|
| `stage2_6_1/src/rl_curriculum/curriculum261_r16_execgov.py` | 修改 journal I/O 事务与未返回 session fd 的错误清理 |
| `stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_execgov.py` | 只替换竞争测试类；此前 22 项测试的源码字节不变 |
| 同测试目录 `r17_r16_journal_test_support.py` | 新增真实进程、屏障和持久化取证 helper |
| 同测试目录 `test_curriculum261_r16_journal_serialization.py` | 新增 37 项 journal 行为测试 |

四个旧 C2 实现/夹具/测试文件固定 blob，应用器及终验再次核对。不修改 R4/R5/R6/R17 科学定义、不改 C2 候选、不改 v3b guard、同步器、监护器、采样器或任何 source lock。本轮 R16 模块不在 v3b 十成员 lock 内；以补丁身份、候选 Git、实际 import 及补充验证绑定新字节，不能重签历史 lock。

## 4. 环境与副作用范围

固定 WSL `CryptoRL-Ubuntu-24.04`、用户 `cryptorl`、conda `freqtrade-rl`、Python `3.11.16`；发布库 `/mnt/f/trading/freqai-rl-audit`，部署项目 `/home/cryptorl/projects/crypto_rl`。激活脚本可能改变 cwd，所有命令激活后重新 cd。

真实 R16/17 状态、旧 claim、旧生产 plan、旧 run、旧失败与旧 C2 evidence 全部只读。保护快照包含既有 R17 证据和真实 R16 默认状态位置；只排除本轮全新的 evidence 子树。`run_supervision` 活动记录单独列账。

测试 helper 的 state 限定专用系统临时子树；原 R16 23 项测试也使用 tmp fixture。不得手工调用实际生产 `R16FormalSession.acquire()`、preclaim writer、claim writer 或 C2 design/calibration 入口。

## 5. 顺序及停止条件

S0：核对当前远端与本地 HEAD、父链、暂存区、代码面和保护对象；校验本包所有 SHA256SUMS；明确传入真实输入 ZIP 路径，由工具验证整个 ZIP 后再复制。路径错误或空 checksum 必须立即报错，不能写成功说明。

S1：应用器 check，再显式 apply。恢复副本必须写在发布库之外。运行 `git diff --check`，同步并检查实际 import/file SHA。不要通过删除合法测试修复映射错误。

S2：顺序执行一次 `run_probe.sh`（精确旧模块红例与新模块绿例）、一次十一文件定向（预计 291），以及 C2 合成 rehearsal/七类负例。probe 只作用于临时根；红例的预期损坏不是生产失败日志，也不能计成新模块绿色。

S3：只有 S2 全通过才能生成代码候选 C。C 是基线的直接子提交，只含四个允许路径；正常普通 commit，冻结候选。不 amend；源码不再改动。这里不必提前 push，E 后终验完成再一次普通 push。

S4：同一 clean 候选 C 上运行一次完整 R17-first 回归。预计 **2181 = 2144 + 37**；既有允许 skip 仍恰好七项。新 R16 37 项、旧 R16 23 项、C2 53 项全部零 skip/xfail。候选源树应有 131 个测试文件；完整集合由 Git 映射核对，不通过删测凑数。完整入口与 collector/reader 使用既有项目实现，额外补充 checker 约束本轮三组 critical。

S5：所有重任务结束后归档。`WORK` 在首次导出后冻结，不把导出输出再重定向到它内部。使用 safe exporter，不执行 `cp -a` 复制未知链接。暂存区检查 member 集合、普通 Git blob 与实际字节一致。证据 E 只新增本轮子树，不改 C，不改历史，普通 commit。

S6：在 E 上执行一次已有 full reader 和 C2 只读冷读，检查 C→E 历史、实际 R16/C2 imports、healthy package digest、补充 JUnit 和保护对象；结果写仓库外 `return`。无须新增 E2/E3，也无须为了归档末次回执再运行 pytest。最后普通 push，记录实际远端 ref 与前后 HEAD，然后打包回传。

任一步失败：保留原始 rc/stdout/stderr/JUnit/子进程快照及已写前缀，停止后续计算。不得重跑原全量追绿、自动恢复 journal、改旧报告、调统计门槛、增 skip 或自主实现修复。允许把实际失败代码与证据作为明确 FAILED/NOT_ADMISSIBLE 的普通提交交回；不能将其命名为通过的候选。应用器失败时不自动回滚未知状态。

## 6. 必需原件

固定身份（HEAD、branch、remote、Python/vendor/import）、输入 ZIP 与非空校验值、前后保护清单、应用器输出/恢复副本、红绿进程原件、定向日志及 JUnit、合成 CLI 与七负例、完整 collect/命令/JUnit/entry 和 business rc、required/native 原字节、测试映射、source/import 补充身份、safe-export manifest、暂存门禁输出，以及仓库外终验回执。

`R17_R16_TEST_EVIDENCE_DIR` 由脚本设置到本次外部运行目录。即使 pytest 清理 `/tmp`，竞争进程的 stdout/stderr/rc、阶段跟踪和 journal 字节已留在外部文件中。原件必须先落盘再进行 pytest 断言，不以最终 `results` 字符串替代 stderr。

## 7. 本轮 PASS 的含义

全部矩阵通过、新候选全量绿色、相同候选证据冷验通过且旧保护对象不变，方可输出：

```text
R16 journal serialization engineering: PASS
C2 synthetic consumer integration regression: PASS
old C2 consumer v1 execution: FAIL (retained)
v3b: CLOSED PASS (unchanged)
business statistics: NOT_RUN
formal qualification: NOT_ISSUED
production launch authorized: false
```

合成报告仍不是正式校准，未重建真实 episode/proof，未接入真实 V2 fit/scaled evaluator，未启动 C2 真实生成、正式 A/B 或训练。
