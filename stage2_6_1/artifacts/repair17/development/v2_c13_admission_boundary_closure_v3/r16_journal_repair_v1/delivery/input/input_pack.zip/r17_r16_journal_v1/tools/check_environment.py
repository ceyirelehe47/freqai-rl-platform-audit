#!/usr/bin/env python3
"""Read-only WSL import/complete-deployment check, including R16 journal patch and unchanged C2 files."""
import hashlib, importlib, json, os, sys
from pathlib import Path
import apply_patch as ap
REPO=Path('/mnt/f/trading/freqai-rl-audit')
DEPLOY=Path('/home/cryptorl/projects/crypto_rl')


def verify_source_bindings(repo,deploy,identity,revision='HEAD'):
    """Actual imported direct dependencies must equal candidate normalized bytes."""
    if not identity:raise RuntimeError('empty source identity')
    result={}
    for name,item in identity.items():
        if name.startswith('rl_curriculum.'):
            leaf=name.split('.')[-1]+'.py'
            rel='stage2_6_1/src/rl_curriculum/'+leaf
            expected_path=deploy/'src/rl_curriculum'/leaf
        elif name=='r17_c2_consumer_rehearsal':
            rel='stage2_6_1/runner/'+name+'.py'
            expected_path=deploy/'stage2_6_1_runner'/(name+'.py')
        else:raise RuntimeError('unknown imported source role: '+name)
        if Path(item['file'])!=expected_path:raise RuntimeError('shadow import path: '+name)
        # Before C, the two new modules are untracked but exactly the packaged
        # payload; after C the final receipt additionally pins them via Git.
        additions=ap.payload()
        body=additions[rel] if rel in additions else ap.git(repo,'show',revision+':'+rel)
        expected=hashlib.sha256(body.replace(b'\r',b'')).hexdigest()
        if item['sha256']!=expected:raise RuntimeError('imported bytes differ from candidate source: '+name)
        if hashlib.sha256(expected_path.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('import file changed: '+name)
        result[name]={'source_path':rel,'import_path':str(expected_path),'sha256':expected}
    return result

def main():
    if sys.version_info[:3]!=(3,11,16):raise RuntimeError('WSL Python 3.11.16 required')
    if os.environ.get('R17_LOCAL_EXCERPT_TESTS'):raise RuntimeError('local excerpt loader forbidden in WSL project test')
    if 'freqtrade-rl' not in sys.prefix:raise RuntimeError('freqtrade-rl environment required')
    sys.path[:0]=[str(DEPLOY/'stage2_6_1_runner'),str(DEPLOY/'src')]
    import r17_v2_c13_pipeline as old
    import r17_c2_consumer_rehearsal as runner
    import r17_v2_c13_admission_guard as guard
    old_sources=old.source_guard();new=ap.payload()
    imports=runner.source_identity()
    from rl_curriculum import curriculum261_r16_execgov as r16
    imports['rl_curriculum.curriculum261_r16_execgov']={'file':str(Path(r16.__file__).absolute()), 'sha256':hashlib.sha256(Path(r16.__file__).read_bytes()).hexdigest()}
    for rel,oid in ap.C2_PINS.items():
        if ap.blob((REPO/rel).read_bytes())!=oid:raise RuntimeError('C2 source changed: '+rel)
    historical=REPO/'stage2_6_1/runner/r17_v2_c13_source_lock.py'
    if hashlib.sha256(historical.read_bytes()).hexdigest()!='c9152b62192a93571c16ba62e0ef2e70522f108726f3eb83fd25d48007a77c55':raise RuntimeError('historical source lock changed')
    source_bindings=verify_source_bindings(REPO,DEPLOY,imports)
    for rel,b in new.items():
        target=REPO/rel
        if target.read_bytes().replace(b'\r',b'')!=b:raise RuntimeError('new payload mismatch: '+rel)
        if '/src/' in rel:deployed=DEPLOY/'src/rl_curriculum'/target.name
        elif '/runner/' in rel:deployed=DEPLOY/'stage2_6_1_runner'/target.name
        else:deployed=DEPLOY/'tests/route_c_stage2_6_1'/target.name
        if guard.stable_bytes(deployed)!=b:raise RuntimeError('new deployed bytes differ: '+str(deployed))
    source_root=REPO/'stage2_6_1/tests'
    mapping={};folded=set()
    for file in sorted(source_root.rglob('*.py')):
        guard.no_symlink_path(file,must_exist=True)
        key=file.name.casefold()
        if key in folded:raise RuntimeError('test flatten collision: '+str(file))
        folded.add(key);body=guard.stable_bytes(file).replace(b'\r',b'')
        rel='tests/route_c_stage2_6_1/'+file.name
        mapping[rel]={'deploy_sha256':hashlib.sha256(body).hexdigest(),'deploy_size':len(body)}
    errors=guard.deployment_test_errors(DEPLOY,mapping)
    if errors:raise RuntimeError('complete deployed test set mismatch: '+str(errors))
    out={'ok':True,'python':sys.version,'executable':sys.executable,
         'head':ap.git(REPO,'rev-parse','HEAD').decode().strip(),
         'old_source_guard':old_sources,'new_consumer_sources':imports,
         'source_bindings':source_bindings,'test_python_files':len(mapping),'test_files':sum(Path(x).name.startswith('test_') for x in mapping),
         'generation_not_run':True,'scope':'R16 + unchanged C2 import/deployment preflight; full Git binding checked separately'}
    print(json.dumps(out,sort_keys=True,indent=2));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:print(json.dumps({'ok':False,'error':str(e)}));raise SystemExit(1)
