#!/usr/bin/env python3
"""Exercise real installed synthetic C2 bundle reader on disposable copies.

Reports/blocks are synthetic specimens. Never touches the healthy source,
production claims, generator, evaluator or preprocessor. Exit zero means every
specified negative was refused and the healthy reader control succeeded.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, os, shutil, sys, tempfile
from pathlib import Path


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle',type=Path,required=True);p.add_argument('--input-sha256',required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args(argv)
    import r17_c2_consumer_rehearsal as r
    from rl_curriculum import curriculum261_r17_c2_consumer as c
    a.out=r._safe(a.out)
    if os.path.lexists(a.out):raise FileExistsError(a.out)
    if not a.out.is_relative_to(Path(tempfile.gettempdir()).resolve()):raise ValueError('temp-only negatives')
    a.out.mkdir(parents=True);before=r._index(a.bundle)
    results=[]
    with r.zero_calls() as calls:
        healthy=r.verify_bundle(a.bundle,a.input_sha256)
        (a.out/'healthy.json').write_text(json.dumps(healthy,indent=2)+'\n')
        for name,expected in (
                ('missing_result','file set mismatch'),('append_result','bytes differ'),
                ('resign_wrong_decision','result differs'),('resign_promote_qualification','result differs'),
                ('resign_swapped_candidate','result differs'),('replace_input_and_manifest','input identity mismatch'),
                ('source_identity_changed','source identity differs')):
            case=a.out/name;case.mkdir();target=case/'bundle'
            shutil.copytree(a.bundle,target)
            def doc(file):return json.loads((target/file).read_bytes())
            def put(file,value):(target/file).write_text(c.canonical(value)+'\n')
            if name=='missing_result':(target/'result.json').unlink()
            elif name=='append_result':
                with (target/'result.json').open('ab') as f:f.write(b' ')
            else:
                if name=='source_identity_changed':
                    x=doc('sources.json');next(iter(x.values()))['sha256']='00'*32;put('sources.json',x)
                elif name=='replace_input_and_manifest':
                    x=doc('input.json');x['foreign_receipt']='not-the-original-input';put('input.json',x)
                else:
                    x=doc('result.json')
                    if name=='resign_wrong_decision':x['calibration']['strict_and']=False
                    elif name=='resign_promote_qualification':x['formal_qualification']='ISSUED'
                    elif name=='resign_swapped_candidate':x['design']['selection']['candidate_id']='midpoint'
                    put('result.json',x)
                m=doc('manifest.json');m['files']={k:v for k,v in r._index(target).items() if k!='manifest.json'}
                if name=='replace_input_and_manifest':m['input_sha256']=c.digest(doc('input.json'))
                put('manifest.json',m)
            mut_before=r._index(target)
            try:r.verify_bundle(target,a.input_sha256)
            except (ValueError,RuntimeError) as exc:
                actual=str(exc)
                if expected not in actual:raise AssertionError((name,expected,actual))
            else:raise AssertionError('negative accepted: '+name)
            if r._index(target)!=mut_before:raise AssertionError('reader wrote during negative')
            item={'case':name,'expected_error':expected,'error':actual,'rejected':True,'read_only':True}
            (case/'result.json').write_text(json.dumps(item,indent=2)+'\n');results.append(item)
        if any(calls.values()):raise AssertionError('side-effect boundary called')
    if before!=r._index(a.bundle):raise AssertionError('healthy bundle changed')
    summary={'healthy_pass':True,'all_negative_cases_rejected':True,'original_unchanged':True,
             'zero_call_counts':calls,'cases':results,'business_statistics':'NOT_RUN',
             'formal_qualification':'NOT_ISSUED'}
    (a.out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({'ok':False,'error':type(exc).__name__,'message':str(exc)}));raise SystemExit(1)
