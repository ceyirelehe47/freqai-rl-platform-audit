#!/usr/bin/env python3
"""Pack an existing external receipt directory without following any links."""
import argparse, hashlib, json, os, zipfile
from pathlib import Path
import archive_evidence as ar
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--zip',type=Path,required=True)
a=p.parse_args();source=ar.safe_path(a.source,exists=True);z=ar.safe_path(a.zip)
if z.is_relative_to(source) or os.path.lexists(z):raise ValueError('fresh ZIP must be outside source')
index=ar.file_index(source)
if 'SHA256SUMS' in index:raise ValueError('reserved return checksum name already exists')
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for rel,meta in sorted(index.items()):
        body=(source/rel).read_bytes()
        if {'size':len(body),'sha256':hashlib.sha256(body).hexdigest()}!=meta:raise RuntimeError('source raced')
        archive.writestr('return/'+rel,body)
    archive.writestr('return/SHA256SUMS',''.join(m['sha256']+'  '+p+'\n' for p,m in sorted(index.items())))
if ar.file_index(source)!=index:raise RuntimeError('source changed')
sha=hashlib.sha256(z.read_bytes()).hexdigest()
with z.with_suffix('.sha256.txt').open('x') as f:f.write(sha+'  '+z.name+'\n')
print(json.dumps({'zip':str(z),'sha256':sha,'files':len(index)},indent=2))
