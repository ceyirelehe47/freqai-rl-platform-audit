#!/usr/bin/env bash
set -euo pipefail
PACK=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
OUT=${1:?fresh absolute work directory required}
D=/home/cryptorl/projects/crypto_rl
source "$D/activate-freqtrade.sh"
cd "$D"
[[ -z ${R17_LOCAL_EXCERPT_TESTS:-} && -z ${PYTEST_ADDOPTS:-} ]] || { echo 'Unexpected pytest injection environment'; exit 2; }
[[ $OUT = /* && $OUT != /mnt/f/trading/freqai-rl-audit/* && ! -e $OUT ]] || exit 2
mkdir -p "$OUT"
export PYTHONPATH="$D/stage2_6_1_runner:$D/src"
python "$PACK/tools/check_environment.py" > "$OUT/environment_before.json"
mkdir -p "$OUT/child_evidence"
export R17_R16_TEST_EVIDENCE_DIR="$OUT/child_evidence"
FILES=(
 tests/route_c_stage2_6_1/test_curriculum261_r16_execgov.py
 tests/route_c_stage2_6_1/test_curriculum261_r16_journal_serialization.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_c2_consumer.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_admission_guard.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_claim_protocol.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_regression_evidence.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_pipeline.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_reader_binding.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_synthetic_chain.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_v2_c13_source_provenance.py
 tests/route_c_stage2_6_1/test_curriculum261_r17_c2_launch_prep.py
)
RUN="$OUT/monitored_run"
printf '%q ' bash "$D/stage2_6_1_runner/r17_monitored_entry.sh" pytest --max-seconds 3600 -- python -m pytest --rootdir="$D" -o "cache_dir=$D/.pytest_cache" -q "${FILES[@]}" "--junitxml=$RUN/junit.xml" > "$OUT/command.txt"
printf '\n' >> "$OUT/command.txt"
set +e
R17_RUN_DIR="$RUN" bash "$D/stage2_6_1_runner/r17_monitored_entry.sh" pytest --max-seconds 3600 -- \
 python -m pytest --rootdir="$D" -o "cache_dir=$D/.pytest_cache" -q "${FILES[@]}" "--junitxml=$RUN/junit.xml" > "$OUT/entry.stdout.log" 2> "$OUT/entry.stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$OUT/entry.rc"
[[ $RC = 0 ]] || exit "$RC"
python "$PACK/tools/check_junit.py" --scope targeted "$RUN/junit.xml" > "$OUT/new_c2_check.json"
python - "$OUT/new_c2_check.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]));assert x['skipped']==0,x
PY
python "$PACK/tools/check_environment.py" > "$OUT/environment_after.json"
cmp "$OUT/environment_before.json" "$OUT/environment_after.json"
