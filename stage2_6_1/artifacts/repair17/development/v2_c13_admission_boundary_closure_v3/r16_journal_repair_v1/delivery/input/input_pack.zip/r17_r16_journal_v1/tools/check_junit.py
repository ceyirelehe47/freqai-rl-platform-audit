#!/usr/bin/env python3
"""Source-owned supplemental critical checks; no change to the old v3b policy."""
from pathlib import Path
import argparse,json,xml.etree.ElementTree as ET
COUNTS={'test_curriculum261_r17_c2_consumer':53,
        'test_curriculum261_r16_execgov':23,
        'test_curriculum261_r16_journal_serialization':37}
TOTAL={'targeted':291,'full':2181}

def check(path,scope='full'):
    root=ET.fromstring(Path(path).read_bytes());cases=list(root.iter('testcase'))
    ids=[(c.get('classname'),c.get('name')) for c in cases]
    if not cases or len(ids)!=len(set(ids)):raise ValueError('empty/duplicate identities')
    bad={tag:sum(c.find(tag) is not None for c in cases) for tag in ('failure','error','skipped')}
    if bad['failure'] or bad['error']:raise ValueError('actual testcase failure/error; do not rerun to green')
    suites=[s for s in root.iter('testsuite') if list(s.findall('testcase'))]
    for key,actual in [('tests',len(cases)),('failures',bad['failure']),('errors',bad['error']),('skipped',bad['skipped'])]:
        if sum(int(s.get(key,'0')) for s in suites)!=actual:raise ValueError('suite '+key+' contradicts cases')
    found={}
    for file,expected in COUNTS.items():
        selected=[c for c in cases if file in c.get('classname','').split('.')]
        if len(selected)!=expected:raise ValueError(f'critical {file}: {len(selected)} != {expected}')
        if any(c.find('skipped') is not None for c in selected):raise ValueError('critical skipped/xfail')
        found[file]=len(selected)
    if len(cases)!=TOTAL[scope]:raise ValueError(f'{scope} count: {len(cases)} != {TOTAL[scope]}')
    if scope=='targeted' and bad['skipped']:raise ValueError('targeted skip forbidden')
    if scope=='full':
        from r17_v2_c13_admission_guard import HISTORICAL_SKIP_IDS
        skipped={c.get('classname')+'::'+c.get('name') for c in cases if c.find('skipped') is not None}
        if skipped!=set(HISTORICAL_SKIP_IDS):raise ValueError('historical skip set changed')
    return {'ok':True,'scope':scope,'all_cases':len(cases),'passed':len(cases)-bad['skipped'],
            'skipped':bad['skipped'],'critical_counts':found,'critical_zero_skip':True}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('junit',type=Path)
    p.add_argument('--scope',choices=tuple(TOTAL),default='full');a=p.parse_args()
    try:print(json.dumps(check(a.junit,a.scope),indent=2))
    except Exception as exc:print(json.dumps({'ok':False,'error':str(exc)}));raise SystemExit(1)
