#!/usr/bin/env bash
set -euo pipefail
PACK=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
OUT=${1:?fresh absolute external output required}
D=/home/cryptorl/projects/crypto_rl
source "$D/activate-freqtrade.sh"; cd "$D"
[[ $OUT = /* && $OUT != /mnt/f/trading/freqai-rl-audit/* && ! -e $OUT ]] || exit 2
[[ -z ${R17_LOCAL_EXCERPT_TESTS:-} ]] || exit 2
mkdir -p "$OUT"
export PYTHONPATH="$D/stage2_6_1_runner:$D/src"
python "$PACK/tools/check_environment.py" > "$OUT/environment.json"
RUN="$OUT/monitored_run"
printf '%q ' bash "$D/stage2_6_1_runner/r17_monitored_entry.sh" fixture --max-seconds 180 -- \
 python "$PACK/tools/probe_journal.py" --module "$D/src/rl_curriculum/curriculum261_r16_execgov.py" --out "$OUT/probe" > "$OUT/command.txt"
printf '\n' >> "$OUT/command.txt"
set +e
R17_RUN_DIR="$RUN" bash "$D/stage2_6_1_runner/r17_monitored_entry.sh" fixture --max-seconds 180 -- \
 python "$PACK/tools/probe_journal.py" --module "$D/src/rl_curriculum/curriculum261_r16_execgov.py" --out "$OUT/probe" \
 > "$OUT/entry.stdout.log" 2> "$OUT/entry.stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$OUT/entry.rc"
exit "$RC"
