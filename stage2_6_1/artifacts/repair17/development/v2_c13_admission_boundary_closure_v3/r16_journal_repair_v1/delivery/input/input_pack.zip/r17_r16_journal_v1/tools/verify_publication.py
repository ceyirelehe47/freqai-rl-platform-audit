#!/usr/bin/env python3
"""Check already recorded push/ref bytes against local and verified E. No network."""
import argparse,json
from pathlib import Path
import apply_patch as ap
p=argparse.ArgumentParser();p.add_argument('--receipt',type=Path,required=True);a=p.parse_args()
r=ap.safe(a.receipt);repo=Path('/mnt/f/trading/freqai-rl-audit')
if (r/'push.rc').read_text().strip()!='0':raise RuntimeError('push did not return zero')
lines=(r/'remote_after.txt').read_text().strip().splitlines()
if len(lines)!=1:raise RuntimeError('remote receipt must contain exactly one ref')
fields=lines[0].split()
if len(fields)!=2 or fields[1]!='refs/heads/'+ap.BRANCH:raise RuntimeError('remote ref mismatch')
head=ap.git(repo,'rev-parse','HEAD').decode().strip()
identity=json.loads((r/'identity_after.json').read_bytes())
summary=json.loads((r/'SUMMARY.json').read_bytes())
values=[fields[0],head,identity['head'],(r/'head_before_push.txt').read_text().strip(),(r/'head_after_push.txt').read_text().strip()]
if any(v!=head for v in values):raise RuntimeError('HEAD changed around push or differs from observed remote')
value={'ok':True,'head':head,'remote_ref':fields[1],'engineering_verification':summary['engineering_verification'],
       'note':'push/ref original stdout/stderr/rc are retained; no additional commit required'}
with (r/'publication_check.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value,indent=2))
