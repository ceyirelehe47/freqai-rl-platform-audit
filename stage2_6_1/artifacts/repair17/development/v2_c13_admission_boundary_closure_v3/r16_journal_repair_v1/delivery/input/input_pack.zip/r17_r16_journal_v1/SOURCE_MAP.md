# 修改与复用范围

`PAYLOAD_SHA256.json` 固定实际代码，`PATCH.diff` 可人工审查，`tools/apply_patch.py` 校验 HEAD/branch/preimage 与新文件不存在，先保存恢复副本再应用。

两修改：R16 execgov 模块、旧 R16 execgov 测试文件。
两新增：测试 helper `r17_r16_journal_test_support.py`、37 case 测试 `test_curriculum261_r16_journal_serialization.py`。

`tests/` 只包含这三个需要同步到项目测试目录的文件；`package_tests/` 只用于独立工具测验，绝不能复制进项目以凑全量数量。`references/` 也是审查输入，不进生产 src。

旧 C2 四文件保持 blob：

```text
curriculum261_r17_c2_consumer.py       a22a253acdf5827656478147478995c20ea5b080
r17_c2_consumer_rehearsal.py           84f3087d6655f2b1076a4407437a19dba2f2ccb1
r17_c2_consumer_fixtures.py            985c212ab57c69b4005fa97245092b688fd99d49
test_curriculum261_r17_c2_consumer.py  5dd98e5d03c45ac4eb251024615aea5a791b77ca
```

不更改历史 `r17_v2_c13_source_lock.py`，不更改 v3b 治理 lock 十成员，不修改任何旧 artifact/claim。回归复用原 monitor/sampler、原 regression collector/reader、原全源树测试映射、原 C2 consumer 与七负例；safe-export 工具只调整本次全新 evidence 根。

本轮真实新增状态只在测试临时根和新外部证据目录；本轮 Git 增量只允许四个实现/测试路径与全新 `.../v2_c13_admission_boundary_closure_v3/r16_journal_repair_v1/`。活动 `run_supervision` 追加单列，不混入 C/E。
