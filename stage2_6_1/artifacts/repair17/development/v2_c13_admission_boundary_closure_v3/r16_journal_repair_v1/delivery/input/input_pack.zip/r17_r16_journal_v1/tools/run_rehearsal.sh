#!/usr/bin/env bash
set -euo pipefail
PACK=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
OUT=${1:?fresh report directory outside repository required}
D=/home/cryptorl/projects/crypto_rl
source "$D/activate-freqtrade.sh"; cd "$D"
[[ -z ${R17_LOCAL_EXCERPT_TESTS:-} ]] || exit 2
[[ $OUT = /* && $OUT != /mnt/f/trading/freqai-rl-audit/* && ! -e $OUT ]] || exit 2
mkdir -p "$OUT"
export PYTHONPATH="$D/stage2_6_1_runner:$D/src"
TMP=$(mktemp -d /tmp/r17_c2_consumer_XXXXXX)
printf '%s\n' "$TMP" > "$OUT/temp_output.txt"
RUN="$OUT/monitored_run"
printf '%q ' bash "$D/stage2_6_1_runner/r17_monitored_entry.sh" engineering --max-seconds 1200 -- \
 python "$D/stage2_6_1_runner/r17_c2_consumer_rehearsal.py" rehearse --out "$TMP/bundle" > "$OUT/command.txt"
printf '\n' >> "$OUT/command.txt"
set +e
R17_RUN_DIR="$RUN" bash "$D/stage2_6_1_runner/r17_monitored_entry.sh" engineering --max-seconds 1200 -- \
 python "$D/stage2_6_1_runner/r17_c2_consumer_rehearsal.py" rehearse --out "$TMP/bundle" \
 > "$OUT/entry.stdout.log" 2> "$OUT/entry.stderr.log"
RC=$?
set -e
printf '%s\n' "$RC" > "$OUT/entry.rc"
[[ $RC = 0 ]] || exit "$RC"
# The manifest was written by the actual new runner; do not create synthetic stdout.
INPUT=$(python - "$TMP/bundle/manifest.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1]))['input_sha256'])
PY
)
printf '%s\n' "$INPUT" > "$OUT/input_sha256.txt"
set +e
python "$D/stage2_6_1_runner/r17_c2_consumer_rehearsal.py" verify --bundle "$TMP/bundle" \
 --expected-input-sha256 "$INPUT" > "$OUT/verify.json" 2> "$OUT/verify.stderr.log"
VRC=$?
set -e
printf '%s\n' "$VRC" > "$OUT/verify.rc"
[[ $VRC = 0 ]] || exit "$VRC"
# The bundle consists of four regular files; copytree only after reader validation.
python - "$TMP/bundle" "$OUT/bundle" <<'PY'
from pathlib import Path
import shutil,sys
import r17_c2_consumer_rehearsal as r
r._index(Path(sys.argv[1]))
shutil.copytree(sys.argv[1],sys.argv[2])
PY
set +e
python "$PACK/tools/probe_consumer.py" --bundle "$TMP/bundle" --input-sha256 "$INPUT" \
 --out "$TMP/negative_cases" > "$OUT/negative_cases.json" 2> "$OUT/negative_cases.stderr.log"
NRC=$?
set -e
printf '%s\n' "$NRC" > "$OUT/negative_cases.rc"
[[ $NRC = 0 ]] || exit "$NRC"
python "$PACK/tools/archive_evidence.py" export --source "$TMP/negative_cases" --out "$OUT/negative_cases" \
 > "$OUT/negative_export.json"
