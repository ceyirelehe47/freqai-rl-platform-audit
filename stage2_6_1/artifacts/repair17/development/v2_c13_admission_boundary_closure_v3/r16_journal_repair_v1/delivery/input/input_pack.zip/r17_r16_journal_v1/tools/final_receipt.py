#!/usr/bin/env python3
"""Read-only post-E verification. One full reader call; no pytest or Git writes.

Always writes a fresh external SUMMARY, including on failure. Never changes a
previous run, source lock, claim or healthy-package manifest.
"""
from __future__ import annotations
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
import apply_patch as ap
import archive_evidence as ar
from protected_snapshot import snapshot
REPO=Path('/mnt/f/trading/freqai-rl-audit')
DEPLOY=Path('/home/cryptorl/projects/crypto_rl')


def dump(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')


def candidate_identity(repo,candidate):
    if ap.git(repo,'rev-parse',candidate+'^').decode().strip()!=ap.BASELINE:
        raise RuntimeError('candidate parent is not the pinned failed C2 HEAD')
    changed=set(ap.git(repo,'diff','--name-only',ap.BASELINE,candidate).decode().splitlines())
    if changed!=set(ap.PAYLOAD.values()):raise RuntimeError('candidate changed beyond four allowed paths')
    for rel,body in ap.payload().items():
        if ap.git(repo,'show',candidate+':'+rel)!=body:raise RuntimeError('candidate payload mismatch: '+rel)
    for rel,oid in ap.C2_PINS.items():
        if ap.git(repo,'rev-parse',candidate+':'+rel).decode().strip()!=oid:raise RuntimeError('C2 drifted')
    ap.git(repo,'merge-base','--is-ancestor',candidate,'HEAD')


def invoke(argv,out,label):
    start=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    rc=None;error=None
    with (out/(label+'.stdout.log')).open('xb') as f,(out/(label+'.stderr.log')).open('xb') as e:
        try:rc=subprocess.run(argv,cwd=DEPLOY,stdout=f,stderr=e,timeout=300).returncode
        except subprocess.TimeoutExpired as exc:error=str(exc)
    dump(out/(label+'.command.json'),{'argv':argv,'cwd':str(DEPLOY),'started_utc':start,
         'ended_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'rc':rc,'timeout':error})
    (out/(label+'.rc')).write_text(('TIMEOUT' if rc is None else str(rc))+'\n')
    if error or rc:raise RuntimeError(label+' failed; see original stdout/stderr/rc')
    value=json.loads((out/(label+'.stdout.log')).read_bytes())
    if value.get('ok') is not True:raise RuntimeError(label+' result not ok')
    return value


def execute(a):
    candidate_identity(REPO,a.candidate)
    sys.path[:0]=[str(DEPLOY/'stage2_6_1_runner'),str(DEPLOY/'src')]
    import r17_c2_consumer_rehearsal as c2
    import r17_v2_c13_admission_guard as guard
    from rl_curriculum import curriculum261_r16_execgov as r16
    from check_environment import verify_source_bindings
    from check_junit import check
    def identity():
        sources=c2.source_identity()
        sources['rl_curriculum.curriculum261_r16_execgov']={
            'file':str(Path(r16.__file__).absolute()),'sha256':hashlib.sha256(Path(r16.__file__).read_bytes()).hexdigest()}
        return {'head':ap.git(REPO,'rev-parse','HEAD').decode().strip(),'sources':sources}
    before=identity();dump(a.out/'identity_before.json',before)
    dump(a.out/'candidate_history.json',guard.verify_candidate_history(REPO,a.candidate,a.candidate))
    dump(a.out/'source_bindings.json',verify_source_bindings(REPO,DEPLOY,before['sources'],a.candidate))
    protected=json.loads(a.protected_before.read_bytes());current=snapshot(REPO)
    if protected!=current:raise RuntimeError('protected objects changed before final verify')
    root=REPO/ar.EVIDENCE_ROOT;delivery=root/'delivery'
    tree=ar.file_index(root);dump(a.out/'tree_before.json',tree)
    dump(a.out/'export_check.json',ar.verify_export(delivery))
    for path in ('targeted/entry.rc','probe/entry.rc','rehearsal/entry.rc','full_regression/entry.rc'):
        if (delivery/path).read_text().strip()!='0':raise RuntimeError('recorded stage did not pass: '+path)
    probe=json.loads((delivery/'probe/probe/SUMMARY.json').read_bytes())
    if probe.get('ok') is not True or probe.get('baseline_expected_race_reproduced') is not True or probe.get('patched_serialized_lifecycle_completed') is not True:
        raise RuntimeError('red/green probe missing/failed')
    dump(a.out/'new_critical_junit.json',check(delivery/'full_regression/monitored_run/junit.xml','full'))
    full=invoke([sys.executable,str(DEPLOY/'stage2_6_1_runner/r17_v2_c13_regression_evidence.py'),
           'verify','--package',str(delivery/'full_regression/healthy_package')],a.out,'full_verify')
    if full.get('validation_scope')!='full' or full.get('admission_eligible') is not False:
        raise RuntimeError('wrong full-reader scope/authority')
    earlier=json.loads((delivery/'full_regression/verify_C.json').read_bytes())
    if earlier.get('package_sha256')!=full.get('package_sha256'):raise RuntimeError('healthy package digest changed since C')
    digest=(delivery/'rehearsal/input_sha256.txt').read_text().strip()
    consumed=invoke([sys.executable,str(DEPLOY/'stage2_6_1_runner/r17_c2_consumer_rehearsal.py'),
              'verify','--bundle',str(delivery/'rehearsal/bundle'),'--expected-input-sha256',digest],a.out,'c2_verify')
    counts=consumed.get('zero_call_counts',{})
    if len(counts)!=16 or any(type(v) is not int or v!=0 for v in counts.values()):raise RuntimeError('C2 sentinel count mismatch')
    if consumed.get('business_statistics')!='NOT_RUN' or consumed.get('formal_qualification')!='NOT_ISSUED' or consumed.get('launch_authorized') is not False:
        raise RuntimeError('C2 scope was promoted')
    after=identity();dump(a.out/'identity_after.json',after)
    if before!=after or tree!=ar.file_index(root) or protected!=snapshot(REPO):raise RuntimeError('source/evidence/protected drift during verify')
    dump(a.out/'protected_check.json',{'unchanged':True,'entries':len(protected),
               'baseline_sha256':hashlib.sha256(a.protected_before.read_bytes()).hexdigest()})
    return {'engineering_verification':'PASS','candidate':a.candidate,'head':after['head'],
        'scope':'R16 journal serialization + C2 synthetic consumer regression integration',
        'business_statistics':'NOT_RUN','formal_qualification':'NOT_ISSUED','launch_authorized':False,
        'old_C2_v1_run':'FAIL_RETAINED','v3b':'CLOSED_PASS_UNCHANGED'}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--candidate',required=True)
    p.add_argument('--protected-before',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args(argv)
    ap.safe(a.out)
    if a.out.is_relative_to(REPO) or os.path.lexists(a.out):raise ValueError('fresh external return path required')
    a.out.mkdir(parents=True)
    try:
        if sys.version_info[:3]!=(3,11,16):raise RuntimeError('WSL Python 3.11.16 required')
        result=execute(a);rc=0
    except Exception as exc:
        result={'engineering_verification':'FAIL','error':type(exc).__name__,'message':str(exc),
                'candidate':a.candidate,'business_statistics':'NOT_RUN','formal_qualification':'NOT_ISSUED',
                'launch_authorized':False,'old_failures_retained':True};rc=1
    dump(a.out/'SUMMARY.json',result)
    (a.out/'SUMMARY.md').write_text('# R16 journal / C2 regression return\n\n'+json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2));return rc
if __name__=='__main__':raise SystemExit(main())
