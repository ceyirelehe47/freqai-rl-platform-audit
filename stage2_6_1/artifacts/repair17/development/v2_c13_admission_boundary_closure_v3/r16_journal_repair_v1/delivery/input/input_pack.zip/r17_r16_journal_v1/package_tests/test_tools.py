from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import apply_patch as ap
import archive_evidence as ar
import final_receipt as fr
import capture_input_pack as cp


def setup_tree(root):
    for path in (ROOT/'references/unchanged_c2').rglob('*.py'):
        dest=root/path.relative_to(ROOT/'references/unchanged_c2');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(path.read_bytes())
    for rel,source in [
      ('stage2_6_1/src/rl_curriculum/curriculum261_r16_execgov.py','curriculum261_r16_execgov.before.py'),
      ('stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_execgov.py','test_curriculum261_r16_execgov.before.py')]:
        dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/'references'/source).read_bytes())
    return root


def init_git(repo):
    ap.git(repo,'init','-q');ap.git(repo,'config','user.name','Test');ap.git(repo,'config','user.email','test@example.invalid')
    ap.git(repo,'add','.');ap.git(repo,'commit','-qm','preimage')
    return ap.git(repo,'rev-parse','HEAD').decode().strip()


def test_exact_full_source_preimages():
    assert ap.blob((ROOT/'references/curriculum261_r16_execgov.before.py').read_bytes())=='00a000438e88898d59062034abcf5ae3ef5d2b97'
    assert ap.blob((ROOT/'references/test_curriculum261_r16_execgov.before.py').read_bytes())=='f59df418b16ae27607a3d5dc51e78eb7f6230fe2'


def test_c2_pin_bytes_unchanged():
    for path,oid in ap.C2_PINS.items():assert ap.blob((ROOT/'references/unchanged_c2'/path).read_bytes())==oid


def test_payload_four_files_compiles():
    data=ap.payload();assert len(data)==4
    assert len(ap.PREIMAGES)==2
    assert not any('source_lock' in k for k in data)


def test_apply_actual_preimages_and_recovery(tmp_path):
    repo=setup_tree(tmp_path/'repo');data=ap.check_images(repo)
    result=ap.apply_images(repo,data,tmp_path/'recovery')
    assert set(result)==set(data)
    assert all((repo/p).read_bytes()==b for p,b in data.items())
    for rel,oid in ap.PREIMAGES.items():assert ap.blob((tmp_path/'recovery'/rel).read_bytes())==oid
    with pytest.raises(ap.ApplyError):ap.check_images(repo)


def test_diff_applies_to_exact_original_git_tree(tmp_path):
    repo=setup_tree(tmp_path/'repo');init_git(repo)
    ap.git(repo,'apply','--check',str(ROOT/'PATCH.diff'))
    ap.git(repo,'apply',str(ROOT/'PATCH.diff'))
    assert all((repo/p).read_bytes()==b for p,b in ap.payload().items())


def test_candidate_identity_binds_real_git(tmp_path,monkeypatch):
    repo=setup_tree(tmp_path/'repo');base=init_git(repo)
    ap.apply_images(repo,ap.check_images(repo),tmp_path/'recovery')
    ap.git(repo,'add','.');ap.git(repo,'commit','-qm','candidate');c=ap.git(repo,'rev-parse','HEAD').decode().strip()
    monkeypatch.setattr(ap,'BASELINE',base)
    fr.candidate_identity(repo,c)
    (repo/'unknown.txt').write_text('x');ap.git(repo,'add','.');ap.git(repo,'commit','-qm','evidence')
    # candidate remains bound; full history policy is independently executed by WSL reader.
    fr.candidate_identity(repo,c)


@pytest.mark.parametrize('case',['changed','new_exists','symlink','changed_c2'])
def test_bad_application_never_writes(tmp_path,case):
    repo=setup_tree(tmp_path/'repo')
    target=repo/next(iter(ap.PREIMAGES))
    if case=='changed':target.write_bytes(target.read_bytes()+b'\n# changed')
    if case=='new_exists':(repo/ap.PAYLOAD['tests/r17_r16_journal_test_support.py']).write_text('unknown')
    if case=='symlink':body=target.read_bytes();target.unlink();other=tmp_path/'other';other.write_bytes(body);target.symlink_to(other)
    if case=='changed_c2':(repo/next(iter(ap.C2_PINS))).write_text('changed')
    with pytest.raises(ap.ApplyError):ap.check_images(repo)


def test_archive_regular_export_and_actual_index(tmp_path):
    repo=tmp_path/'repo';repo.mkdir();(repo/'README').write_text('x');init_git(repo)
    src=tmp_path/'raw';src.mkdir();(src/'stdout.log').write_text('actual bytes\n')
    out=repo/ar.EVIDENCE_ROOT/'delivery'
    ar.export_tree(src,out);assert ar.verify_export(out)['ok']
    ap.git(repo,'add','-f',ar.EVIDENCE_ROOT)
    assert ar.verify_staged(repo)['ok']


def test_archive_rejects_live_unknown_symlink(tmp_path):
    src=tmp_path/'src';src.mkdir();(src/'bad').symlink_to('/tmp')
    with pytest.raises(ar.ExportError):ar.export_tree(src,tmp_path/'out')
    assert not (tmp_path/'out').exists()


def test_staged_missing_ignored_log_rejected(tmp_path):
    repo=tmp_path/'repo';repo.mkdir();(repo/'.gitignore').write_text('*.log\n');init_git(repo)
    src=tmp_path/'src';src.mkdir();(src/'output.log').write_text('byte evidence')
    out=repo/ar.EVIDENCE_ROOT/'delivery';ar.export_tree(src,out)
    ap.git(repo,'add',ar.EVIDENCE_ROOT)
    with pytest.raises(ar.ExportError):ar.verify_staged(repo)


@pytest.mark.parametrize('bad',[False,True])
def test_actual_input_zip_capture(tmp_path,monkeypatch,bad):
    pack=tmp_path/'pkg';pack.mkdir();body=b'actual payload';(pack/'file.txt').write_bytes(body)
    sums=hashlib.sha256(body).hexdigest()+'  file.txt\n';(pack/'SHA256SUMS').write_text(sums)
    z=tmp_path/'input.zip'
    with zipfile.ZipFile(z,'w') as f:
        f.writestr('pkg/file.txt',b'bad' if bad else body);f.writestr('pkg/SHA256SUMS',sums)
    monkeypatch.setattr(ap,'ROOT',pack)
    if bad:
        with pytest.raises(ValueError):cp.capture(z,tmp_path/'captured')
        assert not (tmp_path/'captured').exists()
    else:
        result=cp.capture(z,tmp_path/'captured');assert result['ok']
        assert (tmp_path/'captured/input_pack.zip').read_bytes()==z.read_bytes()
        assert (tmp_path/'captured/input_pack.sha256').stat().st_size>64


def test_original_noncompetition_tests_byte_identical():
    before=(ROOT/'references/test_curriculum261_r16_execgov.before.py').read_text().split('class TestRealSubprocessCompetition:')[0]
    after=(ROOT/'tests/test_curriculum261_r16_execgov.py').read_text().split('class TestRealSubprocessCompetition:')[0]
    assert before==after
