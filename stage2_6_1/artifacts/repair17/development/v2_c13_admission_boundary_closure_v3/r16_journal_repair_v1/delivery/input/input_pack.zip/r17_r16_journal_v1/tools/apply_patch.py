#!/usr/bin/env python3
"""Pinned four-file patch. Default checks only; explicit --apply saves preimages.

No git write, network, relock, deployment, generation or state repair. Partial
application errors preserve recovery evidence and stop, never reset unknown work.
"""
from __future__ import annotations
import argparse, hashlib, json, os, stat, subprocess, sys, tempfile
from pathlib import Path
BASELINE='3a0235470996b8b8439d6f565e0eb65fea1c97b4'
BRANCH='route-c-stage2-6-1-repair17'
ROOT=Path(__file__).resolve().parents[1]
PAYLOAD={
 'implementation/curriculum261_r16_execgov.py':'stage2_6_1/src/rl_curriculum/curriculum261_r16_execgov.py',
 'tests/test_curriculum261_r16_execgov.py':'stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_execgov.py',
 'tests/r17_r16_journal_test_support.py':'stage2_6_1/tests/route_c_stage2_6_1/r17_r16_journal_test_support.py',
 'tests/test_curriculum261_r16_journal_serialization.py':'stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_journal_serialization.py',
}
PREIMAGES={
 'stage2_6_1/src/rl_curriculum/curriculum261_r16_execgov.py':'00a000438e88898d59062034abcf5ae3ef5d2b97',
 'stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r16_execgov.py':'f59df418b16ae27607a3d5dc51e78eb7f6230fe2',
}
C2_PINS={
 'stage2_6_1/src/rl_curriculum/curriculum261_r17_c2_consumer.py':'a22a253acdf5827656478147478995c20ea5b080',
 'stage2_6_1/runner/r17_c2_consumer_rehearsal.py':'84f3087d6655f2b1076a4407437a19dba2f2ccb1',
 'stage2_6_1/tests/route_c_stage2_6_1/r17_c2_consumer_fixtures.py':'985c212ab57c69b4005fa97245092b688fd99d49',
 'stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_c2_consumer.py':'5dd98e5d03c45ac4eb251024615aea5a791b77ca',
}
class ApplyError(RuntimeError):pass

def blob(data):return hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()

def git(repo,*args):
    p=subprocess.run(['git','-C',str(repo),*args],capture_output=True,timeout=120)
    if p.returncode:raise ApplyError(f'git {args}: {p.stderr.decode(errors="replace")}')
    return p.stdout

def safe(path):
    path=Path(path)
    if not path.is_absolute() or '..' in path.parts:raise ApplyError('absolute nonescaping path required')
    probe=Path(path.anchor)
    for part in path.parts[1:]:
        probe/=part
        try:s=probe.lstat()
        except FileNotFoundError:continue
        if stat.S_ISLNK(s.st_mode):raise ApplyError('symlink rejected: '+str(probe))
        if probe!=path and not stat.S_ISDIR(s.st_mode):raise ApplyError('nondirectory parent')
    return path

def payload():
    index=json.loads((ROOT/'PAYLOAD_SHA256.json').read_bytes())
    if set(index)!=set(PAYLOAD):raise ApplyError('payload set changed')
    result={}
    for source,dest in PAYLOAD.items():
        p=safe(ROOT/source)
        if not stat.S_ISREG(p.stat().st_mode):raise ApplyError('not regular payload')
        body=p.read_bytes()
        if hashlib.sha256(body).hexdigest()!=index[source]:raise ApplyError('payload checksum mismatch: '+source)
        compile(body,str(p),'exec');result[dest]=body
    return result

def check_images(repo):
    data=payload()
    for rel in data:
        target=safe(repo/rel)
        if not target.parent.is_dir():raise ApplyError('missing expected parent: '+rel)
        if rel in PREIMAGES:
            if not target.is_file() or blob(target.read_bytes())!=PREIMAGES[rel]:
                raise ApplyError('preimage mismatch: '+rel)
        elif os.path.lexists(target):raise ApplyError('new target already exists: '+rel)
    for rel,oid in C2_PINS.items():
        if blob(safe(repo/rel).read_bytes())!=oid:raise ApplyError('C2 payload changed: '+rel)
    return data

def preflight(repo):
    safe(repo)
    if git(repo,'rev-parse','HEAD').decode().strip()!=BASELINE:raise ApplyError('wrong HEAD; do not reset')
    if git(repo,'branch','--show-current').decode().strip()!=BRANCH:raise ApplyError('wrong branch')
    if git(repo,'diff','--cached','--name-only').strip():raise ApplyError('unknown staged changes')
    roots=('stage2_6_1/src','stage2_6_1/runner','stage2_6_1/tests','.gitattributes')
    if git(repo,'status','--porcelain=v1','--',*roots).strip():raise ApplyError('source/test/runner not clean')
    for rel,oid in {**PREIMAGES,**C2_PINS}.items():
        if git(repo,'rev-parse',BASELINE+':'+rel).decode().strip()!=oid:raise ApplyError('baseline object mismatch')
    return check_images(repo)

def fsync_dir(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def apply_images(repo,data,recovery):
    safe(recovery)
    if recovery.is_relative_to(repo) or repo.is_relative_to(recovery) or os.path.lexists(recovery):
        raise ApplyError('fresh recovery directory outside repo required')
    recovery.mkdir(parents=True)
    check_images(repo)
    before={}
    for rel in PREIMAGES:
        body=(repo/rel).read_bytes();p=recovery/rel;p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as f:f.write(body);f.flush();os.fsync(f.fileno())
        before[rel]={'git_blob':blob(body),'sha256':hashlib.sha256(body).hexdigest()}
    (recovery/'RECOVERY.json').write_text(json.dumps({'baseline':BASELINE,'files':before},indent=2)+'\n')
    written=[]
    for rel,body in data.items():
        p=safe(repo/rel)
        if rel in PREIMAGES:
            if blob(p.read_bytes())!=PREIMAGES[rel]:raise ApplyError('preimage changed while applying')
            fd,name=tempfile.mkstemp(prefix='.'+p.name+'.',dir=p.parent)
            try:
                with os.fdopen(fd,'wb') as f:f.write(body);f.flush();os.fsync(f.fileno())
                os.chmod(name,stat.S_IMODE(p.stat().st_mode))
                if blob(p.read_bytes())!=PREIMAGES[rel]:raise ApplyError('preimage raced; temp retained')
                os.replace(name,p)
            except BaseException:raise
        else:
            fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644)
            with os.fdopen(fd,'wb') as f:f.write(body);f.flush();os.fsync(f.fileno())
        fsync_dir(p.parent)
        if p.read_bytes()!=body:raise ApplyError('writeback mismatch; keep recovery and stop')
        written.append(rel)
    return written

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--apply',action='store_true');parser.add_argument('--recovery',type=Path)
    a=parser.parse_args(argv)
    if a.apply and a.recovery is None:parser.error('--apply requires --recovery')
    try:
        data=preflight(a.repo);written=apply_images(a.repo,data,a.recovery) if a.apply else []
        print(json.dumps({'ok':True,'baseline':BASELINE,'applied':a.apply,'written':written,
              'files':{r:hashlib.sha256(b).hexdigest() for r,b in data.items()},
              'C2_files_unchanged':True,'source_locks_modified':False},indent=2));return 0
    except Exception as exc:
        print(json.dumps({'ok':False,'error':type(exc).__name__,'message':str(exc),'do_not_reset':True}));return 2
if __name__=='__main__':raise SystemExit(main())
