#!/usr/bin/env python3
"""Read-only lstat snapshots. Historical symlinks are recorded, never followed."""
from pathlib import Path
import argparse, base64, hashlib, json, os, stat

ROOTS = (
 'v2_c13_engineering_delivery', 'v2_c13_engineering_v2_delivery',
 'v2_c13_postrun_governance_closure', 'c2_calibration_launch_preparation',
 'v2_c13_engineering_claim', 'v2_c13_governance_authority_evidence_closure_v2',
 'v2_c13_admission_boundary_closure_v3',
)
EXCLUDE='v2_c13_admission_boundary_closure_v3/r16_journal_repair_v1'

def snapshot(repo):
    base=repo/'stage2_6_1/artifacts/repair17/development';rows={}
    def visit(p):
        rel=p.relative_to(base).as_posix()
        if rel==EXCLUDE or rel.startswith(EXCLUDE+'/'):return
        st=p.lstat()
        if stat.S_ISLNK(st.st_mode):
            raw=os.readlink(os.fsencode(p))
            rows[rel]={'kind':'symlink','target_base64':base64.b64encode(raw).decode(),'sha256':hashlib.sha256(raw).hexdigest()}
        elif stat.S_ISREG(st.st_mode):
            from archive_evidence import regular_meta
            rows[rel]=regular_meta(p)
        elif stat.S_ISDIR(st.st_mode):
            rows[rel]={'kind':'directory'}
            for child in sorted(p.iterdir()):visit(child)
        else:
            rows[rel]={'kind':'special','mode':st.st_mode}
    for name in ROOTS:
        p=base/name
        if os.path.lexists(p):visit(p)
        else:rows[name]={'kind':'absent'}
    # The journal probe must not touch real R16 state either. Record the two
    # known layouts and an explicitly configured state root, without following
    # symlinks or creating a missing root.
    extra = {
        '__r16_release_state': repo/'stage2_6_1/artifacts/route_c_stage2_6_1_repair16',
        '__r16_deployed_state': Path('/home/cryptorl/projects/crypto_rl/artifacts/route_c_stage2_6_1_repair16'),
    }
    configured = os.environ.get('CURRICULUM261_R16_STATE_ROOT')
    if configured:
        if not Path(configured).is_absolute():raise ValueError('R16 state override is not absolute')
        extra['__r16_configured_state'] = Path(configured)
    def walk_extra(p,key):
        if not os.path.lexists(p):rows[key]={'kind':'absent'};return
        st=p.lstat()
        if stat.S_ISLNK(st.st_mode):
            raw=os.readlink(os.fsencode(p));rows[key]={'kind':'symlink','target_base64':base64.b64encode(raw).decode(),'sha256':hashlib.sha256(raw).hexdigest()}
        elif stat.S_ISREG(st.st_mode):
            from archive_evidence import regular_meta
            rows[key]=regular_meta(p)
        elif stat.S_ISDIR(st.st_mode):
            rows[key]={'kind':'directory'}
            for c in sorted(p.iterdir()):walk_extra(c,key+'/'+c.name)
        else:rows[key]={'kind':'special','mode':st.st_mode}
    for key,path in extra.items():walk_extra(path,key)
    return rows

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--compare',type=Path)
    a=p.parse_args();result=snapshot(a.repo)
    if a.compare:
        previous=json.loads(a.compare.read_bytes())
        changed=[k for k in set(result)|set(previous) if result.get(k)!=previous.get(k)]
        print(json.dumps({'unchanged':not changed,'changed':sorted(changed),'entries':len(result)},indent=2))
        return bool(changed)
    print(json.dumps(result,sort_keys=True,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
