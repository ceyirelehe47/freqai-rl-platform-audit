# R17 下一轮：C3 校准统计接线、测试入口归并与明确推送

## 0. 本轮交付性质与停点

这是**已实现代码的任务包**。不要另写一版校准统计，不重做备援装配器或监护系统。

```text
仓库：ceyirelehe47/freqai-rl-platform-audit
分支：route-c-stage2-6-1-repair17
远端接手基线：5607876b213af825d618868ba89cb0705cfdc472
已完成的真实批次：c3reserve_v1_20260910T050655_93442
固定环境：CryptoRL-Ubuntu-24.04 / cryptorl / Python 3.11.16 / conda freqtrade-rl
发布库：/mnt/f/trading/freqai-rl-audit
部署项目：/home/cryptorl/projects/crypto_rl
```

**这次明确要求：完成验证后，将代码、本地已有测试入口小修、必要勘误和原始证据，以普通提交推送到上面的目标分支，回报完整 SHA。** 应用器只不“自动代做”stage/commit/push，不是禁止 Agent 在交付步骤执行它们。

用户已经让上一份测试入口小修在本地完成，但上一份任务包安排了“随下一轮入库”。不要因未推送认定其没做，也不要回滚、重复覆盖它。本包应用器接受两种精确状态：原测试定位；或已应用的 `stage2_6_1_runner` 唯一定位增量。已经修改好的测试保持原字节，随本轮一起入库。其他执行面漂移须停下核对，不能改守卫迁就。

### 本轮到底接什么

现存有限备援批次 → 选定的真实 episode 评估行 → **现有 R4 pair-level 证据表/统计原语** → **现有 R5 strict per-corpus 条件** → 两分区分别记录 → 新的组合交付。

这是一段真实的 calibration **统计消费端**接线，**不是完整 calibration 运行**。旧批次只有每分区×rung 2 个 pair，而且走 raw production observation 评估。故本轮不声称已运行 V2 fit/transform、不授权 full-size calibration、不建立最终 A/B、不训练。

不用重跑旧批次、不添加新 namespace、不消耗任何新的生成坐标、不启动 policy evaluator。calibration 桥接运行只读旧业务原件，监护入口照常启动其自己的资源采样器；“零新 episode 生成”不等于禁用既有监护。

## 1. 保留的已通过结论

有限备援 v1 的真实 16 pair、32 episode、生成选择先于评估、正常负收益保留、组合隔离交付保持通过。原生 Windows sampler 与旧 full2 隔离工作保持通过。

旧 p52／旧 rt3、旧 r3 遥测完整性 FAIL、R16 C2 统计 FAIL、C3 PPO Branch D 互不追认。bootstrap 或 pooled 均不能救回一个 strict 分区失败。工程 validation 不改称 frozen holdout。

## 2. 代码范围

新增：

```text
stage2_6_1/runner/r17_c3_calibration_bridge.py
stage2_6_1/runner/r17_c3_calibration_authority.py
stage2_6_1/runner/r17_c3_calibration_delivery.py
stage2_6_1/runner/r17_c3_calibration_source_lock.py  # 应用器生成
stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_c3_calibration_bridge.py
```

唯一可能改动的已有文件是原 reserve 测试文件的定位小修；如果已经修好，本包不再写它。**不改 src、API、registry、namespace 数量、旧 source_lock、参数、kappa、旧报告/产物/启动脚本。** 当前 registry 仍为 89/4。

- 运行端调用仓库 `curriculum261_r4_pairs.build_pair_evidence_table`、`difficulty_series`、`margin_series`、`cluster_stats`、`bootstrap_mean_ci`、`table_series`，及 `curriculum261_r5_pairs.corpus_conditions_r5`。
- 只读验证端重算 A/B 均值、pair-cluster n/SE、差值及 strict 布尔关系；不 import 生成/评估业务栈。
- pair、交易次数是元数据，不作为第六类收益。使用固定五策略白名单重算符号计数，纠正旧报告的 192→160 口径。
- 当前 raw 输入的历史 `difficulty_metric` 不是新统计的来源；R4/R5 难度按 `reference_pair - always_flat_pair` 计算。
- bootstrap 是非 binding 辅助统计；运行时由仓库原函数计算，冷读检查字节、元数据和区间合法性，**不声称仅用标准库重新执行了 NumPy bootstrap**。

## 3. 应用与零生成接口检查

把包解压到仓库之外的全新目录，不覆盖旧任务包。沿用固定 Python，不升级。

```bash
source ~/projects/crypto_rl/activate-freqtrade.sh
BUNDLE=/绝对路径/r17_c3_calibration_bridge_pack
REPO=/mnt/f/trading/freqai-rl-audit
RUNNER=$HOME/projects/crypto_rl/stage2_6_1_runner
EVIDENCE=$(mktemp -d /tmp/r17_calbridge_accept_XXXXXX)
cd "$BUNDLE"
sha256sum -c SHA256SUMS > "$EVIDENCE/checksums.log" 2>&1
python apply_patch.py --repo "$REPO" --check \
  --patch-out "$EVIDENCE/candidate.patch" > "$EVIDENCE/apply_check.json" 2> "$EVIDENCE/apply_check.err"
python apply_patch.py --repo "$REPO" --apply \
  > "$EVIDENCE/apply.json" 2> "$EVIDENCE/apply.err"
bash "$REPO/stage2_6_1/runner/r17_sync.sh" > "$EVIDENCE/sync.log" 2>&1
python "$BUNDLE/tools/check_installed_interfaces.py" --runner "$RUNNER" \
  > "$EVIDENCE/interfaces.json" 2> "$EVIDENCE/interfaces.err"
```

逐命令捕获真实 rc（不要只靠最后一条 0；出错立即停）。应用器保护整个 src/runner/tests 面相对基线的漂移，唯独允许精确的本地测试定位小修；文档/已有 artifacts 不被覆盖。

接口检查会调用**实际项目 R4/R5 原语**处理一个明确的合成小表，并将生成器及 policy evaluator 的调用替换为“只要被调用就报错”的哨兵。它不是新真实课程运行，也不是实际 calibration 通过证明。

本轮沿用包内参数和统计合同。不以接口失败为由跳过 source_lock、更换模块路径或修改门槛。环境导入失败不是统计 FAIL，必须单独保存错误。

## 4. 局部测试（不用再应用旧小修）

```bash
cd "$BUNDLE"
python -m pytest -q tests --junitxml="$EVIDENCE/pack_tests.xml" \
  > "$EVIDENCE/pack_tests.stdout" 2> "$EVIDENCE/pack_tests.stderr"
# 紧接上条保存：printf '%s\n' "$?" > "$EVIDENCE/pack_tests.rc"

cd ~/projects/crypto_rl
python -m pytest -q \
  tests/route_c_stage2_6_1/test_curriculum261_r17_c3_reserve_batch.py \
  tests/route_c_stage2_6_1/test_curriculum261_r17_c3_calibration_bridge.py \
  --junitxml="$EVIDENCE/deployed_tests.xml" \
  > "$EVIDENCE/deployed_tests.stdout" 2> "$EVIDENCE/deployed_tests.stderr"
```

新测试能识别任务包、发布树、部署树三种目录名；不能通过 `--ignore` 或过滤新测试来得到绿色。先核验 collect，再执行。原 reserve 69 项应该保持；新测试数量以实际 JUnit 为准，不删测试凑数。

## 5. 一次只读工程接线

```bash
bash "$BUNDLE/tools/run_readonly_handoff.sh" "$EVIDENCE/handoff"
```

脚本只创建本次的新日志目录和受监护 run，旧输入固定为：

```text
<run_supervision>/runs/c3reserve_v1_20260910T050655_93442/c3_finite_reserve
manifest Git blob: 0ef26c7edd2a3b41aac345a751304fb4df2b75bc
```

输入路径可复制重定位，但必须是这个已验收内容身份；不能换一个 v1 也合法的其他批次来取得好统计。不存在的旧原件先找已归档字节相同副本，不重新生成。

本次输出在 `<新run>/c3_calibration_bridge/`：原输入只读副本、plan、选定 episode 行、两个 corpus 的 pair 表/mean/SE/CI/strict 条件、五策略符号统计、result 和 manifest。命令处理完毕后由组合 verifier 复核新监护 required 原字节和 bridge 内容。

### 三种结论分别记录

| 结论 | 意义 |
|---|---|
| `engineering_consumer_complete=true`，run/delivery rc=0 | 输入→现有统计消费端接线正确、产物完整。 |
| `statistical_diagnostic_pass=false` / verdict=FAIL | 固定小样本在原 strict 条件下未通过；**必须保留，不触发换样本、扩样或改门槛**。接线仍可完成。 |
| `calibration_qualified=false` | 本轮恒为 false：raw 输入、每层2个pair、没有V2完整流程。即使统计恰好通过，也不能升格。 |

代码异常、证据错配、源漂移、写入失败则是 rc=3，不能解释成可接受的统计结果；不足额/损坏旧批次在进入统计前拒绝。失败目录保留，不覆盖。

## 6. 组合隔离与一次常规完整回归

接线成功（允许其统计诊断 FAIL）之后：

```bash
RD=$(cat "$EVIDENCE/handoff/run_path.txt")
python "$BUNDLE/tools/check_isolated_delivery.py" \
  --record "$RD/run_record.json" --runner "$RUNNER" \
  > "$EVIDENCE/isolation.outer.stdout" 2> "$EVIDENCE/isolation.outer.stderr"
```

这是此前 unshare/user/mount 隔离模式的复用。五例为健康、bridge缺件、bridge追加、bridge等长篡改、telemetry追加，预期 0/1/1/1/1；原根前后不可读，payload只读且字节不变。失败原因要落在实际损坏处；导入/挂载失败不算负例成功。该脚本作者侧仅完成语法检查，用户 WSL 的真实隔离结果必须另行归档。

之后只做**一次本轮本来需要的常规回归**：

```bash
bash "$BUNDLE/tools/run_full_regression.sh" "$EVIDENCE/full"
```

新脚本保留 R17-first 顺序，明确包含旧 reserve 和新 bridge 两个文件，**没有 `grep -v c3_reserve_batch`／`--ignore`**。不要修改历史 `full_regression_run2/launcher.sh`。本包只新增测试时，计数应在既有 1858 collected 的基础上增加新测试数；以 `test_files.txt` 和真实 JUnit 为准，不声称默认字母顺序已通过。

若完整回归失败，不自动再跑第二遍、不用后一次结果覆盖前一次。不为缺一个 rc 再跑整套；找现存外层原件，确实未保存就如实标注。

## 7. 本轮必须提交和推送（区别于上一份小修包）

完成上述验证后，**同轮**提交与推送，不能只回报“本机完成”。即使某一环节失败，也可提交当前明确未通过的诊断交付，但不能自报 PASS。

归档到全新的 `stage2_6_1/artifacts/repair17/development/c3_calibration_bridge_delivery/`。不存在才创建，保留每次失败子目录。至少包含：

- 本包、实际应用diff/检查、同步与接口日志，及源码/部署 SHA 对照。
- 上一份路径小修的现存部署69项日志（若未保存，如实说明；本轮部署联合运行不冒充旧执行）。
- 本轮局部/完整回归 stdout、stderr、JUnit、真实rc、test_files、run record、全部 required/native 文件。
- 新 bridge 的整个业务输出，以及组合 verifier 输出。
- 隔离 WORK_DIR 的原样副本，命令/rc/挂载/实际不可读证明/五例结果/源与副本快照。
- 五策略符号统计勘误另存为 `RETURN_COUNT_CORRECTION.md`，引用新 `analysis.json` 的结果；不改旧评估 JSON，不把 pair 当收益。
- 最终报告分别列：执行接线结论、main/validation 的统计诊断、仍未执行的 V2/全尺寸/正式资格部分、任何失败及未保存的历史证据。

复制监护 run 时保存完整字节，不能只交一个本机路径或几个摘要；已有 run 不重签、不裁剪。新归档的目录名称不进入业务 seed。

明确操作：

```bash
cd "$REPO"
git diff --check
# 先审阅，仅 stage 本包新增的4个runner、新测试、原定位小修和明确归档目录。
git add stage2_6_1/runner/r17_c3_calibration_*.py \
  stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_c3_calibration_bridge.py \
  stage2_6_1/tests/route_c_stage2_6_1/test_curriculum261_r17_c3_reserve_batch.py \
  stage2_6_1/artifacts/repair17/development/c3_calibration_bridge_delivery
python "$BUNDLE/tools/check_staged_evidence.py" --repo "$REPO" \
  --directory "$REPO/stage2_6_1/artifacts/repair17/development/c3_calibration_bridge_delivery"
# 核验通过后普通提交，不 amend，不 force-push。
git commit -m "R17 C3 calibration statistical handoff and deployment test integration"
git push origin HEAD:route-c-stage2-6-1-repair17
git rev-parse HEAD
git ls-remote origin refs/heads/route-c-stage2-6-1-repair17
```

提交前审阅整个 `git diff --cached --name-status` 与实际 diff，既有暂存的其他工作不得混入本轮；保留它们，不使用 reset/restore 清理。

提交前若 Git 的行尾转换使 staged 字节不等于记录/原件，停止并保存差异；不要更改业务锚去迁就。不要 `git add -A` 混入旧残留 run 或事故日志。返回远端完整 SHA 和关键原件的仓库路径，使下一次能直接独立验收。

## 8. 本轮作者侧验证边界

见 `evidence/execution_scope.json` 和原始 JUnit。作者环境为 Linux/Python 3.13.5；统计测试使用真实新代码、保存文件与明确的模拟上游统计模块，应用器用临时 Git 仓库验证。

**未在用户 WSL 应用、未调用用户完整仓库的 R4/R5 实体、未处理用户真实批次、未做用户监护或隔离实测、未跑完整回归、未推送。** 接口脚本与实机任务正用于验证这些边界，不能把作者本地绿色冒充实机结果。
