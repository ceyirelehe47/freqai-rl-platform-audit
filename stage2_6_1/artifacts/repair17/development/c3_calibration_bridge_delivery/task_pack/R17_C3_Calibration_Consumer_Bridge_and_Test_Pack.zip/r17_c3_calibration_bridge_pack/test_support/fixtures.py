"""Explicit synthetic upstream data; no real generation or evaluation."""
import hashlib
import r17_c3_reserve_batch as m
GENERATOR={"family":"c3_cost","version":"cur261-c3-v4","fixture":True}

def proof(q, accepted=True, attempts=None):
    n = attempts if attempts is not None else (1 if accepted else 5)
    rp = {**m.PARAMS[q.rung], 'cur261_rung': q.rung}
    call = {**q.coordinate, 'iteration': 'r17', 'max_attempts': 5, 'rung_params': rp,
            'generator': GENERATOR, 'split': 'curriculum261_'+q.coordinate['namespace'], 'timeframe': '15m'}
    call['digest'] = m.envelope_digest(call, True)
    envs, logs = [], []
    for i in range(n):
        passed = accepted and i == n-1
        codes = [] if passed else ['A:too_few_distractors','B:too_few_distractors','pair:too_few_distractors']
        env = {**q.coordinate, 'iteration':'r17', 'attempt_index':i, 'outer_seed':m.expected_seed(q,i),
               'internal_derived_seed':m.expected_seed(q,i)//2, 'split':call['split'], 'timeframe':'15m',
               'seed_derivation_fields':{**q.coordinate,'attempt':i,'stage_id':'stage2_6_1'},
               'generator':GENERATOR, 'exception':None, 'generator_state_changed':False,
               'generator_state_changed_since_call_start':False, 'accepted':passed,
               'structural_validator_results':codes, 'rejection_reasons':codes,
               'base_params':{s:{**rp,'pair_variant':s,'episode_bars':288,'initial_price':1.0} for s in ('A','B')},
               'event_table':{s:{'bars':288,'hidden_digest':'hidden-fixture',
                                'episode_content_hash':'ce-'+hashlib.sha256(f'{q.key}/{i}/{s}'.encode()).hexdigest(),
                                'counts':{'n_signals':10,'n_above_cost':6 if s=='A' else 0,
                                          'n_below_cost':4 if s=='A' else 10,'n_distractors':2 if passed else 0}}
                              for s in ('A','B')}}
        env['digest'] = m.envelope_digest(env)
        envs.append(env)
        logs.append({'index':i,'accepted':passed,'reason':'; '.join(codes)})
    hashes = {s:envs[-1]['event_table'][s]['episode_content_hash'] for s in ('A','B')} if accepted else {}
    return {'coordinate':q.coordinate,'status':'accepted' if accepted else 'structural_rejected',
            'recorder_errors':[], 'call_envelope':call,'attempt_envelopes':envs,
            'episode_hashes':hashes,'integrity':{'family':m.FAMILY,'rung':q.rung,'pair_index':q.index,'pass':True},
            'attempt_log':{'family':m.FAMILY,'rung':q.rung,'pair_index':q.index,
                           'seed_namespace':q.coordinate['namespace'],'max_attempts':5,
                           'selected_attempt':n-1 if accepted else None,
                           'attempts':logs,'output_episode_hashes':hashes}}

def ev(q,p,negative=False):
    rows=[]
    for side in ('A','B'):
        row={'rung':q.rung,'pair':q.index,'side':side,'episode_hash':p['episode_hashes'][side]}
        row.update({'always_flat':0.,'always_long':-.002,'c3_cost_ignorant':-.05,
                    'reference':-.12 if negative else .10,'oracle':-.1 if negative else .20})
        rows.append(row)
    means={n:sum(r[n] for r in rows)/2 for n in m.POLICIES}
    return {'family':m.FAMILY,'episodes':rows,'policy_means':means,
            'difficulty_metric':means['reference']-max(0.,means['always_long']),
            'reference_beats_required_baselines':means['reference']>max(means[n] for n in m.POLICIES[:3]),
            'oracle_positive':means['oracle']>0}

class Fixture:
    def __init__(self,rejected=(),fail=None,negative=False,evaluation_fail=None):
        self.rejected=set(rejected); self.fail=fail; self.negative=negative
        self.evaluation_fail=evaluation_fail; self.calls=[]; self.evaluated=[]; self.root=None
    def describe(self):
        return {'kind':'test_fixture','generator':GENERATOR}
    def generate(self,q,observe):
        self.calls.append(q.key)
        if q.key==self.fail:
            raise PermissionError('fixture permission denied; not structural')
        p=proof(q,q.key not in self.rejected)
        observe('call',p['call_envelope'])
        for e in p['attempt_envelopes']: observe('attempt',e)
        return m.Generated(p,p if p['status']=='accepted' else None)
    def evaluate(self,q,handle):
        assert self.root is None or (self.root/'selection.json').is_file()
        self.evaluated.append(q.key)
        if q.key==self.evaluation_fail:
            raise OSError('evaluation failed')
        return ev(q,handle,self.negative)

class LadderFixture(Fixture):
    """Deterministic returns only for bridge tests, not a production evaluator."""
    def __init__(self, fail_split=None, **kw):
        super().__init__(**kw);self.fail_split=fail_split
    def evaluate(self,q,p):
        out=ev(q,p)
        v=[.08,.06,.04,.02][m.RUNGS.index(q.rung)] + q.index*.001
        if q.split==self.fail_split and q.rung=='D3': v=-.02
        for row in out['episodes']:
            row['reference']=2*v+.01 if row['side']=='A' else -.01
            row['oracle']=abs(row['reference'])+.1
            row['reference_trades']=3;row['always_long_trades']=1
        out['policy_means']={k:sum(r[k] for r in out['episodes'])/2 for k in m.POLICIES}
        out['difficulty_metric']=out['policy_means']['reference']
        out['reference_beats_required_baselines']=v>0
        out['oracle_positive']=True
        return out
