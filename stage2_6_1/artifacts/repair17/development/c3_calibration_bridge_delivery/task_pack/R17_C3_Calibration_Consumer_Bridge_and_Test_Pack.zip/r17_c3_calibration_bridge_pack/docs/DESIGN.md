# C3 校准统计消费端：本轮设计决定

## 1. 为什么先接消费端，而不是立即扩样

R17 的 `run_calibration_corpus_c13_r17` 委托 R6 的 C1/C3 语料生成，其输入含 V2 preprocessor 和参数包；完整校准不是把已验收的 v1 raw 结果改个标题。上一批次只有每分区×rung 两个pair，不能无声变成十个pair的校准语料，也不能冒充做过 V2 fit/transform。

本轮采用一个可独立验证的增量：把**现存、身份固定的真实评估行**送入当前 calibration 使用的 pair-cluster 原语与 strict gate 消费端。没有新的抽样，不需要现在重新定义正式备援预算，不触碰旧 rt3。

这是前次“接入工程 calibration”中的统计接口阶段；生成侧全尺寸接线、统一 fit bank、V2 envelope routing 和完整 fresh 工程演练没有在本包里完成。下一步应从这个已验证接口继续接入，而非再次改 reader/监护。

## 2. 同源计算与独立核验

运行计算使用仓库 R4/R5 现有函数，不重新写收益计算。五类策略从白名单取值：always_flat、always_long、c3_cost_ignorant、reference、oracle。

对每个分区独立形成一个表，行键为 `(corpus,family,rung,pair_index)`。每策略先做 mean(A,B)，一个pair是一个cluster。难度是 reference_pair−always_flat_pair；margin 是每条固定基线的差，不是逐episode取最佳基线。

运行时直接调用 `corpus_conditions_r5`，κ=1.5；main 和 engineering validation 各自必须满足全部 strict 条件，整体统计诊断是二者 AND。不调用 pooled rescue、不把 bootstrap CI 用作替代门槛。

只读核验从被复制的原始批次重新提取选中行、比对全部身份，再核验 pair均值、n、ddof=1 SD/SE、gap、margin和布尔条件。数值交叉验证的容差仅用于浮点一致性，不用于放宽 `>`／`>=` 的判断。bootstrap 不绑定 verdict；冷读不是重新执行 NumPy bootstrap 的声明。

## 3. 两种“通过”不能合并

`engineering_consumer_complete` 表示接口执行和证据一致。`statistical_diagnostic_pass` 表示这份已经看过的小型raw数据在strict条件下的诊断结果。

后者为false时，仍应完整保存并允许前者为true；这不是把统计FAIL救成PASS，而是把任务执行状态和数据结论分开。`calibration_qualified` 在本包所有路径上都为false。

正式资格、归一化有效性、样本量充分性、C1/C2、supervised/BC/PPO 都不在本轮结论内。不得看到诊断结果后再增加样本、更换旧输入或调整κ。

## 4. 身份与可重定位

只接受已验收批次 manifest 的固定 Git blob `0ef26c7edd2a3b41aac345a751304fb4df2b75bc`，再使用原 reserve verifier 检查完整字节和业务语义。外层 Git object 绑定原manifest，不由新输入自行授权新批次。

新输出目录排他创建，复制旧业务原件到其 `input_batch/`，新plan/analysis/result独立存储。只读命令输出stdout，没有任意report目标。外层桥接manifest绑定新输出字节，内部统计校验拒绝哈希自洽但错配的数据。

本包不声称能抵御同时替换代码、信任根、全部数据和最终Git提交的攻击者。source_lock、原manifest固定身份和独立提交验收共同提供明确范围的证据。

## 5. 与上一份小修的关系

旧任务安排本地测试定位修好后随下一轮入库，本轮应用器因此允许该唯一已知未提交增量。它既不要求用户回滚，也不再应用相同修复。所有其他执行面漂移拒绝。

本轮Agent交付动作明确包括commit和push。脚本不自动推送只是职责边界，不是停止在本地的指令。

## 6. 参考源码（固定基线5607876）

- `stage2_6_1/src/rl_curriculum/curriculum261_r17_calibration.py`：R17到R6的C1/C3与V2接线。
- `stage2_6_1/src/rl_curriculum/curriculum261_r6_calibration.py`：fit bank及C1/C3 corpus runner。
- `stage2_6_1/src/rl_curriculum/curriculum261_r4_pairs.py`：pair表、cluster_stats、bootstrap、difficulty与margin。
- `stage2_6_1/src/rl_curriculum/curriculum261_r5_pairs.py`：strict per-corpus κ=1.5，pooled仅诊断。
- `stage2_6_1/runner/r17_c3_reserve_batch.py`：已验收的固定批次与只读验证。

上面均来自 `ceyirelehe47/freqai-rl-platform-audit`，不使用第三方解释替代仓库合同。
