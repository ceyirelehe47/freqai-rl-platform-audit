# 本地测试记录说明

首次 bridge 局部运行：54 passed、1 failed。失败测试的子进程未继承测试专用旧 reserve 模块路径，得到 ModuleNotFoundError，尚未到达被测 fixture 拒绝逻辑。随后只修正测试子进程 PYTHONPATH，未放宽产品判断；保留 bridge_initial.log/xml。

最终本包运行：55 项 bridge 数据/接口/证据测试 + 13 项临时 Git 仓库应用器测试，68 passed。三种目录布局另外各运行同一旧 reserve 69项和新 bridge 55项，分别124 passed；这是重复验证，不是372个不同测试。

本地统计原语为明确的 NumPy 测试实现，运行的是实际新 adapter.analyze 控制流，不是用户完整仓库。任务包的 check_installed_interfaces.py 要在用户 WSL 调用实际 R4/R5 原函数完成接口复验。

未运行真实采样/评价/预处理fit/用户监护/用户隔离冷读/完整项目回归。没有操作远端写入。
