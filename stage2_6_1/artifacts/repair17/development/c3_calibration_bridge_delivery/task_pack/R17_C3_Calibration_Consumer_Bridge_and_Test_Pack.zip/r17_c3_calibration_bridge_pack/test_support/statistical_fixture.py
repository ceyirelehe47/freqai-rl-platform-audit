"""NumPy statistical fixtures for adapter tests, not the full repository.

Equations match the inspected R4/R5 contract; the WSL interface check must call
actual repository functions. No test here claims full project execution.
"""
import math
import types
import numpy as np
import r17_c3_calibration_bridge as b
from r17_c3_calibration_authority import RepositoryAuthority


def build_pair_evidence_table(rows,family,corpus):
    by={}
    for r in rows:by.setdefault((r['rung'],r['pair']),{})[r['side']]=r
    table=[]
    for (r,i),x in sorted(by.items()):
        table.append({'family':family,'corpus':corpus,'rung':r,'pair_index':i,
                      'episode_hashes':{s:x[s]['episode_hash'] for s in ('A','B')},
                      'returns':{p:float(np.mean([x['A'][p],x['B'][p]])) for p in b.POLICIES}})
    return {'schema':{'fixture':True},'schema_identity':'fixture','family':family,'corpus':corpus,'rows':table,'n_pairs':len(table)}


def table_series(t,r,p):return np.asarray([x['returns'][p] for x in t['rows'] if x['rung']==r])
def difficulty_series(t,r):return table_series(t,r,'reference')-table_series(t,r,'always_flat')
def margin_series(t,r,p):return table_series(t,r,'reference')-table_series(t,r,p)
def cluster_stats(a):
    return {'n':len(a),'mean':float(np.mean(a)),'sd':float(np.std(a,ddof=1)),
            'se':float(np.std(a,ddof=1)/np.sqrt(len(a)))}
def bootstrap_mean_ci(a):
    rng=np.random.default_rng(b.BOOTSTRAP_SEED)
    v=a[rng.integers(0,len(a),size=(b.BOOTSTRAP_N,len(a)))].mean(axis=1)
    lo,hi=np.quantile(v,[.025,.975])
    return {'n':len(a),'mean':float(a.mean()),'ci_low':float(lo),'ci_high':float(hi),
            'seed':b.BOOTSTRAP_SEED,'resamples':b.BOOTSTRAP_N,'method':'percentile bootstrap;resample pairs(A/B 不拆散)'}

def corpus_conditions_r5(rep,kappa=1.5):
    la=rep['difficulty_ladder'];gaps={}
    for a,c in zip(b.RUNGS,b.RUNGS[1:]):
        key=a+'-'+c;g=rep['adjacent_rung_gaps'][key]
        gaps[key]={**g,'kappa_times_se':kappa*g['se_pair_cluster'],
                   'ok':g['gap']>0 and g['gap']>=kappa*g['se_pair_cluster']}
    margins={}
    for p in b.BASELINES:
        margins[p]={}
        for r in b.RUNGS:
            st=rep['fixed_baseline_margins'][p][r]
            margins[p][r]={'mean':st['mean'],'se':st['se'],'kappa_times_se':kappa*st['se'],
                           'bootstrap_ci':st['bootstrap_ci'],'ok':st['mean']>0 and st['mean']>=kappa*st['se']}
    doc={'rule':'strict per-corpus(R5 唯一口径)','kappa':float(kappa),
         'ordering_ok':all(la[a]['mean']>la[c]['mean'] for a,c in zip(b.RUNGS,b.RUNGS[1:])),
         'gaps_ge_kappa_se':all(x['ok'] for x in gaps.values()),'gaps':gaps,
         'd3_positive':la['D3']['mean']>0,'d3_mean_ge_kappa_se':la['D3']['mean']>=kappa*la['D3']['se'],
         'd3_mean':la['D3']['mean'],'d3_se':la['D3']['se'],'d3_bootstrap_ci':la['D3']['bootstrap_ci'],
         'margins_ok':all(x['ok'] for pr in margins.values() for x in pr.values()),'fixed_baseline_margins':margins,
         'pair_integrity_unity':rep['pair_integrity_pass_rate']==1.,'oracle_positive':rep['oracle_positive_all_rungs']}
    doc['pass']=all(doc[k] for k in ('ordering_ok','gaps_ge_kappa_se','d3_positive','d3_mean_ge_kappa_se','margins_ok','pair_integrity_unity','oracle_positive'))
    return doc


class FixtureAuthority(RepositoryAuthority):
    def __init__(self):
        names=('build_pair_evidence_table','table_series','difficulty_series','margin_series','cluster_stats','bootstrap_mean_ci')
        self.r4=types.SimpleNamespace(**{n:globals()[n] for n in names})
        self.r5=types.SimpleNamespace(corpus_conditions_r5=corpus_conditions_r5)
        self.calls=0
    def describe(self):return {'kind':'test_fixture','sources':{}}
    def analyze(self,rows):
        self.calls+=1
        return super().analyze(rows)
