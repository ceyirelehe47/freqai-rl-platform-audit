#!/usr/bin/env python3
"""Confirm Git's staged bytes equal an explicitly named archived evidence directory."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);p.add_argument('--directory',type=Path,required=True);a=p.parse_args()
    repo=a.repo.resolve(strict=True);directory=a.directory.resolve(strict=True)
    if not directory.is_relative_to(repo):p.error('directory outside repo')
    out=[]
    for f in sorted(directory.rglob('*')):
        if f.is_symlink():raise RuntimeError('symlink evidence: '+str(f))
        if not f.is_file():continue
        rel=f.relative_to(repo).as_posix()
        p=subprocess.run(['git','-C',str(repo),'show',':'+rel],capture_output=True)
        raw=f.read_bytes();ok=p.returncode==0 and p.stdout==raw
        out.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'staged_byte_equal':ok})
    ok=bool(out) and all(x['staged_byte_equal'] for x in out)
    print(json.dumps({'ok':ok,'files':out},ensure_ascii=False,indent=2));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
