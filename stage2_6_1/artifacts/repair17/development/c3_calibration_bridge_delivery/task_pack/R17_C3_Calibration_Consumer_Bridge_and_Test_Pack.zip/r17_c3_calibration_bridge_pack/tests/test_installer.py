from pathlib import Path
import hashlib
import subprocess
import pytest
import apply_patch as app


def git(root,*args):return subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True).stdout

@pytest.fixture
def repo(tmp_path,monkeypatch):
    r=tmp_path/'repo';r.mkdir();git(r,'init','-b',app.BRANCH);git(r,'config','user.email','test@example.invalid');git(r,'config','user.name','Fixture')
    for name,path in app.MODULE_PATHS.items():
        p=r/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# synthetic installer fixture for '+name+'\nVALUE=1\n')
    for path in app.GUARD_BLOBS:
        p=r/path
        if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# synthetic guard fixture\nVALUE=1\n')
    t=r/app.OLD_TEST;t.parent.mkdir(parents=True,exist_ok=True)
    raw=b"for base in []:\n"+app.ANCHOR+b"\n        pass\n"
    t.write_bytes(raw)
    git(r,'add','.');git(r,'commit','-m','baseline')
    monkeypatch.setattr(app,'BASELINE',git(r,'rev-parse','HEAD').decode().strip())
    monkeypatch.setattr(app,'OLD_TEST_BLOB',app.blob(raw))
    monkeypatch.setattr(app,'GUARD_BLOBS',{p:app.blob((r/p).read_bytes()) for p in app.GUARD_BLOBS})
    return r


def test_check_does_not_write(repo):
    before=git(repo,'status','--porcelain');result=app.apply(repo)
    assert result['checked'] and not result['applied'] and before==git(repo,'status','--porcelain')


def test_apply_adds_components_and_missing_fix(repo):
    result=app.apply(repo,perform=True)
    assert result['old_test_fix_included']
    assert b"base/'stage2_6_1_runner'" in (repo/app.OLD_TEST).read_bytes()
    assert (repo/app.RUNNER/'r17_c3_calibration_bridge.py').is_file()
    assert git(repo,'diff','--cached','--name-only')==b''

@pytest.mark.parametrize('staged',[False,True])
def test_local_precompleted_fix_kept(repo,staged):
    p=repo/app.OLD_TEST;p.write_bytes(p.read_bytes().replace(app.ANCHOR,app.REPLACEMENT));before=p.read_bytes()
    if staged:git(repo,'add',app.OLD_TEST)
    index=git(repo,'diff','--cached')
    result=app.apply(repo,perform=True)
    assert result['preserved_already_applied_test_fix'] and p.read_bytes()==before
    assert index==git(repo,'diff','--cached')


def test_unknown_local_test_change_rejected(repo):
    p=repo/app.OLD_TEST;p.write_bytes(p.read_bytes()+b'# arbitrary\n')
    with pytest.raises(Exception):app.apply(repo,perform=True)
    assert not (repo/app.RUNNER/'r17_c3_calibration_bridge.py').exists()


def test_source_drift_rejected(repo):
    p=repo/next(iter(app.GUARD_BLOBS));p.write_bytes(p.read_bytes()+b'# drift\n')
    with pytest.raises(Exception):app.apply(repo,perform=True)


def test_already_installed_refused(repo):
    app.apply(repo,perform=True)
    with pytest.raises(Exception):app.apply(repo,perform=True)


def test_future_docs_commit_accepted_and_local_note_preserved(repo):
    p=repo/'report.md';p.write_text('doc');git(repo,'add','.');git(repo,'commit','-m','docs')
    p.write_text('local note')
    app.apply(repo,perform=True);assert p.read_text()=='local note'


def test_newer_source_commit_rejected(repo):
    p=repo/next(iter(app.MODULE_PATHS.values()));p.write_text('CHANGED=True\n');git(repo,'add','.');git(repo,'commit','-m','source drift')
    with pytest.raises(Exception):app.apply(repo,perform=True)


def test_wrong_branch_rejected(repo):
    git(repo,'checkout','-b','other')
    with pytest.raises(Exception):app.apply(repo)


def test_generated_lock_matches_installed_files(repo):
    result=app.apply(repo,perform=True)
    lock={};exec((repo/app.RUNNER/'r17_c3_calibration_source_lock.py').read_text(),lock)
    assert lock['SOURCE_SHA256']==result['source_lock']
    for name in app.MODULES:
        assert lock['SOURCE_SHA256'][name]==hashlib.sha256((repo/app.RUNNER/(name+'.py')).read_bytes()).hexdigest()


def test_patch_output_is_create_only(repo,tmp_path):
    target=tmp_path/'patch';target.write_text('history')
    with pytest.raises(FileExistsError):app.apply(repo,patch_out=target)
    assert target.read_text()=='history' and not (repo/app.RUNNER/'r17_c3_calibration_bridge.py').exists()


def test_unknown_untracked_executable_refused(repo):
    p=repo/app.RUNNER/'other.py';p.write_text('pass\n')
    with pytest.raises(Exception):app.apply(repo)
