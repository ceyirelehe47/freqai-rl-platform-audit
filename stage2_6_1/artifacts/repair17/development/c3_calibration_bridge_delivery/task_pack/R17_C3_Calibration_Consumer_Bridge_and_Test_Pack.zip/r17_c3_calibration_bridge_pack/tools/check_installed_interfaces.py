#!/usr/bin/env python3
"""Call actual repository calibration-statistics interfaces on synthetic rows only."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
from unittest.mock import patch
from contextlib import ExitStack


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--runner',type=Path,required=True);a=p.parse_args()
    sys.path.insert(0,str(a.runner.resolve(strict=True)))
    try:
        import r17_c3_calibration_bridge as b
        from r17_c3_calibration_authority import RepositoryAuthority
        authority=RepositoryAuthority()
        from rl_curriculum import curriculum261_api as api, curriculum261_pairs as pairs
        from rl_curriculum import curriculum261_r4_pairs as r4
        from rl_curriculum import curriculum261_c3 as c3
        rows={s:[] for s in b.SPLITS}
        for s in b.SPLITS:
            for j,r in enumerate(b.RUNGS):
                for i in (0,1):
                    for side in ('A','B'):
                        v=.08-j*.02+i*.001
                        rows[s].append({'rung':r,'pair':i,'side':side,
                            'episode_hash':'ce-'+hashlib.sha256(f'interface-fixture/{s}/{r}/{i}/{side}'.encode()).hexdigest(),
                            'always_flat':0.,'always_long':-.002,'c3_cost_ignorant':-.03,'reference':v,'oracle':.2})
        with ExitStack() as stack:
            mocks=[stack.enter_context(patch.object(obj,name,side_effect=AssertionError('prohibited generation/evaluation')))
                   for obj,name in ((api,'generate_pair_with_attempts'),(pairs,'generate_pair'),
                                    (c3.C3CostAwareGenerator,'_generate'),(r4,'run_policy_episode'))]
            doc=authority.analyze(rows)
            statuses=b.check_analysis(rows,doc)
            for f in mocks:f.assert_not_called()
        if not all(statuses.values()):raise RuntimeError('expected toy strict gate failed')
        print(json.dumps({'ok':True,'scope':'actual repository R4/R5 functions on synthetic rows; no real sample generation',
                          'python':sys.version,'authority':authority.describe(),
                          'pair_n_per_rung':2,'policy_values':doc['return_counts']['n_policy_returns'],
                          'blocked_generator_and_evaluator_calls':0},ensure_ascii=False,indent=2));return 0
    except Exception as exc:
        print(json.dumps({'ok':False,'error':type(exc).__name__+': '+str(exc)},ensure_ascii=False));return 2

if __name__=='__main__':raise SystemExit(main())
